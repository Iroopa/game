import { useCallback, useEffect, useState, type CSSProperties } from "react";
import { MotionConfig } from "framer-motion";
import { LanguageProvider } from "./lib/i18n";
import { StoreProvider, useStore } from "./lib/store";
import { ConciergeProvider } from "./lib/concierge";
import { parseRoute, type Route } from "./lib/router-types";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { ThemeSpotlight } from "./components/ThemeStudio";
import { Services } from "./components/Services";
import { BrandsSection as VendorsSection, CategoriesSection } from "./components/Vendors";
import { StorefrontSection } from "./components/Storefront";
import { HowItWorks } from "./components/HowItWorks";
import { DashboardPreview } from "./components/DashboardPreview";
import { Bilingual } from "./components/Bilingual";
import { Footer } from "./components/Footer";
import { MobileDock } from "./components/MobileDock";
import { ToastViewport } from "./components/ui";
import { Spotlighter } from "./components/Spotlighter";
import { ConciergeCenter } from "./components/ConciergeCenter";
import { DashboardView } from "./views/DashboardView";
import { SubmitView } from "./views/SubmitView";
import { ShowcaseView } from "./views/ShowcaseView";

type Theme = "dark" | "light";

function useRoute(): Route {
  const [route, setRoute] = useState<Route>(() => parseRoute(window.location.hash));
  useEffect(() => {
    const onHash = () => {
      const hash = window.location.hash;
      const next = parseRoute(hash);
      setRoute((prev) => {
        /* return-to-home anchor navigation from other views */
        if (
          next.name === "home" &&
          prev.name !== "home" &&
          hash &&
          !hash.startsWith("#/")
        ) {
          window.setTimeout(() => {
            document.getElementById(hash.slice(1))?.scrollIntoView({ behavior: "smooth" });
          }, 120);
        } else if (next.name !== "home") {
          window.scrollTo({ top: 0 });
        }
        return next;
      });
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  return route;
}

function HomeShell({ theme, onToggleTheme }: { theme: Theme; onToggleTheme: () => void }) {
  const { db } = useStore();
  const override = db.overrides[db.activeTheme];
  const style: CSSProperties = {};
  if (override?.colors) {
    Object.entries(override.colors).forEach(([k, v]) => {
      if (v) (style as Record<string, string>)[`--c-${k}`] = v;
    });
  }

  return (
    <div data-ht={db.activeTheme} style={style} className="min-h-dvh bg-ink text-fg">
      <a
        href="#demo"
        className="sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-[60] focus:rounded-lg focus:bg-elev focus:px-4 focus:py-2 focus:text-sm"
      >
        Skip to voice assistant
      </a>
      <Navbar theme={theme} onToggleTheme={onToggleTheme} route="home" />
      <main>
        <Hero />
        <ThemeSpotlight />
        <Services />
        <div className="cv-auto">
          <VendorsSection />
        </div>
        <div className="cv-auto">
          <CategoriesSection />
        </div>
        <div className="cv-auto">
          <StorefrontSection />
        </div>
        <div className="cv-auto">
          <HowItWorks />
        </div>
        <DashboardPreview />
        <div className="cv-auto">
          <Bilingual />
        </div>
      </main>
      <div className="cv-auto">
        <Footer />
      </div>
      <MobileDock />
      <Spotlighter />
    </div>
  );
}

export default function App() {
  const route = useRoute();
  const [theme, setTheme] = useState<Theme>(() => {
    try {
      return (localStorage.getItem("iroopa-theme") as Theme) || "dark";
    } catch {
      return "dark";
    }
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute("content", theme === "dark" ? "#05080b" : "#f3f6f4");
    try {
      localStorage.setItem("iroopa-theme", theme);
    } catch {
      /* private mode */
    }
  }, [theme]);

  const toggleTheme = useCallback(
    () => setTheme((p) => (p === "dark" ? "light" : "dark")),
    []
  );

  return (
    <MotionConfig reducedMotion="user">
      <LanguageProvider>
        <StoreProvider>
          <ConciergeProvider>
            {route.name === "home" && <HomeShell theme={theme} onToggleTheme={toggleTheme} />}
            {route.name === "dashboard" && <DashboardView sub={route.sub} />}
            {route.name === "submit" && <SubmitView />}
            {route.name === "showcase" && <ShowcaseView />}
            <ConciergeCenter />
            <ToastViewport />
          </ConciergeProvider>
        </StoreProvider>
      </LanguageProvider>
    </MotionConfig>
  );
}
