import { useState } from "react";
import {
  AtSign,
  Briefcase,
  Building2,
  CheckCircle2,
  Clock3,
  Globe2,
  MessageCircle,
  Music2,
  Package,
  Phone,
  Play,
  Plus,
  Send,
  Sparkles,
  Trash2,
} from "lucide-react";
import { SECTORS, useStore, type RequestedProductDraft, type SectorKey } from "../lib/store";
import { useLang } from "../lib/i18n";
import { Logo } from "../components/Navbar";
import { Field, inputCls } from "../components/ui";
import { cn } from "../utils/cn";

const normalize = (v: string) => {
  const s = v.trim();
  if (!s) return "";
  if (/^https?:\/\//i.test(s)) return s;
  if (/^[\w-]+\.[\w.-]+/.test(s)) return `https://${s}`;
  return s;
};

export function SubmitView() {
  const { submitRequest } = useStore();
  const { lang } = useLang();
  const ar = lang === "ar";

  const [name, setName] = useState("");
  const [sector, setSector] = useState<SectorKey>("fashion");
  const [website, setWebsite] = useState("");
  const [instagram, setInstagram] = useState("");
  const [facebook, setFacebook] = useState("");
  const [linkedin, setLinkedin] = useState("");
  const [tiktok, setTiktok] = useState("");
  const [youtube, setYoutube] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [city, setCity] = useState("");
  const [about, setAbout] = useState("");
  const [products, setProducts] = useState<RequestedProductDraft[]>([
    { name: "", category: "", price: null, originalPrice: null, productUrl: "" },
  ]);
  const [done, setDone] = useState<{ id: string } | null>(null);

  const valid = name.trim().length > 1 && normalize(website).startsWith("http");

  const submit = () => {
    if (!valid) return;
    const request = submitRequest({
      name: name.trim(),
      sector,
      website: normalize(website),
      instagram: normalize(instagram) || undefined,
      facebook: normalize(facebook) || undefined,
      linkedin: normalize(linkedin) || undefined,
      tiktok: normalize(tiktok) || undefined,
      youtube: normalize(youtube) || undefined,
      whatsapp: whatsapp.replace(/\D/g, "") || undefined,
      city: city.trim() || undefined,
      about: about.trim() || undefined,
      productDrafts: products
        .filter((p) => p.name?.trim())
        .map((p) => ({
          name: p.name.trim(),
          category: p.category?.trim() || undefined,
          price: p.price ? Number(p.price) : null,
          originalPrice: p.originalPrice ? Number(p.originalPrice) : null,
          productUrl: normalize(p.productUrl || "") || undefined,
        })),
    });
    setDone({ id: request.id });
  };

  return (
    <div className="min-h-dvh bg-ink text-fg">
      <header className="glass sticky top-0 z-40 border-b border-line">
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-4 py-3">
          <a href="#/" aria-label="Back to site">
            <Logo />
          </a>
          <a
            href="#/"
            className="ms-auto rounded-full border border-line bg-elev/70 px-4 py-2 text-xs font-bold text-fg2 transition-colors hover:border-brand/50 hover:text-fg"
          >
            {ar ? "العودة للموقع" : "Back to site"}
          </a>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-10 sm:py-14">
        {done ? (
          <div className="card-surface rounded-3xl p-8 text-center sm:p-12">
            <span className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-gradient-to-br from-brand to-accent text-onbrand">
              <CheckCircle2 className="h-8 w-8" aria-hidden />
            </span>
            <h1 className="mt-6 font-display text-3xl font-bold tracking-tight">
              {ar ? "تم إرسال طلبك" : "Request received"}
            </h1>
            <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-fg2">
              {ar
                ? "سنراجع علامتك خلال ٤٨ ساعة. الإضافة مجانية بالكامل، وسنتحقق من الروابط الرسمية قبل النشر."
                : "We review your brand within 48 hours. Listing is completely free, and we verify your official links before publishing."}
            </p>
            <div className="mx-auto mt-6 flex max-w-sm items-center justify-center gap-3 rounded-2xl border border-brand/30 bg-brand/[0.07] p-4">
              <Clock3 className="h-5 w-5 shrink-0 text-brand" aria-hidden />
              <div className="text-start">
                <p className="text-xs font-bold text-fg">
                  {ar ? "مرجع الطلب" : "Reference"}
                </p>
                <p className="font-mono text-[11px] text-brand" dir="ltr">{done.id}</p>
              </div>
            </div>
            <a
              href="#/"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand to-brand-deep px-7 py-3 text-sm font-bold text-onbrand transition-all hover:brightness-110"
            >
              {ar ? "العودة للموقع" : "Back to site"}
            </a>
          </div>
        ) : (
          <>
            <div className="text-center">
              <span className="inline-flex items-center gap-2 rounded-full border border-brand/40 bg-brand/10 px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-widest text-brand">
                <Sparkles className="h-3.5 w-3.5" aria-hidden />
                {ar ? "إضافة مجانية" : "Free listing"}
              </span>
          <h1 className="mt-5 font-display text-4xl font-bold tracking-tight sm:text-5xl">
            {ar ? "أضف علامتك التجارية" : "Add your brand"}
          </h1>
          <p className="mx-auto mt-4 max-w-lg text-sm leading-relaxed text-fg2 sm:text-base">
            {ar
              ? "أرسل رابط موقعك وحساباتك الرسمية. نراجع الطلب يدويًا خلال ٤٨ ساعة، والنشر مجاني."
              : "Submit your website and official social links. We review every request manually within 48 hours — listing is free."}
          </p>
            </div>

            <div className="card-surface mt-9 rounded-3xl p-6 sm:p-8">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label={ar ? "اسم الشركة *" : "Company name *"}>
                  <div className="relative">
                    <Building2 className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg3" aria-hidden />
                    <input
                      className={cn(inputCls, "ps-9")}
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={ar ? "مثال: قلب" : "e.g. QALEB"}
                    />
                  </div>
                </Field>

                <Field label={ar ? "القطاع" : "Sector"}>
                  <select
                    className={inputCls}
                    value={sector}
                    onChange={(e) => setSector(e.target.value as SectorKey)}
                  >
                    {SECTORS.map((s) => (
                      <option key={s.key} value={s.key}>
                        {ar ? s.label : s.label}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>

              <div className="mt-4">
                <Field label={ar ? "رابط الموقع *" : "Website link *"}>
                  <div className="relative">
                    <Globe2 className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg3" aria-hidden />
                    <input
                      className={cn(inputCls, "ps-9")}
                      dir="ltr"
                      value={website}
                      onChange={(e) => setWebsite(e.target.value)}
                      placeholder="example.com"
                    />
                  </div>
                </Field>
              </div>

              <p className="mt-6 text-[11px] font-bold uppercase tracking-widest text-fg3">
                {ar ? "روابط التواصل الاجتماعي" : "Social media links"}
              </p>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {[
                  { icon: AtSign, label: "Instagram", value: instagram, set: setInstagram, ph: "instagram.com/yourbrand" },
                  { icon: MessageCircle, label: "Facebook", value: facebook, set: setFacebook, ph: "facebook.com/yourbrand" },
                  { icon: Briefcase, label: "LinkedIn", value: linkedin, set: setLinkedin, ph: "linkedin.com/company/yourbrand" },
                  { icon: Music2, label: "TikTok", value: tiktok, set: setTiktok, ph: "tiktok.com/@yourbrand" },
                  { icon: Play, label: "YouTube", value: youtube, set: setYoutube, ph: "youtube.com/@yourbrand" },
                ].map((f) => {
                  const Icon = f.icon;
                  return (
                    <Field key={f.label} label={f.label}>
                      <div className="relative">
                        <Icon className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg3" aria-hidden />
                        <input
                          className={cn(inputCls, "ps-9")}
                          dir="ltr"
                          value={f.value}
                          onChange={(e) => f.set(e.target.value)}
                          placeholder={f.ph}
                        />
                      </div>
                    </Field>
                  );
                })}
              </div>

              <div className="mt-6 rounded-2xl border border-line bg-elev/35 p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <p className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-widest text-fg3">
                    <Package className="h-4 w-4 text-brand" aria-hidden />
                    {ar ? "منتجات اختيارية" : "Optional products"}
                  </p>
                  <button
                    type="button"
                    onClick={() =>
                      setProducts((prev) => [
                        ...prev,
                        { name: "", category: "", price: null, originalPrice: null, productUrl: "" },
                      ])
                    }
                    className="inline-flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 text-[10px] font-bold text-fg2 hover:border-brand/50 hover:text-brand"
                  >
                    <Plus className="h-3.5 w-3.5" /> {ar ? "أضف منتجًا" : "Add product"}
                  </button>
                </div>
                <div className="mt-3 space-y-3">
                  {products.map((product, idx) => (
                    <div key={idx} className="rounded-2xl border border-line bg-ink/30 p-3">
                      <div className="grid gap-3 sm:grid-cols-2">
                        <Field label={ar ? `اسم المنتج ${idx + 1}` : `Product ${idx + 1} name`}>
                          <input
                            className={inputCls}
                            value={product.name}
                            onChange={(e) =>
                              setProducts((prev) =>
                                prev.map((p, i) => (i === idx ? { ...p, name: e.target.value } : p))
                              )
                            }
                            placeholder={ar ? "مثال: حقيبة جلد" : "e.g. Leather Tote"}
                          />
                        </Field>
                        <Field label={ar ? "الفئة" : "Category"}>
                          <input
                            className={inputCls}
                            value={product.category ?? ""}
                            onChange={(e) =>
                              setProducts((prev) =>
                                prev.map((p, i) => (i === idx ? { ...p, category: e.target.value } : p))
                              )
                            }
                            placeholder={ar ? "مثال: Bags" : "e.g. Bags"}
                          />
                        </Field>
                        <Field label={ar ? "السعر الحالي (اختياري)" : "Current price (optional)"}>
                          <input
                            type="number"
                            min={0}
                            className={inputCls}
                            value={product.price ?? ""}
                            onChange={(e) =>
                              setProducts((prev) =>
                                prev.map((p, i) => (i === idx ? { ...p, price: e.target.value ? Number(e.target.value) : null } : p))
                              )
                            }
                          />
                        </Field>
                        <Field label={ar ? "السعر السابق (اختياري)" : "Previous price (optional)"}>
                          <input
                            type="number"
                            min={0}
                            className={inputCls}
                            value={product.originalPrice ?? ""}
                            onChange={(e) =>
                              setProducts((prev) =>
                                prev.map((p, i) => (i === idx ? { ...p, originalPrice: e.target.value ? Number(e.target.value) : null } : p))
                              )
                            }
                          />
                        </Field>
                      </div>
                      <div className="mt-3 flex flex-wrap items-center gap-3">
                        <input
                          className={cn(inputCls, "min-w-[220px] flex-1")}
                          dir="ltr"
                          value={product.productUrl ?? ""}
                          onChange={(e) =>
                            setProducts((prev) =>
                              prev.map((p, i) => (i === idx ? { ...p, productUrl: e.target.value } : p))
                            )
                          }
                          placeholder={ar ? "رابط المنتج الرسمي (اختياري)" : "Official product URL (optional)"}
                        />
                        {products.length > 1 && (
                          <button
                            type="button"
                            onClick={() => setProducts((prev) => prev.filter((_, i) => i !== idx))}
                            className="inline-flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 text-[10px] font-bold text-fg3 hover:border-rose-400/40 hover:text-rose-400"
                          >
                            <Trash2 className="h-3.5 w-3.5" /> {ar ? "حذف" : "Remove"}
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <Field label={ar ? "واتساب" : "WhatsApp"}>
                  <div className="relative">
                    <Phone className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg3" aria-hidden />
                    <input
                      className={cn(inputCls, "ps-9")}
                      dir="ltr"
                      value={whatsapp}
                      onChange={(e) => setWhatsapp(e.target.value)}
                      placeholder="201234567890"
                    />
                  </div>
                </Field>
                <Field label={ar ? "المدينة" : "City"}>
                  <input
                    className={inputCls}
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder={ar ? "القاهرة" : "Cairo"}
                  />
                </Field>
              </div>

              <div className="mt-4">
                <Field label={ar ? "نبذة قصيرة" : "Short description"}>
                  <textarea
                    className={cn(inputCls, "min-h-[80px] resize-y")}
                    value={about}
                    onChange={(e) => setAbout(e.target.value)}
                    placeholder={ar ? "ما الذي تقدمه شركتك؟" : "What does your company offer?"}
                  />
                </Field>
              </div>

              <p className="mt-5 flex items-start gap-2 rounded-xl border border-line bg-ink/40 p-3 text-[10px] leading-relaxed text-fg3">
                <Clock3 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand" aria-hidden />
                {ar
                  ? "المراجعة تستغرق حتى ٤٨ ساعة. نتحقق من أن الروابط رسمية قبل النشر — لن ننشر حسابات غير مؤكدة."
                  : "Review takes up to 48 hours. We verify links are official before publishing — we never publish unconfirmed accounts."}
              </p>

              <button
                type="button"
                onClick={submit}
                disabled={!valid}
                className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-brand to-brand-deep px-8 py-3.5 text-sm font-bold text-onbrand transition-all hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
              >
                <Send className="h-4 w-4" aria-hidden />
                {ar ? "إرسال الطلب" : "Submit for review"}
              </button>
              {!valid && (
                <p className="mt-2 text-center text-[10px] text-fg3">
                  {ar ? "الاسم ورابط الموقع مطلوبان" : "Company name and website link are required"}
                </p>
              )}
            </div>
          </>
        )}
      </main>
    </div>
  );
}
