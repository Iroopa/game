import { useMemo, useState } from "react";
import {
  AtSign,
  ExternalLink,
  Globe2,
  Loader2,
  MessageCircle,
  Music2,
  Play,
  RefreshCw,
  Search,
  ShieldCheck,
  TriangleAlert,
} from "lucide-react";
import { PROBE_STYLE, probeVendorLinks, runPool } from "../../lib/link-check";
import { SECTORS, useStore, vendorHost, type LinkProbe, type Vendor, type BrandCompany } from "../../lib/store";
import { VendorLogo } from "../../components/Vendors";
import { inputCls } from "../../components/ui";
import { cn } from "../../utils/cn";

type Channel = "website" | "instagram" | "facebook" | "tiktok" | "youtube";

const CHANNELS: { key: Channel; label: string; icon: typeof Globe2 }[] = [
  { key: "website", label: "Website", icon: Globe2 },
  { key: "instagram", label: "Instagram", icon: AtSign },
  { key: "facebook", label: "Facebook", icon: MessageCircle },
  { key: "tiktok", label: "TikTok", icon: Music2 },
  { key: "youtube", label: "YouTube", icon: Play },
];

const targetsOf = (v: BrandCompany) => ({
  website: v.website || undefined,
  instagram: v.socials?.instagram,
  facebook: v.socials?.facebook,
  tiktok: v.socials?.tiktok,
  youtube: v.socials?.youtube,
});

const discoverUrl = (v: BrandCompany, channel: Channel) => {
  if (channel === "youtube") {
    return `https://www.youtube.com/results?search_query=${encodeURIComponent(`${v.name} official channel Egypt`)}`;
  }
  return `https://www.google.com/search?q=${encodeURIComponent(`${v.name} official ${channel} Egypt`)}`;
};

export function LinksPanel() {
  const { db, bulkUpsertVendors, toast } = useStore();
  const [sector, setSector] = useState("fashion");
  const [q, setQ] = useState("");
  const [onlyProblems, setOnlyProblems] = useState(false);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [editing, setEditing] = useState<{ id: string; channel: Channel } | null>(null);
  const [draftUrl, setDraftUrl] = useState("");

  const list = useMemo(() => {
    const query = q.trim().toLowerCase();
    return db.vendors
      .filter((v) => (sector === "all" ? true : v.sector === sector))
      .filter((v) => !query || v.name.toLowerCase().includes(query))
      .filter((v) => {
        if (!onlyProblems) return true;
        const c = v.linkCheck;
        const targets = targetsOf(v);
        if (!c) return CHANNELS.some((ch) => !targets[ch.key]);
        return CHANNELS.some(
          (ch) =>
            !targets[ch.key] ||
            c[ch.key]?.state === "missing" ||
            c[ch.key]?.state === "unreachable" ||
            c[ch.key]?.state === "blocked"
        );
      })
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [db.vendors, sector, q, onlyProblems]);

  const stats = useMemo(() => {
    let ok = 0;
    let broken = 0;
    let unconfirmed = 0;
    let checked = 0;
    db.vendors.forEach((v) => {
      if (!v.linkCheck) return;
      checked += 1;
      CHANNELS.forEach((ch) => {
        const s = v.linkCheck?.[ch.key]?.state;
        if (s === "ok") ok += 1;
        else if (s === "unreachable") broken += 1;
        else if (s === "blocked") unconfirmed += 1;
      });
    });
    return { ok, broken, unconfirmed, checked };
  }, [db.vendors]);

  const sweep = async (vendors: Vendor[]) => {
    if (!vendors.length || running) return;
    setRunning(true);
    setProgress({ done: 0, total: vendors.length });
    const updated = await runPool(
      vendors,
      4,
      async (v): Promise<Vendor> => {
        const report = await probeVendorLinks(targetsOf(v));
        return {
          ...v,
          linkCheck: { ...report, checkedAt: new Date().toISOString() },
          linkStatus:
            report.website.state === "ok"
              ? "fresh"
              : report.website.state === "missing"
                ? "unverified"
                : "stale",
        };
      },
      (done, total) => setProgress({ done, total })
    );
    /* one silent commit keeps a 60-vendor sweep from firing 60 toasts */
    bulkUpsertVendors(updated);
    setRunning(false);
    const broken = updated.filter((v) =>
      CHANNELS.some((ch) => v.linkCheck?.[ch.key]?.state === "unreachable")
    ).length;
    toast(
      broken
        ? `Checked ${updated.length} — ${broken} need attention`
        : `Checked ${updated.length} vendor${updated.length === 1 ? "" : "s"}`,
      broken ? "warn" : "ok"
    );
  };

  const saveUrl = (v: Vendor, channel: Channel, url: string) => {
    const clean = url.trim();
    bulkUpsertVendors([
      channel === "website"
        ? { ...v, website: clean, catalogUrl: clean || undefined }
        : { ...v, socials: { ...v.socials, [channel]: clean || undefined } },
    ]);
    setEditing(null);
    toast("Link updated — re-run the check to confirm", "info");
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-line bg-panel p-5">
        <div className="flex flex-wrap items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-brand to-accent text-onbrand">
            <ShieldCheck className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold text-fg">Link health</p>
            <p className="text-[11px] text-fg3">
              Checks websites and social/video channels from the browser using DNS plus a reachability probe.
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5 text-[10px] font-bold">
            <span className="rounded-full border border-brand/40 bg-brand/10 px-2.5 py-1 text-brand">{stats.ok} working</span>
            <span className="rounded-full border border-gold/40 bg-gold/10 px-2.5 py-1 text-gold">{stats.unconfirmed} unconfirmed</span>
            <span className="rounded-full border border-rose-400/40 bg-rose-400/10 px-2.5 py-1 text-rose-400">{stats.broken} broken</span>
            <span className="rounded-full border border-line px-2.5 py-1 text-fg3">{stats.checked} profiles checked</span>
          </div>
        </div>

        <p className="mt-3 flex items-start gap-2 rounded-xl border border-line bg-ink/40 p-3 text-[10px] leading-relaxed text-fg3">
          <TriangleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gold" aria-hidden />
          Browsers cannot read cross-origin HTTP status codes, so results are reported as Working, Unconfirmed, Broken or Missing
          rather than fake 200/404 codes. “Unconfirmed” means the domain resolves but the site refused the browser probe — open it to confirm.
        </p>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute start-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-fg3" aria-hidden />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search vendors…" className={cn(inputCls, "w-48 rounded-full ps-9 text-xs")} />
          </div>
          <select value={sector} onChange={(e) => setSector(e.target.value)} className={cn(inputCls, "w-44 rounded-full text-xs")}>
            <option value="all">All sectors</option>
            {SECTORS.map((s) => (
              <option key={s.key} value={s.key}>{s.label}</option>
            ))}
          </select>
          <label className="flex items-center gap-2 text-[11px] font-bold text-fg2">
            <input type="checkbox" checked={onlyProblems} onChange={(e) => setOnlyProblems(e.target.checked)} className="h-4 w-4 accent-[var(--c-brand)]" />
            Problems only
          </label>
          <button
            type="button"
            disabled={running || !list.length}
            onClick={() => void sweep(list)}
            className="ms-auto inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand to-brand-deep px-5 py-2.5 text-xs font-bold text-onbrand disabled:opacity-40"
          >
            {running ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            {running ? `Checking ${progress.done}/${progress.total}` : `Check ${list.length} vendor${list.length === 1 ? "" : "s"}`}
          </button>
        </div>
        {running && (
          <div className="mt-3 h-1 w-full overflow-hidden rounded-full bg-line">
            <div
              className="h-full rounded-full bg-brand transition-all"
              style={{ width: `${progress.total ? (progress.done / progress.total) * 100 : 0}%` }}
            />
          </div>
        )}
      </div>

      <div className="space-y-2">
        {list.map((v) => {
          const targets = targetsOf(v);
          return (
            <div key={v.id} className="rounded-2xl border border-line bg-panel p-3">
              <div className="flex items-center gap-3">
                <VendorLogo vendor={v} size={34} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-bold text-fg" dir="ltr">{v.name}</p>
                  <p className="truncate text-[10px] text-fg3">
                    {vendorHost(v.website) ?? "no official site"}
                    {v.linkCheck?.checkedAt && ` · checked ${new Date(v.linkCheck.checkedAt).toLocaleDateString()}`}
                  </p>
                </div>
                <button
                  type="button"
                  disabled={running}
                  onClick={() => void sweep([v])}
                  className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-line px-3 py-1.5 text-[10px] font-bold text-fg2 hover:border-brand/50 hover:text-fg disabled:opacity-40"
                >
                  <RefreshCw className="h-3 w-3" /> Recheck
                </button>
              </div>

              <div className="mt-2.5 flex flex-wrap gap-1.5">
                {CHANNELS.map((ch) => {
                  const probe: LinkProbe | undefined = v.linkCheck?.[ch.key];
                  const state = probe?.state ?? (targets[ch.key] ? "blocked" : "missing");
                  const style = PROBE_STYLE[probe ? probe.state : state === "missing" ? "missing" : "blocked"];
                  const isEditing = editing?.id === v.id && editing.channel === ch.key;
                  const Icon = ch.icon;

                  if (isEditing) {
                    return (
                      <span key={ch.key} className="flex items-center gap-1.5">
                        <input
                          autoFocus
                          value={draftUrl}
                          onChange={(e) => setDraftUrl(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") saveUrl(v, ch.key, draftUrl);
                            if (e.key === "Escape") setEditing(null);
                          }}
                          dir="ltr"
                          placeholder={`${ch.label} URL`}
                          className={cn(inputCls, "w-60 text-[11px]")}
                        />
                        <button
                          type="button"
                          onClick={() => saveUrl(v, ch.key, draftUrl)}
                          className="rounded-lg bg-brand px-2.5 py-1.5 text-[10px] font-bold text-onbrand"
                        >
                          Save
                        </button>
                      </span>
                    );
                  }

                  return (
                    <span
                      key={ch.key}
                      className={cn(
                        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-bold",
                        style.cls
                      )}
                      title={probe?.detail ?? "Not checked yet"}
                    >
                      <Icon className="h-3 w-3" aria-hidden />
                      {ch.label}
                      <span className="opacity-80">· {probe ? style.label : "unchecked"}</span>
                      {targets[ch.key] && (
                        <a
                          href={targets[ch.key]}
                          target="_blank"
                          rel="noreferrer"
                          className="opacity-70 transition-opacity hover:opacity-100"
                          aria-label={`Open ${ch.label}`}
                        >
                          <ExternalLink className="h-2.5 w-2.5" />
                        </a>
                      )}
                      {!targets[ch.key] && (
                        <a
                          href={discoverUrl(v, ch.key)}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-0.5 text-gold opacity-80 hover:opacity-100"
                          aria-label={`Find official ${ch.label}`}
                          title={`Search the web for ${v.name}'s official ${ch.label}`}
                        >
                          <Search className="h-2.5 w-2.5" /> find
                        </a>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          setEditing({ id: v.id, channel: ch.key });
                          setDraftUrl(targets[ch.key] ?? "");
                        }}
                        className="underline decoration-dotted underline-offset-2 opacity-70 hover:opacity-100"
                      >
                        edit
                      </button>
                    </span>
                  );
                })}
              </div>
            </div>
          );
        })}
        {!list.length && <p className="py-10 text-center text-xs text-fg3">No vendors match this filter.</p>}
      </div>
    </div>
  );
}
