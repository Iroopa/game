import { useRef, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Database,
  Download,
  FileJson,
  ImageOff,
  Info,
  Loader2,
  Navigation as NavIcon,
  PackageX,
  Upload,
} from "lucide-react";
import {
  buildReportJson,
  parseWordPressBundle,
  type ParsedBundle,
} from "../../lib/wp-migrate";
import { useStore } from "../../lib/store";
import { downloadJSON, inputCls } from "../../components/ui";
import { cn } from "../../utils/cn";

const CURRENCIES = ["EGP", "USD", "EUR", "AED", "SAR"];

export function MigrationPanel() {
  const { db, setCurrency, toast } = useStore();
  const [bundle, setBundle] = useState<ParsedBundle | null>(null);
  const [fileName, setFileName] = useState("");
  const [busy, setBusy] = useState(false);
  const [showMedia, setShowMedia] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const currency = db.currency ?? "EGP";

  const ingest = async (text: string, name: string) => {
    setBusy(true);
    try {
      const parsed = JSON.parse(text);
      const result = parseWordPressBundle(parsed, 50);
      setBundle(result);
      setFileName(name);
      toast(
        `Parsed ${result.report.pages} pages · ${result.report.mediaReferences} media refs · 0 products`,
        "info"
      );
    } catch (err) {
      toast(
        err instanceof Error ? `Invalid JSON: ${err.message}` : "That file is not valid JSON",
        "err"
      );
    } finally {
      setBusy(false);
    }
  };

  const report = bundle?.report;

  return (
    <div className="space-y-4">
      {/* source summary */}
      <div className="rounded-2xl border border-line bg-panel p-5">
        <div className="flex flex-wrap items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-accent to-violet text-white">
            <Database className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold text-fg">Legacy WordPress migration</p>
            <p className="text-[11px] text-fg3">
              iROOPA database · tagline “BUY AND SELL EASILY” · 50 tables · 91 content records
            </p>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[
            { label: "Tables", value: 50, icon: Database },
            { label: "Content records", value: 91, icon: FileJson },
            { label: "Media references", value: 11, icon: ImageOff },
            { label: "Nav items", value: 8, icon: NavIcon },
          ].map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.label} className="rounded-xl border border-line bg-elev/45 p-3">
                <Icon className="h-4 w-4 text-brand" aria-hidden />
                <p className="mt-2 font-display text-xl font-bold tabular-nums">{s.value}</p>
                <p className="text-[10px] text-fg3">{s.label}</p>
              </div>
            );
          })}
        </div>

        <p className="mt-3 flex items-start gap-2 rounded-xl border border-gold/30 bg-gold/[0.07] p-3 text-[10px] leading-relaxed text-gold">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
          The source SQL contains <strong>no WooCommerce products</strong> and{" "}
          <strong>no vendor directory</strong>. This importer reports what exists and never
          invents products, sellers, prices or media files.
        </p>
      </div>

      {/* upload + currency */}
      <div className="grid gap-4 lg:grid-cols-[1fr_minmax(0,320px)]">
        <div className="rounded-2xl border border-line bg-panel p-5">
          <p className="text-sm font-bold text-fg">Import extracted JSON</p>
          <p className="mt-1 text-[11px] text-fg3">
            Upload the “Extracted website data — JSON” file from the migration bundle.
          </p>
          <div
            className="mt-3 rounded-2xl border border-dashed border-line2 p-6 text-center"
            onDragOver={(e) => e.preventDefault()}
            onDrop={async (e) => {
              e.preventDefault();
              const f = e.dataTransfer.files?.[0];
              if (f) await ingest(await f.text(), f.name);
            }}
          >
            <FileJson className="mx-auto h-7 w-7 text-fg3/60" aria-hidden />
            <p className="mt-2 text-xs font-semibold text-fg2">
              Drop the bundle JSON here
            </p>
            <p className="mt-0.5 text-[10px] text-fg3">
              Accepts posts, options, terms, navigation and media references in any nesting
            </p>
            <button
              type="button"
              disabled={busy}
              onClick={() => fileRef.current?.click()}
              className="mt-3 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand to-brand-deep px-5 py-2.5 text-xs font-bold text-onbrand disabled:opacity-40"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
              {busy ? "Parsing…" : "Choose file"}
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (f) await ingest(await f.text(), f.name);
                e.target.value = "";
              }}
            />
            {fileName && (
              <p className="mt-2 truncate text-[10px] font-semibold text-brand" dir="ltr">
                {fileName}
              </p>
            )}
          </div>
        </div>

        <div className="rounded-2xl border border-line bg-panel p-5">
          <p className="text-sm font-bold text-fg">Store currency</p>
          <p className="mt-1 text-[11px] text-fg3">
            The legacy database does not state a currency. Confirm before launch.
          </p>
          <select
            value={currency}
            onChange={(e) => setCurrency(e.target.value)}
            className={cn(inputCls, "mt-3 text-sm")}
          >
            {CURRENCIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          {report?.currenciesDetected.length ? (
            <p className="mt-2 flex items-start gap-2 text-[10px] leading-relaxed text-fg3">
              <Info className="mt-0.5 h-3 w-3 shrink-0 text-accent" aria-hidden />
              Detected in content: {report.currenciesDetected.join(", ")}
            </p>
          ) : (
            <p className="mt-2 text-[10px] leading-relaxed text-fg3">
              No currency detected in the imported content yet.
            </p>
          )}
        </div>
      </div>

      {/* report */}
      {report && (
        <div className="rounded-2xl border border-line bg-panel p-5">
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm font-bold text-fg">Migration report</p>
            {report.bundleTagline && (
              <span className="rounded-full border border-brand/30 bg-brand/10 px-2.5 py-0.5 text-[10px] font-bold text-brand">
                “{report.bundleTagline}”
              </span>
            )}
            <button
              type="button"
              onClick={() =>
                downloadJSON("iroopa-wp-migration-report.json", buildReportJson(bundle!, currency))
              }
              className="ms-auto inline-flex items-center gap-2 rounded-full border border-line px-4 py-2 text-[11px] font-bold text-fg2 hover:text-brand"
            >
              <Download className="h-3.5 w-3.5" /> Download report
            </button>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {[
              { label: "Pages", value: report.pages, ok: true },
              { label: "Placeholders", value: report.placeholders, ok: false },
              { label: "Nav items", value: report.navItems, ok: true },
              { label: "Taxonomy terms", value: report.terms, ok: true },
            ].map((s) => (
              <div key={s.label} className="rounded-xl border border-line bg-elev/45 p-3">
                {s.ok ? (
                  <CheckCircle2 className="h-4 w-4 text-brand" aria-hidden />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-gold" aria-hidden />
                )}
                <p className="mt-2 font-display text-xl font-bold tabular-nums">{s.value}</p>
                <p className="text-[10px] text-fg3">{s.label}</p>
              </div>
            ))}
          </div>

          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <div className="flex items-start gap-2 rounded-xl border border-gold/30 bg-gold/[0.07] p-3">
              <PackageX className="mt-0.5 h-4 w-4 shrink-0 text-gold" aria-hidden />
              <p className="text-[10px] leading-relaxed text-gold">
                <strong>0 products · 0 vendors found.</strong> The legacy database has no
                WooCommerce records, so no catalogue entries were created.
              </p>
            </div>
            <div className="flex items-start gap-2 rounded-xl border border-gold/30 bg-gold/[0.07] p-3">
              <ImageOff className="mt-0.5 h-4 w-4 shrink-0 text-gold" aria-hidden />
              <p className="text-[10px] leading-relaxed text-gold">
                <strong>{report.mediaReferences} media references, 0 files.</strong> The SQL does
                not contain the uploads directory — original assets are required.
              </p>
            </div>
          </div>

          {/* placeholder pages */}
          {report.placeholders > 0 && (
            <div className="mt-4">
              <p className="text-[10px] font-bold uppercase tracking-widest text-fg3">
                Placeholder pages needing review
              </p>
              <div className="mt-2 max-h-52 space-y-1.5 overflow-y-auto pe-1">
                {bundle!.pages
                  .filter((p) => p.isPlaceholder)
                  .map((p) => (
                    <div
                      key={p.id}
                      className="flex items-center gap-2 rounded-xl border border-line bg-elev/40 px-3 py-2"
                    >
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-gold" aria-hidden />
                      <span className="truncate text-[11px] font-bold text-fg" dir="ltr">
                        {p.title}
                      </span>
                      <span className="ms-auto shrink-0 text-[9px] text-fg3">
                        {p.placeholderReason}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* missing media */}
          {report.missingMedia.length > 0 && (
            <div className="mt-4">
              <button
                type="button"
                onClick={() => setShowMedia((v) => !v)}
                className="flex w-full items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-fg3 hover:text-fg"
              >
                <ImageOff className="h-3.5 w-3.5" aria-hidden />
                Missing media assets ({report.missingMedia.length})
                <span className="ms-auto">{showMedia ? "−" : "+"}</span>
              </button>
              {showMedia && (
                <ul className="mt-2 max-h-52 space-y-1 overflow-y-auto pe-1">
                  {report.missingMedia.map((m) => (
                    <li
                      key={m}
                      className="truncate rounded-lg border border-line bg-ink/40 px-3 py-1.5 text-[10px] text-fg3"
                      dir="ltr"
                    >
                      {m}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {/* navigation */}
          {bundle!.nav.length > 0 && (
            <div className="mt-4">
              <p className="text-[10px] font-bold uppercase tracking-widest text-fg3">
                Legacy navigation
              </p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {bundle!.nav.map((n, i) => (
                  <span
                    key={`${n.label}-${i}`}
                    className="rounded-full border border-line bg-elev/50 px-2.5 py-1 text-[10px] font-semibold text-fg2"
                  >
                    {n.label}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
