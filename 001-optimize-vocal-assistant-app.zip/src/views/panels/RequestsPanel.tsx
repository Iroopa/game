import { useMemo, useState } from "react";
import {
  AlertTriangle,
  Check,
  Clock3,
  Inbox,
  ShieldCheck,
  X,
} from "lucide-react";
import { useStore, type RequestStatus, type VendorRequest } from "../../lib/store";
import { VendorLogo } from "../../components/Vendors";
import { inputCls } from "../../components/ui";
import { cn } from "../../utils/cn";

const STATUS_STYLE: Record<RequestStatus, string> = {
  pending: "border-gold/40 bg-gold/10 text-gold",
  approved: "border-brand/40 bg-brand/10 text-brand",
  rejected: "border-rose-400/40 bg-rose-400/10 text-rose-400",
};

const hoursLeft = (r: VendorRequest) =>
  r.slaHours - (Date.now() - new Date(r.submittedAt).getTime()) / 3_600_000;

function RequestRow({ request }: { request: VendorRequest }) {
  const { setRequestStatus } = useStore();
  const [note, setNote] = useState("");
  const [showNote, setShowNote] = useState(false);

  const left = hoursLeft(request);
  const overdue = request.status === "pending" && left < 0;
  const dueLabel = overdue
    ? `Overdue by ${Math.abs(Math.round(left))}h`
    : `${Math.max(0, Math.floor(left))}h ${Math.round((left % 1) * 60)}m left`;

  return (
    <div className="rounded-2xl border border-line bg-panel p-4">
      <div className="flex flex-wrap items-start gap-3">
        <VendorLogo
          vendor={
            {
              id: request.id,
              name: request.name,
              website: request.website,
              logoHue: 180,
            } as never
          }
          size={40}
        />
        <div className="min-w-[160px] flex-1">
          <p className="text-sm font-bold text-fg" dir="ltr">{request.name}</p>
          <a
            href={request.website}
            target="_blank"
            rel="noreferrer"
            className="block truncate text-[11px] text-brand hover:underline"
            dir="ltr"
          >
            {request.website}
          </a>
          {request.about && (
            <p className="mt-1 line-clamp-2 text-[11px] leading-relaxed text-fg3">{request.about}</p>
          )}
        </div>

        <div className="flex flex-col items-end gap-1.5">
          <span className={cn("rounded-full border px-2.5 py-0.5 text-[10px] font-bold capitalize", STATUS_STYLE[request.status])}>
            {request.status}
          </span>
          {request.status === "pending" && (
            <span
              className={cn(
                "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold",
                overdue
                  ? "border-rose-400/40 bg-rose-400/10 text-rose-400"
                  : "border-line text-fg3"
              )}
            >
              {overdue ? <AlertTriangle className="h-3 w-3" /> : <Clock3 className="h-3 w-3" />}
              {dueLabel}
            </span>
          )}
        </div>
      </div>

      {/* submitted links */}
      <div className="mt-3 flex flex-wrap gap-1.5">
        {(["instagram", "facebook", "linkedin", "tiktok", "youtube"] as const).map((ch) => {
          const url = request[ch];
          if (!url) return null;
          return (
            <a
              key={ch}
              href={url}
              target="_blank"
              rel="noreferrer"
              className="rounded-full border border-line bg-elev/60 px-2.5 py-1 text-[10px] font-semibold text-fg2 transition-colors hover:border-brand/50 hover:text-brand"
              dir="ltr"
            >
              {ch}
            </a>
          );
        })}
        {request.whatsapp && (
          <span className="rounded-full border border-line bg-elev/60 px-2.5 py-1 text-[10px] font-semibold text-fg2" dir="ltr">
            WhatsApp {request.whatsapp}
          </span>
        )}
        {request.city && (
          <span className="rounded-full border border-line bg-elev/60 px-2.5 py-1 text-[10px] font-semibold text-fg2">
            {request.city}
          </span>
        )}
      </div>

      {request.productDrafts?.length ? (
        <div className="mt-3 rounded-xl border border-line bg-ink/30 p-3">
          <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-fg3">
            Optional products ({request.productDrafts.length})
          </p>
          <div className="space-y-1.5">
            {request.productDrafts.map((p, i) => (
              <div key={`${request.id}-${i}`} className="flex flex-wrap items-center gap-2 text-[11px] text-fg2">
                <span className="font-semibold text-fg">{p.name}</span>
                {p.category && <span className="text-fg3">· {p.category}</span>}
                {p.price ? <span className="font-bold text-brand">{p.price} EGP</span> : null}
                {p.productUrl ? (
                  <a href={p.productUrl} target="_blank" rel="noreferrer" className="text-brand hover:underline" dir="ltr">
                    product link
                  </a>
                ) : null}
              </div>
            ))}
          </div>
        </div>
      ) : null}

      {request.reviewNote && (
        <p className="mt-3 rounded-xl border border-line bg-ink/40 p-2.5 text-[11px] text-fg3">
          {request.reviewNote}
        </p>
      )}

      {request.status === "pending" && (
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {showNote ? (
            <>
              <input
                autoFocus
                className={cn(inputCls, "min-w-[200px] flex-1 text-xs")}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Optional review note"
              />
              <button
                type="button"
                onClick={() => setRequestStatus(request.id, "rejected", note || undefined)}
                className="inline-flex items-center gap-1.5 rounded-full border border-rose-400/50 bg-rose-400/10 px-4 py-2 text-[11px] font-bold text-rose-400"
              >
                <X className="h-3.5 w-3.5" /> Confirm reject
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setRequestStatus(request.id, "approved")}
                className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-brand to-brand-deep px-5 py-2 text-[11px] font-bold text-onbrand"
              >
                <Check className="h-3.5 w-3.5" /> Approve & publish
              </button>
              <button
                type="button"
                onClick={() => setShowNote(true)}
                className="inline-flex items-center gap-1.5 rounded-full border border-line px-4 py-2 text-[11px] font-bold text-fg2 hover:text-rose-400"
              >
                <X className="h-3.5 w-3.5" /> Reject
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}

export function RequestsPanel() {
  const { db } = useStore();
  const [filter, setFilter] = useState<"pending" | "all">("pending");

  const list = useMemo(
    () =>
      db.requests
        .filter((r) => (filter === "all" ? true : r.status === "pending"))
        .sort((a, b) => +new Date(b.submittedAt) - +new Date(a.submittedAt)),
    [db.requests, filter]
  );

  const pending = db.requests.filter((r) => r.status === "pending");
  const overdue = pending.filter((r) => hoursLeft(r) < 0).length;

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-line bg-panel p-5">
        <div className="flex flex-wrap items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-brand to-accent text-onbrand">
            <Inbox className="h-5 w-5" />
          </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-bold text-fg">Brand submissions</p>
          <p className="text-[11px] text-fg3">
            Free listings submitted from the public form. Each carries a 48-hour review SLA.
          </p>
        </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <span className="rounded-full border border-gold/40 bg-gold/10 px-3 py-1 text-[11px] font-bold text-gold">
            {pending.length} pending
          </span>
          {overdue > 0 && (
            <span className="rounded-full border border-rose-400/40 bg-rose-400/10 px-3 py-1 text-[11px] font-bold text-rose-400">
              {overdue} overdue
            </span>
          )}
          <span className="rounded-full border border-line px-3 py-1 text-[11px] font-bold text-fg3">
            {db.requests.filter((r) => r.status === "approved").length} approved
          </span>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value as "pending" | "all")}
            className={cn(inputCls, "ms-auto w-36 rounded-full text-xs")}
          >
            <option value="pending">Pending only</option>
            <option value="all">All requests</option>
          </select>
        </div>
        <p className="mt-3 flex items-start gap-2 rounded-xl border border-line bg-ink/40 p-3 text-[10px] leading-relaxed text-fg3">
          <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand" aria-hidden />
          Approving creates a live vendor record with the submitted links. Links are not verified automatically —
          run Dashboard → Link Health after approval to confirm they resolve.
        </p>
      </div>

      <div className="space-y-3">
        {list.map((r) => (
          <RequestRow key={r.id} request={r} />
        ))}
        {!list.length && (
          <div className="rounded-2xl border border-dashed border-line2 py-12 text-center">
            <Inbox className="mx-auto h-8 w-8 text-fg3/50" aria-hidden />
            <p className="mt-3 text-sm font-semibold text-fg2">
              {filter === "pending" ? "No pending requests" : "No requests yet"}
            </p>
            <p className="mt-1 text-xs text-fg3">
              Share the public form to start receiving free submissions.
            </p>
            <a
              href="#/submit"
              className="mt-4 inline-flex rounded-full border border-line px-5 py-2 text-xs font-bold text-fg2 hover:border-brand/50 hover:text-brand"
            >
              Open public form →
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
