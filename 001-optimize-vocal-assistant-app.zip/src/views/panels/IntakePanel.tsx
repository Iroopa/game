import { useMemo, useRef, useState } from "react";
import {
  BrainCircuit,
  Check,
  CloudUpload,
  FileSpreadsheet,
  ImagePlus,
  KeyRound,
  Loader2,
  Sparkles,
  Trash2,
  TriangleAlert,
  Wand2,
} from "lucide-react";
import {
  DEFAULT_GATEWAY,
  classifyBrands,
  gatewayReady,
  parseVendorInput,
  readGateway,
  writeGateway,
  type GatewayConfig,
  type ParsedVendorRow,
} from "../../lib/ai-gateway";
import { slugify, useStore, vendorHost, type Vendor } from "../../lib/store";
import { Field, inputCls, readFileAsDataURL } from "../../components/ui";
import { cn } from "../../utils/cn";

interface Draft extends ParsedVendorRow {
  key: string;
  subId: string;
  confidence: number;
  source: "ai" | "rules" | "manual";
  reason?: string;
  include: boolean;
}

const SAMPLE = `name,website,instagram,notes
QALEB,qalebstore.com,,heavyweight cotton tees
Maison Yeya,maisonyeya.com,,bridal couture atelier
Up-fuse,up-fuse.com,,upcycled bags and backpacks`;

export function IntakePanel() {
  const { db, bulkUpsertVendors, toast } = useStore();
  const [cfg, setCfg] = useState<GatewayConfig>(readGateway);
  const [text, setText] = useState("");
  const [drafts, setDrafts] = useState<Draft[]>([]); // Acts as the company_expansion_candidates staging array
  const [busy, setBusy] = useState(false);
  const [usedAi, setUsedAi] = useState<boolean | null>(null);
  const [gatewayError, setGatewayError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const logoRefs = useRef<Record<string, HTMLInputElement | null>>({});

  const fashionCat = db.categories.find((c) => c.slug === "fashion");
  const subs = useMemo(
    () =>
      db.subcategories
        .filter((s) => s.catId === fashionCat?.id)
        .sort((a, b) => a.order - b.order),
    [db.subcategories, fashionCat?.id]
  );
  const allowed = subs.map((s) => s.name);

  const saveCfg = (next: Partial<GatewayConfig>) => {
    const merged = { ...cfg, ...next };
    setCfg(merged);
    writeGateway(merged);
  };

  const ingest = async (raw: string) => {
    const rows = parseVendorInput(raw);
    if (!rows.length) {
      toast("No brands found in that input", "warn");
      return;
    }
    setBusy(true);
    setGatewayError("");
    const { results, usedAi: viaAi, error } = await classifyBrands(
      rows.map((r) => ({ name: r.name, website: r.website, notes: r.notes })),
      allowed,
      cfg
    );
    setUsedAi(viaAi);
    if (error) setGatewayError(error);
    setDrafts(
      rows.map((row, i) => {
        const hit = results[i];
        const sub = subs.find((s) => s.name === hit?.segment) ?? subs[0];
        return {
          ...row,
          key: `${slugify(row.name)}-${i}`,
          subId: sub?.id ?? "",
          confidence: hit?.confidence ?? 0,
          source: hit?.source ?? "rules",
          reason: hit?.reason,
          include: true,
        };
      })
    );
    setBusy(false);
    toast(
      viaAi ? `Classified ${rows.length} brands with the AI Gateway` : `Classified ${rows.length} brands with local rules`,
      viaAi ? "ok" : "info"
    );
  };

  const commit = () => {
    const picked = drafts.filter((d) => d.include && d.name.trim());
    if (!picked.length) {
      toast("Nothing selected to import", "warn");
      return;
    }
    const vendors: Vendor[] = picked.map((d, i) => {
      const host = d.website ? vendorHost(d.website) : null;
      const socials = {
        instagram: d.instagram,
        facebook: d.facebook,
        tiktok: d.tiktok,
        youtube: d.youtube,
        linkedin: d.linkedin,
      };
      const hasSocial = Object.values(socials).some(Boolean);
      return {
        id: `v-import-${Date.now()}-${i}`,
        name: d.name.trim(),
        sector: "fashion",
        tier: "Verified",
        hotline: "",
        website: d.website ?? "",
        mapQuery: "",
        mapUrl: d.mapUrl,
        whatsapp: d.whatsapp,
        videoUrl: "",
        logoHue: Math.floor((d.name.charCodeAt(0) * 37 + i * 59) % 360),
        showImg: d.logo ?? "",
        about: d.notes?.trim()
          ? `${d.name.trim()} — ${d.notes.trim()}`
          : `${d.name.trim()} is an imported Egyptian fashion record. Verify links and pricing before publishing.`,
        socials,
        catalogUrl: host ? d.website : undefined,
        subId: d.subId || undefined,
        subSource: d.source === "manual" ? "manual" : d.source === "ai" ? "ai" : "seed",
        entityKind: host ? "official" : "research",
        madeInEgypt: "unverified",
        linkStatus: host ? "stale" : "unverified",
        priceStatus: "unverified",
        linksAuditedAt: hasSocial || host ? new Date().toISOString().slice(0, 7) : undefined,
        hidden: false,
        order: db.vendors.length + i,
      };
    });
    const n = bulkUpsertVendors(vendors);
    setDrafts([]);
    setText("");
    toast(`Imported ${n} brand${n === 1 ? "" : "s"} into Egyptian Fashion`, "ok");
  };

  const ready = gatewayReady(cfg);

  return (
    <div className="space-y-5">
      {/* gateway config */}
      <div className="rounded-2xl border border-line bg-panel p-5">
        <div className="flex flex-wrap items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-violet to-accent text-white">
            <BrainCircuit className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold text-fg">AI Gateway</p>
            <p className="text-[11px] text-fg3">
              Used to sort imported brands into fashion subcategories. Without a key, deterministic keyword rules run instead.
            </p>
          </div>
          <label className="flex items-center gap-2 text-[11px] font-bold text-fg2">
            <input
              type="checkbox"
              checked={cfg.enabled}
              onChange={(e) => saveCfg({ enabled: e.target.checked })}
              className="h-4 w-4 accent-[var(--c-brand)]"
            />
            Enable
          </label>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <Field label="Base URL">
            <input className={inputCls} dir="ltr" value={cfg.baseUrl} onChange={(e) => saveCfg({ baseUrl: e.target.value })} placeholder={DEFAULT_GATEWAY.baseUrl} />
          </Field>
          <Field label="Model">
            <input className={inputCls} dir="ltr" value={cfg.model} onChange={(e) => saveCfg({ model: e.target.value })} placeholder="openai/gpt-4o-mini" />
          </Field>
          <Field label="API key">
            <div className="relative">
              <KeyRound className="absolute start-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-fg3" aria-hidden />
              <input
                className={cn(inputCls, "ps-9")}
                dir="ltr"
                type="password"
                value={cfg.apiKey}
                onChange={(e) => saveCfg({ apiKey: e.target.value })}
                placeholder="sk-…"
              />
            </div>
          </Field>
        </div>

        <p className="mt-3 flex items-start gap-2 rounded-xl border border-gold/30 bg-gold/[0.07] p-3 text-[10px] leading-relaxed text-gold">
          <TriangleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
          This build is fully client-side, so the key is stored in this browser and is visible to anyone using this device.
          Use a restricted key, or proxy the gateway from a server before exposing this dashboard publicly.
        </p>
        <p className="mt-2 text-[10px] font-semibold text-fg3">
          Status: {ready ? <span className="text-brand">gateway ready</span> : <span className="text-gold">rules-only mode</span>}
          {gatewayError && <span className="text-rose-400"> · {gatewayError}</span>}
        </p>
      </div>

      {/* input */}
      <div className="rounded-2xl border border-line bg-panel p-5">
        <p className="flex items-center gap-2 text-sm font-bold text-fg">
          <FileSpreadsheet className="h-4 w-4 text-brand" /> Data Import & Expansion
        </p>
        <p className="mt-1 text-[11px] text-fg3">
          Paste your <b>egypt_directory_expansion.json</b> or CSV file here. Recognized columns: name, website, logo, instagram, facebook, tiktok, youtube, whatsapp, linkedin, map, notes.
        </p>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={SAMPLE}
          dir="ltr"
          className={cn(inputCls, "mt-3 min-h-[150px] font-mono text-xs")}
        />
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            disabled={busy || !text.trim()}
            onClick={() => void ingest(text)}
            className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand to-brand-deep px-5 py-2.5 text-xs font-bold text-onbrand transition-all hover:brightness-110 disabled:opacity-40"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />}
            {busy ? "Classifying…" : "Parse & classify"}
          </button>
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="inline-flex items-center gap-2 rounded-full border border-line px-5 py-2.5 text-xs font-bold text-fg2 hover:text-fg"
          >
            <CloudUpload className="h-4 w-4 text-brand" /> Upload CSV / JSON
          </button>
          <input
            ref={fileRef}
            type="file"
            accept=".csv,.tsv,.txt,.json,application/json,text/csv"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (f) {
                const content = await f.text();
                setText(content);
                await ingest(content);
              }
              e.target.value = "";
            }}
          />
          <button
            type="button"
            onClick={() => setText(SAMPLE)}
            className="inline-flex items-center gap-2 rounded-full border border-line px-5 py-2.5 text-xs font-bold text-fg3 hover:text-fg"
          >
            Load sample
          </button>
        </div>
      </div>

      {/* review */}
      {drafts.length > 0 && (
        <div className="rounded-2xl border border-line bg-panel p-5">
          <div className="flex flex-wrap items-center gap-2">
            <p className="flex items-center gap-2 text-sm font-bold text-fg">
              <Sparkles className="h-4 w-4 text-brand" /> Staging Area: {drafts.length} Expansion Candidate{drafts.length === 1 ? "" : "s"}
            </p>
            <span
              className={cn(
                "rounded-full border px-2.5 py-0.5 text-[10px] font-bold",
                usedAi ? "border-violet/40 bg-violet/10 text-violet" : "border-gold/40 bg-gold/10 text-gold"
              )}
            >
              {usedAi ? "AI Gateway" : "Local rules"}
            </span>
            <span className="ms-auto flex gap-2">
              <button
                type="button"
                onClick={commit}
                className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand to-brand-deep px-5 py-2.5 text-xs font-bold text-onbrand"
              >
                <Check className="h-4 w-4" /> Import selected
              </button>
              <button
                type="button"
                onClick={() => setDrafts([])}
                className="inline-flex items-center gap-2 rounded-full border border-line px-4 py-2.5 text-xs font-bold text-fg3 hover:text-fg"
              >
                <Trash2 className="h-3.5 w-3.5" /> Discard
              </button>
            </span>
          </div>

          <div className="mt-4 space-y-2">
            {drafts.map((d) => (
              <div
                key={d.key}
                className={cn(
                  "flex flex-wrap items-center gap-3 rounded-2xl border p-3",
                  d.include ? "border-line bg-elev/45" : "border-dashed border-line opacity-55"
                )}
              >
                <input
                  type="checkbox"
                  checked={d.include}
                  onChange={(e) =>
                    setDrafts((list) => list.map((x) => (x.key === d.key ? { ...x, include: e.target.checked } : x)))
                  }
                  className="h-4 w-4 accent-[var(--c-brand)]"
                  aria-label={`Include ${d.name}`}
                />
                <button
                  type="button"
                  onClick={() => logoRefs.current[d.key]?.click()}
                  className="grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-xl border border-dashed border-line2 bg-ink/50 text-fg3"
                  title="Upload logo"
                >
                  {d.logo ? (
                    <img src={d.logo} alt="" className="h-full w-full object-contain p-1" />
                  ) : (
                    <ImagePlus className="h-4 w-4" />
                  )}
                </button>
                <input
                  ref={(el) => { logoRefs.current[d.key] = el; }}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (f) {
                      const data = await readFileAsDataURL(f);
                      setDrafts((list) => list.map((x) => (x.key === d.key ? { ...x, logo: data } : x)));
                    }
                    e.target.value = "";
                  }}
                />
                <div className="min-w-[150px] flex-1">
                  <input
                    value={d.name}
                    onChange={(e) =>
                      setDrafts((list) => list.map((x) => (x.key === d.key ? { ...x, name: e.target.value } : x)))
                    }
                    className="w-full bg-transparent text-xs font-bold text-fg outline-none"
                    dir="ltr"
                  />
                  <input
                    value={d.website ?? ""}
                    onChange={(e) =>
                      setDrafts((list) => list.map((x) => (x.key === d.key ? { ...x, website: e.target.value } : x)))
                    }
                    placeholder="website"
                    className="w-full bg-transparent text-[10px] text-fg3 outline-none"
                    dir="ltr"
                  />
                </div>
                <select
                  value={d.subId}
                  onChange={(e) =>
                    setDrafts((list) =>
                      list.map((x) => (x.key === d.key ? { ...x, subId: e.target.value, source: "manual" } : x))
                    )
                  }
                  className={cn(inputCls, "w-44 text-xs")}
                >
                  {subs.map((s) => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
                <span
                  className={cn(
                    "shrink-0 rounded-full border px-2 py-0.5 text-[9px] font-bold",
                    d.source === "manual"
                      ? "border-brand/40 bg-brand/10 text-brand"
                      : d.confidence >= 0.6
                        ? "border-violet/40 bg-violet/10 text-violet"
                        : "border-gold/40 bg-gold/10 text-gold"
                  )}
                  title={d.reason}
                >
                  {d.source === "manual" ? "manual" : `${d.source} ${Math.round(d.confidence * 100)}%`}
                </span>
              </div>
            ))}
          </div>
          <p className="mt-3 text-[10px] text-fg3">
            Imported records enter as unverified research profiles. Confirm links in the Link health panel before publishing them as official.
          </p>
        </div>
      )}
    </div>
  );
}
