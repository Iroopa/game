import { useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  Eye,
  EyeOff,
  Layers,
  Plus,
  Search,
  Shirt,
  Sparkles,
  Users,
} from "lucide-react";
import { useStore, vendorHost, type Vendor } from "../../lib/store";
import { TwoStepDelete, inputCls } from "../../components/ui";
import { VendorLogo } from "../../components/Vendors";
import { cn } from "../../utils/cn";

export function SegmentsPanel() {
  const {
    db,
    upsertSubcategory,
    removeSubcategory,
    toggleSubHidden,
    reorderSubcategory,
    assignVendorSub,
    toast,
  } = useStore();

  const fashionCat = db.categories.find((c) => c.slug === "fashion");
  const subs = useMemo(
    () =>
      db.subcategories
        .filter((s) => s.catId === fashionCat?.id)
        .sort((a, b) => a.order - b.order),
    [db.subcategories, fashionCat?.id]
  );

  const vendors = useMemo(
    () =>
      db.vendors
        .filter((v) => v.sector === "fashion")
        .sort((a, b) => a.name.localeCompare(b.name)),
    [db.vendors]
  );

  const [newName, setNewName] = useState("");
  const [focus, setFocus] = useState<string>("all");
  const [q, setQ] = useState("");

  const counts = useMemo(() => {
    const m = new Map<string, number>();
    vendors.forEach((v) => {
      if (v.subId) m.set(v.subId, (m.get(v.subId) ?? 0) + 1);
    });
    return m;
  }, [vendors]);

  const unassigned = vendors.filter((v) => !v.subId).length;

  const shown = useMemo(() => {
    const query = q.trim().toLowerCase();
    return vendors.filter((v) => {
      if (focus === "unassigned" && v.subId) return false;
      if (focus !== "all" && focus !== "unassigned" && v.subId !== focus) return false;
      return !query || v.name.toLowerCase().includes(query);
    });
  }, [vendors, focus, q]);

  if (!fashionCat) {
    return <p className="text-sm text-fg3">Egyptian Fashion category not found.</p>;
  }

  const add = () => {
    const name = newName.trim();
    if (!name) return;
    if (subs.some((s) => s.name.toLowerCase() === name.toLowerCase())) {
      toast("That subcategory already exists", "warn");
      return;
    }
    upsertSubcategory({
      id: `fsub-${Date.now()}`,
      catId: fashionCat.id,
      name,
      hidden: false,
      order: subs.length,
    });
    setNewName("");
    toast(`Added “${name}”`, "ok");
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,380px)_1fr]">
      {/* subcategory manager */}
      <div className="rounded-2xl border border-line bg-panel p-5">
        <p className="flex items-center gap-2 text-sm font-bold text-fg">
          <Layers className="h-4 w-4 text-brand" /> Fashion subcategories
        </p>
        <p className="mt-1 text-[11px] text-fg3">
          Create, rename, reorder and hide the segments used across the storefront, the category directory and voice search.
        </p>

        <div className="mt-4 space-y-2">
          {subs.map((s, i) => (
            <div
              key={s.id}
              className={cn(
                "flex items-center gap-2 rounded-xl border border-line bg-elev/45 p-2",
                s.hidden && "opacity-55"
              )}
            >
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-brand/10 text-[10px] font-bold text-brand">
                {i + 1}
              </span>
              <input
                value={s.name}
                onChange={(e) => upsertSubcategory({ ...s, name: e.target.value })}
                className="min-w-0 flex-1 rounded-md bg-transparent px-1 py-0.5 text-xs font-bold text-fg outline-none focus:bg-ink/60"
                aria-label="Subcategory name"
              />
              <span className="shrink-0 rounded-full border border-line px-2 py-0.5 text-[9px] font-bold text-fg3">
                {counts.get(s.id) ?? 0}
              </span>
              <button
                type="button"
                onClick={() => reorderSubcategory(s.id, -1)}
                disabled={i === 0}
                className="grid h-7 w-7 place-items-center rounded-lg border border-line text-fg3 transition-colors hover:text-fg disabled:opacity-30"
                aria-label="Move up"
              >
                <ArrowUp className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={() => reorderSubcategory(s.id, 1)}
                disabled={i === subs.length - 1}
                className="grid h-7 w-7 place-items-center rounded-lg border border-line text-fg3 transition-colors hover:text-fg disabled:opacity-30"
                aria-label="Move down"
              >
                <ArrowDown className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={() => toggleSubHidden(s.id)}
                className="grid h-7 w-7 place-items-center rounded-lg border border-line text-fg3 transition-colors hover:text-fg"
                aria-label="Toggle visibility"
              >
                {s.hidden ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
              </button>
              <TwoStepDelete
                onConfirm={() => {
                  vendors.filter((v) => v.subId === s.id).forEach((v) => assignVendorSub(v.id, ""));
                  removeSubcategory(s.id);
                  toast(`Removed “${s.name}”`, "warn");
                }}
              />
            </div>
          ))}
        </div>

        <div className="mt-3 flex gap-2">
          <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && add()}
            placeholder="New subcategory…"
            className={cn(inputCls, "text-xs")}
          />
          <button
            type="button"
            onClick={add}
            disabled={!newName.trim()}
            className="shrink-0 rounded-xl bg-gradient-to-r from-brand to-brand-deep px-4 text-xs font-bold text-onbrand disabled:opacity-40"
            aria-label="Add subcategory"
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* vendor assignment */}
      <div className="rounded-2xl border border-line bg-panel p-5">
        <div className="flex flex-wrap items-center gap-2">
          <p className="flex items-center gap-2 text-sm font-bold text-fg">
            <Users className="h-4 w-4 text-brand" /> Assign brands
          </p>
          <span className="rounded-full border border-line px-2 py-0.5 text-[10px] font-bold text-fg3">
            {vendors.length} fashion profiles
          </span>
          {unassigned > 0 && (
            <button
              type="button"
              onClick={() => setFocus("unassigned")}
              className="rounded-full border border-gold/40 bg-gold/10 px-2.5 py-0.5 text-[10px] font-bold text-gold"
            >
              {unassigned} unassigned
            </button>
          )}
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          <div className="relative">
            <Search className="absolute start-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-fg3" aria-hidden />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search brands…"
              className={cn(inputCls, "w-48 rounded-full ps-9 text-xs")}
            />
          </div>
          <select
            value={focus}
            onChange={(e) => setFocus(e.target.value)}
            className={cn(inputCls, "w-52 rounded-full text-xs")}
          >
            <option value="all">All subcategories</option>
            <option value="unassigned">Unassigned only</option>
            {subs.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>

        <div className="mt-4 max-h-[58dvh] space-y-2 overflow-y-auto pe-1">
          {shown.map((v: Vendor) => (
            <div key={v.id} className="flex items-center gap-3 rounded-xl border border-line bg-elev/45 p-2.5">
              <VendorLogo vendor={v} size={34} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-bold text-fg" dir="ltr">{v.name}</p>
                <p className="truncate text-[10px] text-fg3">
                  {vendorHost(v.website) ?? "no official site"}
                  {v.subSource === "ai" && " · AI suggested"}
                  {v.subSource === "manual" && " · manual"}
                </p>
              </div>
              {v.subSource === "ai" && (
                <Sparkles className="h-3.5 w-3.5 shrink-0 text-violet" aria-hidden />
              )}
              <select
                value={v.subId ?? ""}
                onChange={(e) => assignVendorSub(v.id, e.target.value)}
                className={cn(inputCls, "w-44 text-xs")}
              >
                <option value="">— Unassigned —</option>
                {subs.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
          ))}
          {!shown.length && (
            <p className="py-10 text-center text-xs text-fg3">
              <Shirt className="mx-auto mb-2 h-6 w-6 opacity-50" />
              No brands match this filter.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
