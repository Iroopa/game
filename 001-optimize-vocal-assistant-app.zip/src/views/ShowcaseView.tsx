import { useEffect, useRef } from "react";
import { motion, useReducedMotion } from "framer-motion";
import {
  ArrowLeft,
  ArrowUpRight,
  Bot,
  Braces,
  Brush,
  Cpu,
  Gauge,
  GitBranch,
  Globe2,
  Layers,
  Mic2,
  Package,
  Rocket,
  ScanLine,
  Sparkles,
  Wand2,
} from "lucide-react";
import { Logo } from "../components/Navbar";
import { Reveal } from "../components/Reveal";

/* ------------------------------ particles ------------------------------- */

function ParticleField() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let raf = 0;
    let w = 0;
    let h = 0;
    let mx = 0.5;
    let my = 0.5;
    let inView = true;

    const resize = () => {
      const dpr = Math.min(devicePixelRatio, 1.5);
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();

    const N = 170;
    const pts = Array.from({ length: N }, (_, i) => ({
      x: Math.random(),
      y: Math.random(),
      z: 0.35 + Math.random() * 0.65,
      vx: (Math.random() - 0.5) * 0.00035,
      vy: (Math.random() - 0.5) * 0.00035,
      hue: i % 3,
    }));

    const io = new IntersectionObserver(([e]) => (inView = e.isIntersecting));
    io.observe(canvas);
    const onMove = (e: PointerEvent) => {
      mx = e.clientX / innerWidth;
      my = e.clientY / innerHeight;
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const COLORS = ["96,165,250", "34,211,238", "139,92,246"];
    const draw = () => {
      raf = requestAnimationFrame(draw);
      if (!inView) return;
      ctx.clearRect(0, 0, w, h);
      const ox = (mx - 0.5) * 26;
      const oy = (my - 0.5) * 18;
      for (const p of pts) {
        if (!reduced) {
          p.x += p.vx;
          p.y += p.vy;
          if (p.x < -0.05) p.x = 1.05;
          if (p.x > 1.05) p.x = -0.05;
          if (p.y < -0.05) p.y = 1.05;
          if (p.y > 1.05) p.y = -0.05;
        }
        const x = p.x * w + ox * p.z;
        const y = p.y * h + oy * p.z;
        const r = p.z * 1.9;
        ctx.beginPath();
        ctx.fillStyle = `rgba(${COLORS[p.hue]},${0.24 + p.z * 0.5})`;
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }
      /* connective tissue */
      ctx.lineWidth = 0.5;
      for (let i = 0; i < N; i += 4) {
        for (let j = i + 4; j < Math.min(i + 28, N); j += 4) {
          const a = pts[i];
          const b = pts[j];
          const dx = (a.x - b.x) * w;
          const dy = (a.y - b.y) * h;
          const d = Math.hypot(dx, dy);
          if (d < 120) {
            ctx.strokeStyle = `rgba(96,165,250,${(1 - d / 120) * 0.14})`;
            ctx.beginPath();
            ctx.moveTo(a.x * w + ox * a.z, a.y * h + oy * a.z);
            ctx.lineTo(b.x * w + ox * b.z, b.y * h + oy * b.z);
            ctx.stroke();
          }
        }
      }
    };
    raf = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(raf);
      io.disconnect();
      ro.disconnect();
      window.removeEventListener("pointermove", onMove);
    };
  }, []);
  return <canvas ref={ref} className="absolute inset-0 h-full w-full" aria-hidden="true" />;
}

/* ----------------------------- 3D torus rings ----------------------------- */

function Torus({ className, dur, delay = "0s" }: { className?: string; dur: string; delay?: string }) {
  return (
    <div
      aria-hidden
      className={`absolute rounded-full border border-cyan-400/30 ${className ?? ""}`}
      style={{
        transform: "rotateX(68deg)",
        animation: `torus-spin ${dur} linear ${delay} infinite`,
        boxShadow: "0 0 44px rgba(34,211,238,0.22), inset 0 0 44px rgba(34,211,238,0.12)",
      }}
    />
  );
}

/* ------------------------------ glossy icons ------------------------------ */

const SERVICES: { icon: typeof Mic2; label: string; from: string; to: string; glow: string }[] = [
  { icon: Mic2, label: "Voice UI", from: "#22d3ee", to: "#0e7490", glow: "rgba(34,211,238,.4)" },
  { icon: Bot, label: "AI Agents", from: "#a78bfa", to: "#6d28d9", glow: "rgba(167,139,250,.4)" },
  { icon: Layers, label: "3D Scenes", from: "#60a5fa", to: "#1d4ed8", glow: "rgba(96,165,250,.4)" },
  { icon: Brush, label: "Art Direction", from: "#f472b6", to: "#be185d", glow: "rgba(244,114,182,.4)" },
  { icon: Gauge, label: "Perf Tuning", from: "#34d399", to: "#047857", glow: "rgba(52,211,153,.4)" },
  { icon: Braces, label: "Codegen", from: "#fbbf24", to: "#b45309", glow: "rgba(251,191,36,.4)" },
  { icon: GitBranch, label: "Workspaces", from: "#f87171", to: "#b91c1c", glow: "rgba(248,113,113,.4)" },
  { icon: Globe2, label: "i18n / RTL", from: "#2dd4bf", to: "#0f766e", glow: "rgba(45,212,191,.4)" },
  { icon: ScanLine, label: "Vision QA", from: "#818cf8", to: "#4338ca", glow: "rgba(129,140,248,.4)" },
  { icon: Package, label: "Component Kits", from: "#fb923c", to: "#c2410c", glow: "rgba(251,146,60,.4)" },
  { icon: Wand2, label: "Motion Design", from: "#e879f9", to: "#a21caf", glow: "rgba(232,121,249,.4)" },
  { icon: Rocket, label: "Deploys", from: "#4ade80", to: "#15803d", glow: "rgba(74,222,128,.4)" },
];

function GlossyIcon({ s, i }: { s: (typeof SERVICES)[number]; i: number }) {
  const Icon = s.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ delay: 0.05 * (i % 4), duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -6 }}
      className="group relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03] p-5 backdrop-blur-sm"
    >
      <div
        aria-hidden
        className="absolute -top-10 start-1/2 h-20 w-24 -translate-x-1/2 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100"
        style={{ background: s.glow }}
      />
      <div
        className="glossy-tile relative mx-auto grid h-14 w-14 place-items-center rounded-2xl text-white shadow-lg"
        style={{ background: `linear-gradient(145deg, ${s.from}, ${s.to})`, boxShadow: `0 14px 30px -8px ${s.glow}` }}
      >
        <Icon className="h-6 w-6" aria-hidden />
      </div>
      <p className="mt-4 text-center text-xs font-bold text-white/90">{s.label}</p>
    </motion.div>
  );
}

/* -------------------------------- the view -------------------------------- */

const STEPS = [
  { n: "01", t: "Plan", d: "Sketch the vibe — mood, palette, motion. AI turns it into a design system." },
  { n: "02", t: "Generate", d: "Components materialize from prompts: heroes, orbiters, glass decks." },
  { n: "03", t: "Integrate", d: "Wire Three.js (or a lean particle engine), parallax and physics." },
  { n: "04", t: "Deploy", d: "One command. Edge-cached, 60fps, production-ready in minutes." },
];

const STACK = ["React 19", "Three.js", "WebGL", "Tailwind v4", "Framer Motion", "Web Audio", "Vite", "TypeScript", "GSAP-ready"];

export function ShowcaseView() {
  const reduced = useReducedMotion();
  return (
    <div className="min-h-dvh bg-[#030712] text-slate-100">
      <style>{`
        @keyframes torus-spin { from { transform: rotateX(68deg) rotateZ(0deg);} to { transform: rotateX(68deg) rotateZ(360deg);} }
        .glossy-tile::after { content:""; position:absolute; inset:0; border-radius:inherit; background:linear-gradient(160deg, rgba(255,255,255,.55), rgba(255,255,255,.06) 38%, transparent 60%); mix-blend-mode:screen; pointer-events:none; }
      `}</style>

      {/* nav */}
      <header className="fixed inset-x-0 top-0 z-40 border-b border-white/5 bg-[#030712]/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-5 py-3.5">
          <a href="#/" aria-label="Back home" className="transition-opacity hover:opacity-80"><Logo /></a>
          <span className="hidden rounded-full border border-cyan-400/30 bg-cyan-400/10 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-widest text-cyan-300 sm:inline">
            3D Showcase
          </span>
          <a href="#/" className="ms-auto inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs font-bold text-slate-300 transition-colors hover:border-cyan-400/40 hover:text-white">
            <ArrowLeft className="h-3.5 w-3.5 rtl:rotate-180" aria-hidden /> Home
          </a>
        </div>
      </header>

      {/* hero */}
      <section className="relative overflow-hidden pt-36 pb-24 sm:pt-44">
        <div className="absolute inset-0"><ParticleField /></div>
        <div aria-hidden className="pointer-events-none absolute inset-0">
          <div className="aurora-blob start-[10%] top-[-10%] h-[420px] w-[420px] opacity-25" style={{ background: "#2563eb" }} />
          <div className="aurora-blob end-[8%] top-[20%] h-[380px] w-[380px] opacity-20" style={{ background: "#06b6d4" }} />
          <div className="absolute start-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 [perspective:900px]">
            <Torus className="-start-40 -top-40 h-80 w-80" dur="26s" />
            <Torus className="-start-64 -top-64 h-[32rem] w-[32rem] opacity-60" dur="38s" delay="-8s" />
          </div>
        </div>

        <div className="relative mx-auto max-w-4xl px-5 text-center">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="mx-auto inline-flex items-center gap-2 rounded-full border border-cyan-400/25 bg-cyan-400/10 px-4 py-1.5 text-[11px] font-bold uppercase tracking-[0.18em] text-cyan-300"
          >
            <Sparkles className="h-3.5 w-3.5" aria-hidden /> The 3D web, shipped by voice
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.85, delay: 0.08 }}
            className="mt-6 font-display text-5xl font-bold leading-[1.02] tracking-[-0.03em] sm:text-7xl"
          >
            Stunning{" "}
            <span className="bg-gradient-to-r from-cyan-300 via-sky-400 to-violet-400 bg-clip-text text-transparent">
              3D websites
            </span>
            <br />
            in minutes
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.85, delay: 0.16 }}
            className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-slate-400 sm:text-lg"
          >
            Plan the design, generate the components, integrate real-time 3D and deploy — one flow.
            Developers, designers and founders ship production-grade experiences at AI speed.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.85, delay: 0.24 }}
            className="mt-9 flex flex-wrap items-center justify-center gap-3"
          >
            <a
              href="#/"
              className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 to-blue-600 px-7 py-3.5 text-sm font-bold text-[#04121a] shadow-[0_18px_50px_-12px_rgba(34,211,238,0.6)] transition-all hover:scale-[1.03] hover:brightness-110 active:scale-95"
            >
              Build yours
              <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 rtl:rotate-[-90deg]" aria-hidden />
            </a>
            <a
              href="#glossy-grid"
              className="rounded-full border border-white/12 bg-white/5 px-7 py-3.5 text-sm font-semibold text-slate-200 transition-colors hover:border-cyan-400/40"
            >
              See the toolkit
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="mx-auto mt-14 grid max-w-lg grid-cols-3 gap-3"
          >
            {[
              ["1800+", "particles @ 60fps"],
              ["<2s", "first paint target"],
              ["12", "glossy service kits"],
            ].map(([v, l]) => (
              <div key={l} className="rounded-2xl border border-white/8 bg-white/[0.03] px-3 py-4 backdrop-blur-sm">
                <p className="font-display text-xl font-bold text-cyan-300" dir="ltr">{v}</p>
                <p className="mt-0.5 text-[10px] uppercase tracking-widest text-slate-500">{l}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* glossy grid */}
      <section id="glossy-grid" className="relative py-20">
        <div className="mx-auto max-w-6xl px-5">
          <Reveal className="text-center">
            <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-cyan-300">The glossy dozen</p>
            <h2 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-5xl">Every service, cut like a gem</h2>
          </Reveal>
          <div className="mt-12 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {SERVICES.map((s, i) => (
              <GlossyIcon key={s.label} s={s} i={i} />
            ))}
          </div>
        </div>
      </section>

      {/* bento features */}
      <section className="relative py-16">
        <div className="mx-auto grid max-w-6xl gap-4 px-5 lg:grid-cols-3">
          <Reveal className="lg:col-span-2 lg:row-span-2">
            <div className="relative flex h-full min-h-[300px] flex-col justify-end overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-blue-900/40 via-cyan-900/20 to-transparent p-8">
              <div aria-hidden className="absolute end-[-40px] top-[-40px] h-56 w-56 rounded-full bg-cyan-400/20 blur-3xl" />
              <Cpu className="h-8 w-8 text-cyan-300" aria-hidden />
              <h3 className="mt-5 font-display text-2xl font-bold sm:text-3xl">Real-time renderer, zero dependencies</h3>
              <p className="mt-3 max-w-md text-sm leading-relaxed text-slate-400">
                The particle field, parallax rings and depth glow you see here run on a hand-rolled canvas engine —
                no WebGL context required, no jank, and IntersectionObserver-paused offscreen.
              </p>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="h-full rounded-3xl border border-white/10 bg-white/[0.03] p-7">
              <Gauge className="h-6 w-6 text-emerald-400" aria-hidden />
              <h3 className="mt-4 text-base font-bold">Budgeted motion</h3>
              <p className="mt-2 text-xs leading-relaxed text-slate-400">DPR capped at 1.5, rAF-batched, reduced-motion aware. Pretty and polite.</p>
            </div>
          </Reveal>
          <Reveal delay={0.16}>
            <div className="h-full rounded-3xl border border-white/10 bg-white/[0.03] p-7">
              <ScanLine className="h-6 w-6 text-violet-400" aria-hidden />
              <h3 className="mt-4 text-base font-bold">Mouse parallax</h3>
              <p className="mt-2 text-xs leading-relaxed text-slate-400">Depth-layered scene that answers your cursor without a single re-render.</p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* process */}
      <section className="relative py-16">
        <div className="mx-auto max-w-6xl px-5">
          <Reveal className="text-center">
            <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-cyan-300">The workflow</p>
            <h2 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">Idea → production in four moves</h2>
          </Reveal>
          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((s, i) => (
              <Reveal key={s.n} delay={0.08 * i}>
                <div className="group relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03] p-6 transition-colors hover:border-cyan-400/30">
                  <p className="font-display text-4xl font-bold text-cyan-400/25 transition-colors group-hover:text-cyan-400/50">{s.n}</p>
                  <h3 className="mt-3 text-base font-bold">{s.t}</h3>
                  <p className="mt-2 text-xs leading-relaxed text-slate-400">{s.d}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* stack + cta */}
      <section className="relative overflow-hidden py-20">
        <div aria-hidden className="absolute inset-x-0 top-1/2 h-[420px] -translate-y-1/2 bg-[radial-gradient(closest-side,rgba(34,211,238,0.14),transparent)]" />
        <div className="relative mx-auto max-w-4xl px-5 text-center">
          <div className="flex flex-wrap justify-center gap-2">
            {STACK.map((t) => (
              <span key={t} className="rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-1.5 text-[11px] font-semibold text-slate-300">
                {t}
              </span>
            ))}
          </div>
          <h2 className="mt-10 font-display text-4xl font-bold tracking-tight sm:text-5xl">
            Ready to go{" "}
            <span className="bg-gradient-to-r from-cyan-300 to-violet-400 bg-clip-text text-transparent">spatial</span>?
          </h2>
          <p className="mx-auto mt-4 max-w-lg text-sm leading-relaxed text-slate-400">
            The same engine runs this marketplace's voice orb, dashboard and themes. Head back and talk to it.
          </p>
          <a
            href="#/"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 to-blue-600 px-8 py-4 text-sm font-bold text-[#04121a] transition-all hover:scale-[1.03] hover:brightness-110 active:scale-95"
          >
            <Mic2 className="h-4 w-4" aria-hidden /> Back to iRoopa
          </a>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8 text-center text-[11px] text-slate-500">
        iRoopa Showcase — particles, parallax and glossy things · {reduced ? "" : ""}Built with React, canvas & CSS 3D.
      </footer>
    </div>
  );
}
