import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Building2,
  ChevronDown,
  Eye,
  EyeOff,
  FolderTree,
  ImagePlus,
  LayoutDashboard,
  Package,
  Palette,
  Pencil,
  Plus,
  Search,
  ShieldCheck,
  Inbox,
  Database,
  Layers,
  Lock,
  Sparkles,
  SwatchBook,
  Download,
  Upload,
  type LucideIcon,
} from "lucide-react";
import {
  SECTORS,
  fmtEGP,
  sectorLabel,
  useStore,
  vendorHost,
  type ThemeOverride,
  type Vendor,
} from "../lib/store";
import { POOLS, pick } from "../lib/media";
import { THEMES, themeById, type ThemeId } from "../lib/themes";
import { VendorLogo } from "../components/Vendors";
import { ProductDialog } from "../components/Storefront";
import {
  Field,
  ImgWithFallback,
  Modal,
  TwoStepDelete,
  downloadJSON,
  importJSONFile,
  inputCls,
  readFileAsDataURL,
} from "../components/ui";
import { Logo } from "../components/Navbar";
import { IntakePanel } from "./panels/IntakePanel";
import { SegmentsPanel } from "./panels/SegmentsPanel";
import { LinksPanel } from "./panels/LinksPanel";
import { MigrationPanel } from "./panels/MigrationPanel";
import { RequestsPanel } from "./panels/RequestsPanel";
import { cn } from "../utils/cn";

type Panel =
  | "overview"
  | "vendors"
  | "intake"
  | "segments"
  | "links"
  | "requests"
  | "migration"
  | "categories"
  | "products"
  | "themes";

const PANELS: { id: Panel; label: string; icon: LucideIcon }[] = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "vendors", label: "Brand Companies", icon: Building2 },
  { id: "intake", label: "AI Intake", icon: Sparkles },
  { id: "segments", label: "Fashion Segments", icon: Layers },
  { id: "links", label: "Link Health", icon: ShieldCheck },
  { id: "requests", label: "Requests", icon: Inbox },
  { id: "migration", label: "WP Migration", icon: Database },
  { id: "categories", label: "Categories", icon: FolderTree },
  { id: "products", label: "Products", icon: Package },
  { id: "themes", label: "Themes", icon: Palette },
];

/* ------------------------------- vendor dialog ----------------------------- */

function VendorDialog({ open, onClose, vendor }: { open: boolean; onClose: () => void; vendor: Vendor | null }) {
  const { db, upsertVendor } = useStore();
  const [draft, setDraft] = useState<Vendor | null>(vendor);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    setDraft(
      vendor ?? {
        id: `v-custom-${Date.now()}`,
        name: "",
        sector: "ecommerce",
        tier: "Verified",
        hotline: "",
        website: "",
        mapQuery: "",
        videoUrl: "",
        videoDiscoveryUrl: "",
        entityKind: "marketplace",
        madeInEgypt: "unverified",
        linkStatus: "unverified",
        priceStatus: "unverified",
        logoHue: 155,
        showImg: POOLS.ecommerce[0],
        about: "",
        socials: {},
        catalogUrl: "",
        whatsapp: "",
        mapUrl: "",
        hidden: false,
        order: db.vendors.length + 1,
      }
    );
  }, [open, vendor, db.vendors.length]);

  if (!draft) return null;
  const poolKeys = Object.keys(POOLS) as (keyof typeof POOLS)[];

  return (
    <Modal open={open} onClose={onClose} wide labelledBy="vendor-editor">
      <div className="p-6">
        <p id="vendor-editor" className="font-display text-lg font-bold">
          {vendor ? `Edit — ${vendor.name}` : "New brand"}
        </p>
        <div className="mt-5 grid gap-4 sm:grid-cols-[220px_1fr]">
          <div className="space-y-3">
            <Field label="Logo">
              <div className="flex items-center gap-3">
                <VendorLogo vendor={draft} size={56} />
                <input
                  type="color"
                  value={`hsl(${draft.logoHue}, 70%, 48%)`}
                  onChange={() => undefined}
                  className="hidden"
                  aria-hidden
                />
                <div className="flex-1">
                  <input
                    type="range"
                    min={0}
                    max={360}
                    value={draft.logoHue}
                    onChange={(e) => setDraft({ ...draft, logoHue: Number(e.target.value) })}
                    className="w-full accent-[var(--c-brand)]"
                    aria-label="Logo color hue"
                  />
                  <p className="text-center text-[10px] text-fg3">Hue {draft.logoHue}°</p>
                </div>
              </div>
            </Field>
            <Field label="Showroom photo">
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="group relative block aspect-video w-full overflow-hidden rounded-xl border border-dashed border-line2"
              >
                <ImgWithFallback src={draft.showImg} alt="showroom" letter="S" className="h-full w-full object-cover" />
                <span className="absolute inset-0 grid place-items-center bg-black/45 opacity-0 transition-opacity group-hover:opacity-100">
                  <ImagePlus className="h-5 w-5 text-white" aria-hidden />
                </span>
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (f) setDraft({ ...draft, showImg: await readFileAsDataURL(f) });
                  e.target.value = "";
                }}
              />
            </Field>
            <Field label="Or pick from pool">
              <select
                className={inputCls}
                value=""
                onChange={(e) => {
                  const [k, i] = e.target.value.split(":");
                  if (k) setDraft({ ...draft, showImg: pick(POOLS[k as keyof typeof POOLS], Number(i)) });
                }}
              >
                <option value="">Choose…</option>
                {poolKeys.map((k) =>
                  POOLS[k].map((_, i) => (
                    <option key={`${k}:${i}`} value={`${k}:${i}`}>
                      {k} #{i + 1}
                    </option>
                  ))
                )}
              </select>
            </Field>
          </div>

          <div className="grid gap-3">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Name">
                <input className={inputCls} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="Vendor name" />
              </Field>
              <Field label="Tier">
                <select className={inputCls} value={draft.tier} onChange={(e) => setDraft({ ...draft, tier: e.target.value as Vendor["tier"] })}>
                  {["Platinum", "Gold", "Silver", "Verified"].map((t) => (
                    <option key={t}>{t}</option>
                  ))}
                </select>
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Sector">
                <select className={inputCls} value={draft.sector} onChange={(e) => setDraft({ ...draft, sector: e.target.value as Vendor["sector"] })}>
                  {SECTORS.map((s) => (
                    <option key={s.key} value={s.key}>{s.label}</option>
                  ))}
                </select>
              </Field>
              <Field label="Hotline">
                <input className={inputCls} value={draft.hotline} onChange={(e) => setDraft({ ...draft, hotline: e.target.value })} />
              </Field>
            </div>
            <Field label="Website URL">
              <input className={inputCls} dir="ltr" value={draft.website} onChange={(e) => setDraft({ ...draft, website: e.target.value })} />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Record type">
                <select className={inputCls} value={draft.entityKind ?? "marketplace"} onChange={(e) => setDraft({ ...draft, entityKind: e.target.value as Vendor["entityKind"] })}>
                  <option value="official">Official brand/profile</option>
                  <option value="marketplace">Directory/marketplace source</option>
                  <option value="research">Research candidate</option>
                  <option value="manufacturer">Manufacturer/B2B</option>
                  <option value="service">Service</option>
                </select>
              </Field>
              <Field label="Made-in-Egypt status">
                <select className={inputCls} value={draft.madeInEgypt ?? "unverified"} onChange={(e) => setDraft({ ...draft, madeInEgypt: e.target.value as Vendor["madeInEgypt"] })}>
                  <option value="verified">Verified official evidence</option>
                  <option value="claimed">Brand claims it</option>
                  <option value="unverified">Unverified</option>
                </select>
              </Field>
              <Field label="Link status">
                <select className={inputCls} value={draft.linkStatus ?? "unverified"} onChange={(e) => setDraft({ ...draft, linkStatus: e.target.value as Vendor["linkStatus"] })}>
                  <option value="fresh">Verified fresh</option>
                  <option value="stale">Needs recheck</option>
                  <option value="unverified">Unverified</option>
                </select>
              </Field>
              <Field label="Price status">
                <select className={inputCls} value={draft.priceStatus ?? "unverified"} onChange={(e) => setDraft({ ...draft, priceStatus: e.target.value as Vendor["priceStatus"] })}>
                  <option value="fresh">Checked from source</option>
                  <option value="stale">Needs recheck</option>
                  <option value="unverified">Unverified</option>
                </select>
              </Field>
            </div>
            <Field label="Official catalogue URL">
              <input className={inputCls} dir="ltr" value={draft.catalogUrl ?? ""} onChange={(e) => setDraft({ ...draft, catalogUrl: e.target.value })} placeholder="Verified official product page only" />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Official Instagram">
                <input className={inputCls} dir="ltr" value={draft.socials?.instagram ?? ""} onChange={(e) => setDraft({ ...draft, socials: { ...draft.socials, instagram: e.target.value || undefined } })} placeholder="https://instagram.com/..." />
              </Field>
              <Field label="Official Facebook">
                <input className={inputCls} dir="ltr" value={draft.socials?.facebook ?? ""} onChange={(e) => setDraft({ ...draft, socials: { ...draft.socials, facebook: e.target.value || undefined } })} placeholder="https://facebook.com/..." />
              </Field>
              <Field label="Official TikTok">
                <input className={inputCls} dir="ltr" value={draft.socials?.tiktok ?? ""} onChange={(e) => setDraft({ ...draft, socials: { ...draft.socials, tiktok: e.target.value || undefined } })} placeholder="https://tiktok.com/@..." />
              </Field>
              <Field label="Official YouTube">
                <input className={inputCls} dir="ltr" value={draft.socials?.youtube ?? ""} onChange={(e) => setDraft({ ...draft, socials: { ...draft.socials, youtube: e.target.value || undefined } })} placeholder="https://youtube.com/..." />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Maps query">
                <input className={inputCls} value={draft.mapQuery} onChange={(e) => setDraft({ ...draft, mapQuery: e.target.value })} />
              </Field>
              <Field label="Exact Google Maps URL">
                <input className={inputCls} dir="ltr" value={draft.mapUrl ?? ""} onChange={(e) => setDraft({ ...draft, mapUrl: e.target.value || undefined })} placeholder="Official maps.app.goo.gl link" />
              </Field>
              <Field label="Verified WhatsApp number">
                <input className={inputCls} dir="ltr" value={draft.whatsapp ?? ""} onChange={(e) => setDraft({ ...draft, whatsapp: e.target.value.replace(/\D/g, "") || undefined })} placeholder="201234567890" />
              </Field>
              <Field label="Reel video">
                <input
                  className={inputCls}
                  dir="ltr"
                  value={draft.videoUrl}
                  onChange={(e) => setDraft({ ...draft, videoUrl: e.target.value })}
                  placeholder="Audited direct MP4 URL only"
                />
              </Field>
            </div>
            <Field label="About">
              <textarea className={cn(inputCls, "min-h-[64px]")} value={draft.about} onChange={(e) => setDraft({ ...draft, about: e.target.value })} placeholder="Shown on the Visit tab" />
            </Field>
            <label className="flex items-center gap-2 text-xs font-semibold text-fg2">
              <input type="checkbox" checked={!draft.hidden} onChange={(e) => setDraft({ ...draft, hidden: !e.target.checked })} className="h-4 w-4 accent-[var(--c-brand)]" />
              Visible on the site
            </label>
          </div>
        </div>

        <div className="mt-6 flex items-center gap-2.5">
          <button
            type="button"
            disabled={!draft.name.trim()}
            onClick={() => {
              const hasSocial = Object.values(draft.socials ?? {}).some(Boolean);
              const hasOfficialLink = Boolean(draft.website && draft.linkStatus === "fresh");
              upsertVendor({
                ...draft,
                name: draft.name.trim(),
                linksAuditedAt: hasSocial || hasOfficialLink ? new Date().toISOString().slice(0, 7) : undefined,
              });
              onClose();
            }}
            className="rounded-full bg-gradient-to-r from-brand to-brand-deep px-6 py-2.5 text-sm font-bold text-onbrand transition-all hover:brightness-110 disabled:opacity-40"
          >
            Save vendor
          </button>
          <button type="button" onClick={onClose} className="ms-auto rounded-full border border-line px-5 py-2.5 text-sm font-semibold text-fg2 hover:text-fg">
            Cancel
          </button>
        </div>
      </div>
    </Modal>
  );
}

/* --------------------------------- panels --------------------------------- */

function Toolbar({ children }: { children: React.ReactNode }) {
  return <div className="mb-4 flex flex-wrap items-center gap-2">{children}</div>;
}

function ImportBtn({ onData }: { onData: (v: unknown) => void }) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <>
      <button
        type="button"
        onClick={() => ref.current?.click()}
        className="inline-flex items-center gap-1.5 rounded-full border border-line bg-elev/70 px-3.5 py-2 text-[11px] font-bold text-fg2 transition-colors hover:border-brand/50 hover:text-fg"
      >
        <Upload className="h-3.5 w-3.5" aria-hidden /> Import
      </button>
      <input
        ref={ref}
        type="file"
        accept="application/json"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          if (f) onData(await importJSONFile(f));
          e.target.value = "";
        }}
      />
    </>
  );
}

function VendorsPanel() {
  const { db, removeVendor, reorderVendor, toggleVendorHidden, setSectorHidden, toast, importList } = useStore();
  const [q, setQ] = useState("");
  const [sector, setSector] = useState<string>("all");
  const [quality, setQuality] = useState("all");
  const [editing, setEditing] = useState<Vendor | null>(null);
  const [open, setOpen] = useState(false);

  const list = useMemo(() => {
    let vs = [...db.vendors].sort((a, b) => a.order - b.order);
    if (sector !== "all") vs = vs.filter((v) => v.sector === sector);
    if (quality === "website") vs = vs.filter((v) => !vendorHost(v.website));
    if (quality === "social") vs = vs.filter((v) => !Object.values(v.socials ?? {}).some(Boolean));
    if (quality === "whatsapp") vs = vs.filter((v) => !v.whatsapp);
    if (quality === "map") vs = vs.filter((v) => !v.mapUrl && !v.mapQuery);
    if (quality === "review") vs = vs.filter((v) => (v.linkStatus ?? "unverified") !== "fresh");
    const query = q.trim().toLowerCase();
    if (query) vs = vs.filter((v) => v.name.toLowerCase().includes(query));
    return vs;
  }, [db.vendors, q, sector, quality]);

  return (
    <div>
      <Toolbar>
        <div className="relative">
          <Search className="absolute start-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-fg3" aria-hidden />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search vendors…" className={cn(inputCls, "w-48 rounded-full ps-9 text-xs")} />
        </div>
        <select value={sector} onChange={(e) => setSector(e.target.value)} className={cn(inputCls, "w-40 rounded-full text-xs")}>
          <option value="all">All sectors</option>
          {SECTORS.map((s) => (
            <option key={s.key} value={s.key}>{s.label}</option>
          ))}
        </select>
        <select value={quality} onChange={(e) => setQuality(e.target.value)} className={cn(inputCls, "w-44 rounded-full text-xs")}>
          <option value="all">All data states</option>
          <option value="website">Missing official site</option>
          <option value="social">Missing audited socials</option>
          <option value="whatsapp">Missing WhatsApp</option>
          <option value="map">Missing exact map</option>
          <option value="review">Needs link review</option>
        </select>
        <button
          type="button"
          onClick={() => { setEditing(null); setOpen(true); }}
          className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-brand to-brand-deep px-4 py-2 text-[11px] font-bold text-onbrand transition-all hover:brightness-110"
        >
          <Plus className="h-3.5 w-3.5" aria-hidden /> Add brand
        </button>
        <span className="ms-auto flex gap-2">
          <button
            type="button"
            onClick={() => downloadJSON("iroopa-vendors.json", db.vendors)}
            className="inline-flex items-center gap-1.5 rounded-full border border-line bg-elev/70 px-3.5 py-2 text-[11px] font-bold text-fg2 transition-colors hover:border-brand/50 hover:text-fg"
          >
            <Download className="h-3.5 w-3.5" aria-hidden /> Export
          </button>
          <ImportBtn
            onData={(v) => {
              if (Array.isArray(v)) toast(`Imported ${importList("vendors", v)} vendors`, "info");
            }}
          />
        </span>
      </Toolbar>

      {/* sector visibility strip */}
      <div className="no-scrollbar -mx-1 mb-4 flex gap-1.5 overflow-x-auto px-1 pb-1">
        {SECTORS.map((s) => {
          const hidden = !!db.sectorsHidden[s.key];
          return (
            <button
              key={s.key}
              type="button"
              onClick={() => setSectorHidden(s.key, !hidden)}
              className={cn(
                "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[10px] font-bold transition-all",
                hidden ? "border-line text-fg3 line-through opacity-60" : "border-brand/30 bg-brand/[0.07] text-fg"
              )}
            >
              {hidden ? <EyeOff className="h-3 w-3" aria-hidden /> : <Eye className="h-3 w-3 text-brand" aria-hidden />}
              {s.label}
            </button>
          );
        })}
      </div>

      <div className="space-y-2">
        {list.map((v) => (
          <div key={v.id} className={cn("flex items-center gap-3 rounded-2xl border border-line bg-panel p-2.5", v.hidden && "opacity-55")}>
            <VendorLogo vendor={v} size={38} />
            <div className="h-10 w-14 overflow-hidden rounded-lg">
              <ImgWithFallback src={v.showImg} alt={v.name} letter={v.name[0]} hue={v.logoHue} className="h-full w-full object-cover" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-bold text-fg">{v.name}</p>
              <p className="truncate text-[10px] text-fg3">
                {sectorLabel(v.sector)} · {v.tier} · {v.hotline || "No verified phone"} · {v.linkStatus ?? "unverified"}
              </p>
            </div>
            <button type="button" onClick={() => reorderVendor(v.id, -1)} aria-label="Move up" className="grid h-7 w-7 place-items-center rounded-lg border border-line text-fg3 hover:text-fg">
              <ArrowUp className="h-3.5 w-3.5" />
            </button>
            <button type="button" onClick={() => reorderVendor(v.id, 1)} aria-label="Move down" className="grid h-7 w-7 place-items-center rounded-lg border border-line text-fg3 hover:text-fg">
              <ArrowDown className="h-3.5 w-3.5" />
            </button>
            <button type="button" onClick={() => toggleVendorHidden(v.id)} aria-label="Toggle visibility" className="grid h-7 w-7 place-items-center rounded-lg border border-line text-fg3 hover:text-fg">
              {v.hidden ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
            </button>
            <button
              type="button"
              onClick={() => { setEditing(v); setOpen(true); }}
              className="grid h-7 w-7 place-items-center rounded-lg border border-line text-fg3 hover:border-brand/40 hover:text-brand"
              aria-label={`Edit ${v.name}`}
            >
              <Pencil className="h-3.5 w-3.5" />
            </button>
            <TwoStepDelete onConfirm={() => removeVendor(v.id)} />
          </div>
        ))}
        {list.length === 0 && <p className="py-10 text-center text-xs text-fg3">No vendors match this filter.</p>}
      </div>

      <VendorDialog open={open} onClose={() => setOpen(false)} vendor={editing} />
    </div>
  );
}

function CategoriesPanel() {
  const { db, upsertCategory, removeCategory, toggleCategoryHidden, upsertSubcategory, removeSubcategory, toggleSubHidden, toast, importList } = useStore();
  const [selected, setSelected] = useState<string>(db.categories[0]?.id ?? "");
  const [newCat, setNewCat] = useState("");
  const [newSub, setNewSub] = useState("");
  const fileRefs = useRef<Record<string, HTMLInputElement | null>>({});
  const cat = db.categories.find((c) => c.id === selected);

  return (
    <div>
      <Toolbar>
        <span className="text-xs font-bold text-fg2">Manage catalogue hierarchy</span>
        <span className="ms-auto flex gap-2">
          <button
            type="button"
            onClick={() => downloadJSON("iroopa-categories.json", { categories: db.categories, subcategories: db.subcategories })}
            className="inline-flex items-center gap-1.5 rounded-full border border-line bg-elev/70 px-3.5 py-2 text-[11px] font-bold text-fg2 hover:border-brand/50 hover:text-fg"
          >
            <Download className="h-3.5 w-3.5" aria-hidden /> Export
          </button>
          <ImportBtn
            onData={(raw) => {
              const v = raw as { categories?: unknown[]; subcategories?: unknown[] };
              let n = 0;
              if (Array.isArray(v?.categories)) n += importList("categories", v.categories);
              if (Array.isArray(v?.subcategories)) n += importList("subcategories", v.subcategories);
              toast(`Imported ${n} rows`, "info");
            }}
          />
        </span>
      </Toolbar>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* categories */}
        <div className="rounded-2xl border border-line bg-panel p-4">
          <p className="mb-3 text-[11px] font-bold uppercase tracking-widest text-fg3">Categories · {db.categories.length}</p>
          <div className="max-h-[52dvh] space-y-2 overflow-y-auto pe-1">
            {db.categories.map((c) => (
              <div key={c.id} className={cn("flex items-center gap-2.5 rounded-xl border p-2 transition-colors", selected === c.id ? "border-brand/50 bg-brand/[0.06]" : "border-line bg-elev/40", c.hidden && "opacity-55")}>
                <div role="button" tabIndex={0} onClick={() => setSelected(c.id)} onKeyDown={(e) => e.key === "Enter" && setSelected(c.id)} className="flex min-w-0 flex-1 cursor-pointer items-center gap-2.5 text-start">
                  <span className="h-9 w-12 shrink-0 overflow-hidden rounded-lg">
                    <img src={c.image} alt="" loading="lazy" className="h-full w-full object-cover" />
                  </span>
                  <input
                    value={c.name}
                    onChange={(e) => upsertCategory({ ...c, name: e.target.value })}
                    onClick={(e) => e.stopPropagation()}
                    className="w-full rounded-md bg-transparent px-1 py-0.5 text-xs font-bold text-fg outline-none focus:bg-ink/60"
                    aria-label="Category name"
                  />
                </div>
                <button
                  type="button"
                  title="Replace image"
                  onClick={() => fileRefs.current[c.id]?.click()}
                  className="grid h-7 w-7 place-items-center rounded-lg border border-line text-fg3 hover:text-brand"
                >
                  <ImagePlus className="h-3.5 w-3.5" />
                </button>
                <input
                  ref={(el) => { fileRefs.current[c.id] = el; }}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (f) upsertCategory({ ...c, image: await readFileAsDataURL(f) });
                    e.target.value = "";
                  }}
                />
                <button type="button" onClick={() => toggleCategoryHidden(c.id)} className="grid h-7 w-7 place-items-center rounded-lg border border-line text-fg3 hover:text-fg" aria-label="Toggle visibility">
                  {c.hidden ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
                <TwoStepDelete onConfirm={() => removeCategory(c.id)} />
              </div>
            ))}
          </div>
          <div className="mt-3 flex gap-2">
            <input value={newCat} onChange={(e) => setNewCat(e.target.value)} placeholder="New category name…" className={cn(inputCls, "text-xs")} />
            <button
              type="button"
              disabled={!newCat.trim()}
              onClick={() => {
                upsertCategory({
                  id: `c-custom-${Date.now()}`,
                  name: newCat.trim(),
                  slug: newCat.trim().toLowerCase().replace(/\s+/g, "-"),
                  image: pick(POOLS.ecommerce, db.categories.length),
                  hidden: false,
                  order: db.categories.length,
                });
                setNewCat("");
                toast("Category added");
              }}
              className="shrink-0 rounded-xl bg-gradient-to-r from-brand to-brand-deep px-4 text-xs font-bold text-onbrand disabled:opacity-40"
            >
              <Plus className="h-4 w-4" aria-hidden />
            </button>
          </div>
        </div>

        {/* subcategories */}
        <div className="rounded-2xl border border-line bg-panel p-4">
          <p className="mb-3 flex items-center gap-2 text-[11px] font-bold uppercase tracking-widest text-fg3">
            Subcategories
            <span className="inline-flex items-center gap-1 rounded-full border border-brand/30 px-2 py-0.5 text-[9px] font-bold normal-case tracking-normal text-brand">
              {cat?.name ?? "—"} <ChevronDown className="h-2.5 w-2.5" aria-hidden />
            </span>
          </p>
          <div className="max-h-[52dvh] space-y-2 overflow-y-auto pe-1">
            {db.subcategories.filter((s) => s.catId === selected).map((s) => (
              <div key={s.id} className={cn("flex items-center gap-2.5 rounded-xl border border-line bg-elev/40 p-2", s.hidden && "opacity-55")}>
                <input
                  value={s.name}
                  onChange={(e) => upsertSubcategory({ ...s, name: e.target.value })}
                  className="w-full rounded-md bg-transparent px-1 py-0.5 text-xs font-bold text-fg outline-none focus:bg-ink/60"
                  aria-label="Subcategory name"
                />
                <button type="button" onClick={() => toggleSubHidden(s.id)} className="grid h-7 w-7 place-items-center rounded-lg border border-line text-fg3 hover:text-fg" aria-label="Toggle visibility">
                  {s.hidden ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
                <TwoStepDelete onConfirm={() => removeSubcategory(s.id)} />
              </div>
            ))}
          </div>
          <div className="mt-3 flex gap-2">
            <input value={newSub} onChange={(e) => setNewSub(e.target.value)} placeholder="New subcategory…" className={cn(inputCls, "text-xs")} />
            <button
              type="button"
              disabled={!newSub.trim() || !selected}
              onClick={() => {
                upsertSubcategory({
                  id: `s-custom-${Date.now()}`,
                  catId: selected,
                  name: newSub.trim(),
                  hidden: false,
                  order: db.subcategories.filter((s) => s.catId === selected).length,
                });
                setNewSub("");
                toast("Subcategory added");
              }}
              className="shrink-0 rounded-xl bg-gradient-to-r from-brand to-brand-deep px-4 text-xs font-bold text-onbrand disabled:opacity-40"
            >
              <Plus className="h-4 w-4" aria-hidden />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ProductsPanel() {
  const { db, toggleProductHidden, removeProduct, toast, importList } = useStore();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const [shown, setShown] = useState(20);
  const [editing, setEditing] = useState<any>(null);
  const [open, setOpen] = useState(false);

  const list = useMemo(() => {
    let ps = db.products;
    if (cat !== "all") ps = ps.filter((p) => p.catId === cat);
    const query = q.trim().toLowerCase();
    if (query) ps = ps.filter((p) => p.name.toLowerCase().includes(query));
    return ps;
  }, [db.products, q, cat]);

  return (
    <div>
      <Toolbar>
        <div className="relative">
          <Search className="absolute start-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-fg3" aria-hidden />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products…" className={cn(inputCls, "w-48 rounded-full ps-9 text-xs")} />
        </div>
        <select value={cat} onChange={(e) => setCat(e.target.value)} className={cn(inputCls, "w-44 rounded-full text-xs")}>
          <option value="all">All categories</option>
          {db.categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
        <button
          type="button"
          onClick={() => { setEditing(null); setOpen(true); }}
          className="inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-brand to-brand-deep px-4 py-2 text-[11px] font-bold text-onbrand hover:brightness-110"
        >
          <Plus className="h-3.5 w-3.5" aria-hidden /> Add product
        </button>
        <span className="ms-auto flex gap-2">
          <button
            type="button"
            onClick={() => downloadJSON("iroopa-products.json", db.products)}
            className="inline-flex items-center gap-1.5 rounded-full border border-line bg-elev/70 px-3.5 py-2 text-[11px] font-bold text-fg2 hover:border-brand/50 hover:text-fg"
          >
            <Download className="h-3.5 w-3.5" aria-hidden /> Export
          </button>
          <ImportBtn
            onData={(v) => {
              if (Array.isArray(v)) toast(`Imported ${importList("products", v)} products`, "info");
            }}
          />
        </span>
      </Toolbar>

      <div className="space-y-2">
        {list.slice(0, shown).map((p) => {
          const vendor = db.vendors.find((v) => v.id === p.vendorId);
          return (
            <div key={p.id} className={cn("flex items-center gap-3 rounded-2xl border border-line bg-panel p-2.5", p.hidden && "opacity-55")}>
              <div className="h-11 w-14 shrink-0 overflow-hidden rounded-lg">
                <ImgWithFallback src={p.img} alt={p.name} letter={p.name[0]} className="h-full w-full object-cover" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-bold text-fg">{p.name}</p>
                <p className="truncate text-[10px] text-fg3">{vendor?.name ?? "—"} · {db.categories.find((c) => c.id === p.catId)?.name}</p>
              </div>
              <p className="hidden shrink-0 text-xs font-bold text-brand sm:block">{fmtEGP(p.sale ?? p.price)}</p>
              <button type="button" onClick={() => toggleProductHidden(p.id)} className="grid h-7 w-7 place-items-center rounded-lg border border-line text-fg3 hover:text-fg" aria-label="Toggle visibility">
                {p.hidden ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
              </button>
              <button
                type="button"
                onClick={() => { setEditing(p); setOpen(true); }}
                className="grid h-7 w-7 place-items-center rounded-lg border border-line text-fg3 hover:border-brand/40 hover:text-brand"
                aria-label={`Edit ${p.name}`}
              >
                <Pencil className="h-3.5 w-3.5" />
              </button>
              <TwoStepDelete onConfirm={() => removeProduct(p.id)} />
            </div>
          );
        })}
      </div>
      {shown < list.length && (
        <div className="mt-4 text-center">
          <button type="button" onClick={() => setShown((s) => s + 20)} className="rounded-full border border-line bg-elev/70 px-6 py-2 text-xs font-bold text-fg hover:border-brand/50">
            Show more ({list.length - shown} left)
          </button>
        </div>
      )}
      <ProductDialog open={open} onClose={() => setOpen(false)} product={editing} />
    </div>
  );
}

/* ------------------------------- themes panel ------------------------------ */

const COLOR_KEYS: { key: string; label: string }[] = [
  { key: "brand", label: "Brand" },
  { key: "accent", label: "Accent" },
  { key: "ink", label: "Background" },
  { key: "fg", label: "Foreground" },
  { key: "violet", label: "Violet" },
  { key: "gold", label: "Gold" },
];

function cssVarFor(themeId: ThemeId, token: string): string {
  const el = document.querySelector(`[data-ht="${themeId}"]`);
  if (el) {
    const v = getComputedStyle(el).getPropertyValue(`--c-${token}`).trim();
    if (v) return v;
  }
  const probe = document.createElement("div");
  probe.setAttribute("data-ht", themeId);
  probe.style.display = "none";
  document.body.appendChild(probe);
  const v = getComputedStyle(probe).getPropertyValue(`--c-${token}`).trim();
  probe.remove();
  return v || "#34d399";
}

function ThemesPanel() {
  const { db, setActiveTheme, saveOverride, resetOverride, toast } = useStore();
  const [themeId, setThemeId] = useState<ThemeId>(db.activeTheme);
  const override = db.overrides[themeId];
  const def = themeById(themeId);

  const [copyA, setCopyA] = useState("");
  const [copyB, setCopyB] = useState("");
  const [copySub, setCopySub] = useState("");
  const [spotK, setSpotK] = useState("");
  const [spotT, setSpotT] = useState("");
  const [spotD, setSpotD] = useState("");
  const [spotImg, setSpotImg] = useState("");
  const [colors, setColors] = useState<Record<string, string>>({});
  const [featured, setFeatured] = useState<string[]>([]);

  useEffect(() => {
    setCopyA(override?.copy?.a ?? def.copy.a);
    setCopyB(override?.copy?.b ?? def.copy.b);
    setCopySub(override?.copy?.sub ?? def.copy.sub);
    setSpotK(override?.spotlight?.kicker ?? def.spotlight.kicker);
    setSpotT(override?.spotlight?.title ?? def.spotlight.title);
    setSpotD(override?.spotlight?.desc ?? def.spotlight.desc);
    setSpotImg(override?.spotlight?.img ?? "");
    const c: Record<string, string> = {};
    COLOR_KEYS.forEach(({ key }) => (c[key] = override?.colors?.[key] ?? cssVarFor(themeId, key)));
    setColors(c);
    setFeatured(override?.featuredIds ?? []);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [themeId]);

  const toHex = (v: string) => {
    if (v.startsWith("#")) return v.length === 4 ? `#${v[1]}${v[1]}${v[2]}${v[2]}${v[3]}${v[3]}` : v.slice(0, 7);
    return "#34d399";
  };

  const save = () => {
    const o: ThemeOverride = {
      copy: { a: copyA, b: copyB, sub: copySub },
      spotlight: { kicker: spotK, title: spotT, desc: spotD, img: spotImg },
      colors,
      featuredIds: featured.filter(Boolean),
    };
    saveOverride(themeId, o);
  };

  return (
    <div>
      <div className="no-scrollbar -mx-1 mb-5 flex gap-1.5 overflow-x-auto px-1 pb-1">
        {THEMES.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setThemeId(t.id)}
            className={cn(
              "shrink-0 rounded-full border px-4 py-2 text-xs font-bold transition-all",
              themeId === t.id ? "border-transparent bg-gradient-to-r from-brand to-brand-deep text-onbrand" : "border-line bg-elev/60 text-fg2 hover:text-fg"
            )}
          >
            {t.name}
          </button>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="space-y-4 rounded-2xl border border-line bg-panel p-5">
          <p className="text-[11px] font-bold uppercase tracking-widest text-fg3">Palette</p>
          <div className="grid grid-cols-2 gap-3">
            {COLOR_KEYS.map(({ key, label }) => (
              <div key={key} className="flex items-center gap-2.5 rounded-xl border border-line bg-elev/40 p-2.5">
                <input
                  type="color"
                  value={toHex(colors[key] ?? "#34d399")}
                  onChange={(e) => setColors({ ...colors, [key]: e.target.value })}
                  className="h-9 w-11 cursor-pointer rounded-lg border border-line bg-transparent"
                  aria-label={`${label} color`}
                />
                <div className="min-w-0">
                  <p className="text-[11px] font-bold text-fg">{label}</p>
                  <p className="truncate text-[10px] text-fg3" dir="ltr">{colors[key]}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="text-[11px] font-bold uppercase tracking-widest text-fg3">Hero copy</p>
          <div className="grid gap-2.5">
            <div className="grid grid-cols-2 gap-2.5">
              <input className={inputCls} value={copyA} onChange={(e) => setCopyA(e.target.value)} placeholder="Line 1" />
              <input className={inputCls} value={copyB} onChange={(e) => setCopyB(e.target.value)} placeholder="Line 2 (gradient)" />
            </div>
            <textarea className={cn(inputCls, "min-h-[60px] text-xs")} value={copySub} onChange={(e) => setCopySub(e.target.value)} placeholder="Sub-headline (empty = bilingual default)" />
          </div>
        </div>

        <div className="space-y-4 rounded-2xl border border-line bg-panel p-5">
          <p className="text-[11px] font-bold uppercase tracking-widest text-fg3">Spotlight</p>
          <div className="grid gap-2.5">
            <input className={inputCls} value={spotK} onChange={(e) => setSpotK(e.target.value)} placeholder="Kicker" />
            <input className={inputCls} value={spotT} onChange={(e) => setSpotT(e.target.value)} placeholder="Title" />
            <textarea className={cn(inputCls, "min-h-[52px] text-xs")} value={spotD} onChange={(e) => setSpotD(e.target.value)} placeholder="Description" />
            <input className={cn(inputCls, "text-xs")} dir="ltr" value={spotImg} onChange={(e) => setSpotImg(e.target.value)} placeholder="Image URL (empty = theme pool)" />
          </div>
          <p className="text-[11px] font-bold uppercase tracking-widest text-fg3">Featured products (3)</p>
          {[0, 1, 2].map((i) => (
            <select
              key={i}
              className={cn(inputCls, "text-xs")}
              value={featured[i] ?? ""}
              onChange={(e) => {
                const f = [...featured];
                f[i] = e.target.value;
                setFeatured(f);
              }}
            >
              <option value="">Theme default</option>
              {db.products.filter((p) => !p.hidden).slice(0, 60).map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          ))}
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-2.5">
        <button type="button" onClick={save} className="rounded-full bg-gradient-to-r from-brand to-brand-deep px-6 py-2.5 text-sm font-bold text-onbrand transition-all hover:brightness-110">
          Save override
        </button>
        <button
          type="button"
          onClick={() => { save(); setActiveTheme(themeId); window.location.hash = "#/" ; }}
          className="rounded-full border border-line bg-elev/70 px-5 py-2.5 text-sm font-bold text-fg transition-colors hover:border-brand/50"
        >
          Save & preview on home
        </button>
        <button
          type="button"
          onClick={() => { resetOverride(themeId); setThemeId(themeId); toast("Override cleared", "info"); }}
          className="rounded-full border border-line bg-elev/70 px-5 py-2.5 text-sm font-semibold text-fg2 hover:text-fg"
        >
          Reset this theme
        </button>
        <span className="ms-auto flex gap-2">
          <button
            type="button"
            onClick={() => downloadJSON("iroopa-themes.json", db.overrides)}
            className="inline-flex items-center gap-1.5 rounded-full border border-line bg-elev/70 px-3.5 py-2 text-[11px] font-bold text-fg2 hover:text-fg"
          >
            <Download className="h-3.5 w-3.5" aria-hidden /> Export overrides
          </button>
          <ImportBtn
            onData={(raw) => {
              const o = raw as Record<string, ThemeOverride>;
              Object.entries(o ?? {}).forEach(([k, v]) => saveOverride(k as ThemeId, v));
              toast("Theme overrides imported", "info");
            }}
          />
        </span>
      </div>
    </div>
  );
}

function OverviewPanel({ go }: { go: (p: Panel) => void }) {
  const { db } = useStore();
  const stats = [
    { label: "Verified vendors", value: db.vendors.filter((v) => !v.hidden).length, icon: Building2, panel: "vendors" as Panel },
    { label: "Live products", value: db.products.filter((p) => !p.hidden).length, icon: Package, panel: "products" as Panel },
    { label: "Categories", value: db.categories.filter((c) => !c.hidden).length, icon: FolderTree, panel: "categories" as Panel },
    { label: "Home themes", value: THEMES.length, icon: SwatchBook, panel: "themes" as Panel },
  ];

  return (
    <div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <button key={s.label} type="button" onClick={() => go(s.panel)} className="card-surface card-spotlight group rounded-2xl p-5 text-start transition-transform hover:-translate-y-0.5">
              <Icon className="h-5 w-5 text-brand" aria-hidden />
              <p className="mt-3 font-display text-3xl font-bold tabular-nums">{s.value}</p>
              <p className="mt-0.5 text-[11px] text-fg3">{s.label}</p>
            </button>
          );
        })}
      </div>
      <div className="mt-5 rounded-2xl border border-line bg-panel p-5">
        <p className="text-[11px] font-bold uppercase tracking-widest text-fg3">How this dashboard works</p>
        <ul className="mt-3 space-y-2 text-xs leading-relaxed text-fg2">
          <li>· Everything here edits the live storefront instantly — no deploys, no backend.</li>
          <li>· Data persists in this browser via localStorage; use Export → Import to move it between devices.</li>
          <li>· Image fields accept uploads (stored as data URLs) or plain URLs with automatic fallbacks.</li>
          <li>· Hidden vendors, sectors, categories and products disappear from the public site but stay editable here.</li>
        </ul>
      </div>
    </div>
  );
}

/* --------------------------------- the view -------------------------------- */

/* ------------------------------ admin gate ------------------------------- */

const PIN_KEY = "iroopa-admin-pin";
const SESSION_KEY = "iroopa-admin-ok";
const DEFAULT_PIN = "iroopa2026";

const pinHash = (s: string) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h << 5) - h + s.charCodeAt(i);
    h |= 0;
  }
  return String(h);
};

const storedPinHash = () => {
  try {
    return localStorage.getItem(PIN_KEY) ?? pinHash(DEFAULT_PIN);
  } catch {
    return pinHash(DEFAULT_PIN);
  }
};

/**
 * Client-side gate. This is a convenience lock, NOT real security — the app has
 * no server, so the check runs in the browser. Add a server proxy before
 * exposing genuinely sensitive data.
 */
function AdminGate({ onOk }: { onOk: () => void }) {
  const [pin, setPin] = useState("");
  const [error, setError] = useState(false);

  const submit = () => {
    if (pinHash(pin) === storedPinHash()) {
      try {
        sessionStorage.setItem(SESSION_KEY, "1");
      } catch {
        /* private mode */
      }
      onOk();
    } else {
      setError(true);
    }
  };

  return (
    <div className="grid min-h-dvh place-items-center bg-ink px-4 text-fg">
      <div className="w-full max-w-sm">
        <div className="card-surface rounded-3xl p-7">
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand to-accent text-onbrand">
            <Lock className="h-6 w-6" aria-hidden />
          </span>
          <h1 className="mt-5 font-display text-2xl font-bold tracking-tight">Admin console</h1>
          <p className="mt-1 text-xs text-fg3">
            Enter the admin password to manage vendors, products and requests.
          </p>
          <input
            type="password"
            autoFocus
            value={pin}
            onChange={(e) => {
              setPin(e.target.value);
              setError(false);
            }}
            onKeyDown={(e) => e.key === "Enter" && submit()}
            placeholder="Admin password"
            className={cn(
              inputCls,
              "mt-5 text-center tracking-widest",
              error && "border-rose-400/60"
            )}
          />
          {error && (
            <p className="mt-2 text-center text-[11px] font-semibold text-rose-400">
              Incorrect password
            </p>
          )}
          <button
            type="button"
            onClick={submit}
            disabled={!pin}
            className="mt-4 w-full rounded-full bg-gradient-to-r from-brand to-brand-deep py-3 text-sm font-bold text-onbrand transition-all hover:brightness-110 disabled:opacity-40"
          >
            Unlock dashboard
          </button>
          <a
            href="#/"
            className="mt-3 block text-center text-[11px] font-semibold text-fg3 hover:text-fg"
          >
            Back to site
          </a>
        </div>
        <p className="mt-4 text-center text-[10px] leading-relaxed text-fg3/70">
          Browser-side lock only — no server is involved. Change the password below.
        </p>
      </div>
    </div>
  );
}

export function DashboardView({ sub }: { sub?: string }) {
  const [authed, setAuthed] = useState(() => {
    try {
      return sessionStorage.getItem(SESSION_KEY) === "1";
    } catch {
      return false;
    }
  });
  const [panel, setPanel] = useState<Panel>((sub as Panel) || "overview");
  useEffect(() => {
    if (sub && PANELS.some((p) => p.id === sub)) setPanel(sub as Panel);
  }, [sub]);

  const go = (p: Panel) => {
    setPanel(p);
    window.history.replaceState(null, "", p === "overview" ? "#/dashboard" : `#/dashboard/${p}`);
  };

  if (!authed) return <AdminGate onOk={() => setAuthed(true)} />;

  return (
    <div className="min-h-dvh bg-ink text-fg">
      {/* top bar */}
      <header className="glass sticky top-0 z-40 border-b border-line">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:px-6 lg:px-8">
          <a href="#/" aria-label="Back to site"><Logo /></a>
          <span className="ms-2 hidden rounded-full border border-brand/30 bg-brand/10 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-widest text-brand sm:inline">
            Admin console
          </span>
          <a
            href="#/"
            className="ms-auto inline-flex items-center gap-1.5 rounded-full border border-line bg-elev/70 px-4 py-2 text-xs font-bold text-fg2 transition-colors hover:border-brand/50 hover:text-fg"
          >
            <ArrowLeft className="h-3.5 w-3.5 rtl:rotate-180" aria-hidden /> Back to site
          </a>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
          {/* sidebar — untouched layout per requirements */}
          <aside className="no-scrollbar flex gap-2 overflow-x-auto lg:sticky lg:top-20 lg:h-fit lg:flex-col">
            {PANELS.map((p) => {
              const Icon = p.icon;
              const active = panel === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => go(p.id)}
                  className={cn(
                    "flex shrink-0 items-center gap-2.5 rounded-xl border px-4 py-3 text-xs font-bold transition-all lg:w-full",
                    active
                      ? "border-transparent bg-gradient-to-r from-brand to-brand-deep text-onbrand shadow-[0_12px_30px_-10px_color-mix(in_oklab,var(--c-brand)_60%,transparent)]"
                      : "border-line bg-panel text-fg2 hover:border-brand/40 hover:text-fg"
                  )}
                >
                  <Icon className="h-4 w-4" aria-hidden />
                  {p.label}
                </button>
              );
            })}
          </aside>

          <main className="min-w-0">
            <h1 className="mb-5 font-display text-2xl font-bold tracking-tight capitalize">{panel}</h1>
            {panel === "overview" && <OverviewPanel go={go} />}
            {panel === "vendors" && <VendorsPanel />}
            {panel === "intake" && <IntakePanel />}
            {panel === "segments" && <SegmentsPanel />}
            {panel === "links" && <LinksPanel />}
            {panel === "requests" && <RequestsPanel />}
            {panel === "migration" && <MigrationPanel />}
            {panel === "categories" && <CategoriesPanel />}
            {panel === "products" && <ProductsPanel />}
            {panel === "themes" && <ThemesPanel />}
          </main>
        </div>
      </div>
    </div>
  );
}
