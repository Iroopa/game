import type { Lang } from "./i18n";
import { SECTOR_AR, SUB_AR } from "./i18n";
import { fmtEGP, sectorLabel, type CartItem, type DB, type Product, type Vendor } from "./store";
import type {
  ConciergeProfile,
  NeedSchedule,
  SmartResult,
  WritingDocument,
} from "./concierge";
import { generateWriting, looksLikeWritingRequest } from "./writing";

export interface VoiceResult {
  reply: string;
  /** Runs right after Roopa starts speaking. */
  action?: () => void;
}

export interface VoiceDeps {
  db: DB;
  cart: CartItem[];
  cartTotal: number;
  profile: ConciergeProfile;
  addToCart: (id: string, qty?: number) => void;
  openVendor: (v: Vendor) => void;
  filterShop: (catId: string, subId?: string) => void;
  highlight: (selector: string, label: string, kind?: "ok" | "warn") => void;
  goto: (hash: string) => void;
  showResult: (result: SmartResult) => void;
  addSchedule: (
    input: Omit<NeedSchedule, "id" | "createdAt" | "active">
  ) => NeedSchedule;
  updateProfile: (patch: Partial<ConciergeProfile>) => void;
  openPlanner: () => void;
  openWriter: (draft: Omit<WritingDocument, "createdAt">) => void;
}

/* ------------------------------- matching -------------------------------- */

const norm = (s: string) =>
  s
    .toLowerCase()
    .replace(/[أإآ]/g, "ا")
    .replace(/[ىئ]/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/[ًٌٍَُِّْ]/g, "")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();

/** Fuzzy-ish score: how well `needle` appears inside `hay`. */
function score(hay: string, needle: string): number {
  const h = norm(hay);
  const n = norm(needle);
  if (!h || !n) return 0;
  if (h === n) return 1000;
  if (h.includes(n)) return 700 + n.length;
  const words = n.split(" ").filter((w) => w.length > 2);
  if (!words.length) return 0;
  let hits = 0;
  for (const w of words) if (h.includes(w)) hits++;
  if (!hits) return 0;
  return (hits / words.length) * 400 + hits * 20;
}

function best<T>(items: T[], text: string, keys: (it: T) => string[]): { item: T; s: number } | null {
  let top: { item: T; s: number } | null = null;
  for (const it of items) {
    let s = 0;
    for (const k of keys(it)) s = Math.max(s, score(k, text));
    if (s > 0 && (!top || s > top.s)) top = { item: it, s };
  }
  return top && top.s >= 240 ? top : null;
}

/* -------------------------------- phrases -------------------------------- */

const has = (t: string, ...keys: string[]) => {
  const n = norm(t);
  return keys.some((k) => n.includes(norm(k)));
};

const WANT_ORDER = ["order", "buy", "add to cart", "add", "purchase", "اطلب", "اشتري", "ضيف", "اضف", "أضف", "احجز", "عايز اشتري"];
const WANT_SHOW = ["show", "find", "search", "open", "browse", "اعرض", "ابحث", "افتح", "وريني", "عايز اشوف", "دور"];
const WANT_WHERE = ["where", "location", "address", "directions", "map", "فين", "مكان", "عنوان", "الاتجاهات", "الخريطة", "موقع"];
const WANT_CART = ["cart", "basket", "checkout", "السلة", "سلتي", "الدفع", "اتمم"];
const WANT_DASH = ["dashboard", "admin", "console", "لوحة", "التحكم", "الادارة"];
const WANT_THEME = ["theme", "design", "look", "ثيم", "تصميم", "شكل", "الوان"];
const WANT_COMPARE = ["compare", "comparison", "best value", "which is better", "قارن", "مقارنة", "الافضل", "أفضل", "انسب"];
const WANT_TOTAL = ["calculate", "total", "how much", "cost", "sum", "احسب", "الإجمالي", "الاجمالي", "المجموع", "التكلفة", "بكام"];
const WANT_SUMMARY = ["summarize", "summary", "review order", "ملخص", "لخص", "راجع الطلب", "مراجعة الطلب"];
const WANT_SCHEDULE = ["schedule", "remind", "every day", "daily", "جدول", "ذكرني", "تذكير", "كل يوم", "يوميا", "يوميًا", "موعد"];

function mentions<T>(items: T[], text: string, keys: (it: T) => string[]): T[] {
  const n = norm(text);
  return items
    .map((item) => {
      let rank = 0;
      for (const key of keys(item)) {
        const k = norm(key);
        if (k.length > 2 && n.includes(k)) rank = Math.max(rank, 1000 + k.length);
        const words = k.split(" ").filter((w) => w.length > 3);
        const hits = words.filter((w) => n.includes(w)).length;
        if (hits >= 2 || (words.length === 1 && hits === 1)) rank = Math.max(rank, hits * 160);
      }
      return { item, rank };
    })
    .filter((x) => x.rank > 0)
    .sort((a, b) => b.rank - a.rank)
    .map((x) => x.item);
}

function cartLines(db: DB, cart: CartItem[]) {
  return cart
    .map((line) => {
      const product = db.products.find((p) => p.id === line.productId);
      const vendor = product ? db.vendors.find((v) => v.id === product.vendorId) : undefined;
      return product ? { line, product, vendor } : null;
    })
    .filter(Boolean) as { line: CartItem; product: Product; vendor?: Vendor }[];
}

function westernDigits(s: string) {
  const ar = "٠١٢٣٤٥٦٧٨٩";
  return s.replace(/[٠-٩]/g, (d) => String(ar.indexOf(d)));
}

function parseTime(text: string): string {
  const clean = westernDigits(text.toLowerCase().replace(/[أإآ]/g, "ا"));
  const matches = [...clean.matchAll(/(?:at|الساعة|الساعه)?\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm|ص|م)?/g)];
  const match = matches.reverse().find((m) => Number(m[1]) <= 23);
  if (!match) return "09:00";
  let hour = Number(match[1]);
  const minute = Number(match[2] ?? 0);
  const marker = match[3];
  if ((marker === "pm" || marker === "م") && hour < 12) hour += 12;
  if ((marker === "am" || marker === "ص") && hour === 12) hour = 0;
  return `${String(hour).padStart(2, "0")}:${String(Math.min(59, minute)).padStart(2, "0")}`;
}

function parseQuantity(text: string): number {
  const clean = westernDigits(text.toLowerCase());
  const match = clean.match(/(?:order|buy|add|purchase|اطلب|اشتري|ضيف|اضف|أضف)\s+(\d{1,2})/i);
  return match ? Math.max(1, Math.min(50, Number(match[1]))) : 1;
}

function parseBudget(text: string): number | null {
  if (!has(text, "under", "less than", "budget", "below", "اقل من", "أقل من", "ميزانيه", "ميزانية", "تحت")) return null;
  const nums = westernDigits(text).match(/\d[\d,]*/g)?.map((n) => Number(n.replace(/,/g, ""))).filter(Number.isFinite);
  return nums?.length ? Math.max(...nums) : null;
}

function arithmetic(text: string): { expression: string; value: number } | null {
  const converted = westernDigits(text.toLowerCase())
    .replace(/multiplied by|times|ضرب في|في/gi, "*")
    .replace(/divided by|over|مقسوم على|على/gi, "/")
    .replace(/plus|زائد/gi, "+")
    .replace(/minus|ناقص/gi, "-");
  const expression = converted.match(/-?\d+(?:\.\d+)?(?:\s*[+\-*/]\s*-?\d+(?:\.\d+)?)+/)?.[0];
  if (!expression) return null;
  const tokens = expression.match(/-?\d+(?:\.\d+)?|[+\-*/]/g);
  if (!tokens?.length) return null;
  const nums: number[] = [];
  const ops: string[] = [];
  const apply = () => {
    const b = nums.pop();
    const a = nums.pop();
    const op = ops.pop();
    if (a === undefined || b === undefined || !op) return false;
    if (op === "/" && b === 0) return false;
    nums.push(op === "+" ? a + b : op === "-" ? a - b : op === "*" ? a * b : a / b);
    return true;
  };
  const precedence = (op: string) => (op === "*" || op === "/" ? 2 : 1);
  for (const token of tokens) {
    if (/^-?\d/.test(token)) nums.push(Number(token));
    else {
      while (ops.length && precedence(ops[ops.length - 1]) >= precedence(token)) {
        if (!apply()) return null;
      }
      ops.push(token);
    }
  }
  while (ops.length) if (!apply()) return null;
  const value = nums[0];
  return Number.isFinite(value) ? { expression, value } : null;
}

function spokenName(profile: ConciergeProfile, ar: boolean) {
  const value = profile.userName.trim();
  if (!value || value.toLowerCase() === "friend") return "";
  return ar ? ` يا ${value}` : `, ${value}`;
}

/* ------------------------------- resolution ------------------------------ */

export function resolveVoice(text: string, lang: Lang, d: VoiceDeps): VoiceResult | null {
  const ar = lang === "ar";
  const { db } = d;
  const live = db.products.filter((p) => !p.hidden);
  const vendors = db.vendors.filter((v) => !v.hidden);
  const officialLive = live.filter((p) => {
    const v = db.vendors.find((x) => x.id === p.vendorId);
    return v?.entityKind === "official" || v?.entityKind === "manufacturer" || p.provenance?.sourceLabel;
  });
  const trustedProducts = officialLive.length
    ? [...officialLive, ...live.filter((p) => !officialLive.some((x) => x.id === p.id))]
    : live;

  /* strip command words so names match better */
  const stripped = norm(text)
    .replace(/\b(order|buy|add to cart|add|show me|show|find|search|open|where is|where|please|i want|get me)\b/g, "")
    .replace(/(اطلب|اشتري|ضيف|اضف|أضف|اعرض لي|اعرض|ابحث عن|ابحث|افتح|وريني|عايز|عاوز|من فضلك|فين|مكان)/g, "")
    .trim();
  const probe = stripped.length > 2 ? stripped : text;
  const address = spokenName(d.profile, ar);

  /* --------------------------- personalization ------------------------- */
  const userNameMatch = ar
    ? text.match(/(?:اسمي|ناديني|قولي لي)\s+([\p{L}]{2,20})/u)
    : text.match(/(?:my name is|call me)\s+([a-z][a-z -]{1,24})/i);
  if (userNameMatch?.[1]) {
    const userName = userNameMatch[1].trim();
    return {
      reply: ar
        ? `تشرفت يا ${userName}. هاناديك بالاسم ده من دلوقتي.`
        : `Nice to meet you, ${userName}. I'll remember that from now on.`,
      action: () => d.updateProfile({ userName }),
    };
  }
  const assistantNameMatch = ar
    ? text.match(/(?:اسمك|هسميكي|سأسميك)\s+([\p{L}]{2,20})/u)
    : text.match(/(?:your name is|i will call you|call yourself)\s+([a-z][a-z -]{1,24})/i);
  if (assistantNameMatch?.[1]) {
    const assistantName = assistantNameMatch[1].trim();
    return {
      reply: ar
        ? `تمام. اسمي ${assistantName} من دلوقتي.`
        : `Perfect. You can call me ${assistantName} from now on.`,
      action: () => d.updateProfile({ assistantName }),
    };
  }

  const math = arithmetic(text);
  if (math && has(text, "calculate", "what is", "how much", "احسب", "كام", "ما ناتج")) {
    const formatted = new Intl.NumberFormat(ar ? "ar-EG" : "en-US", { maximumFractionDigits: 4 }).format(math.value);
    return {
      reply: ar ? `الناتج هو ${formatted}${address}.` : `The result is ${formatted}${address}.`,
      action: () => d.showResult({
        kind: "calculation",
        title: ar ? "نتيجة الحساب" : "Calculation result",
        subtitle: `${math.expression} = ${formatted}`,
        items: [],
      }),
    };
  }

  /* --------------------------- writing studio -------------------------- */
  if (looksLikeWritingRequest(text)) {
    const draft = generateWriting(text, lang, d.profile.userName);
    return {
      reply: ar
        ? `كتبت ${draft.title} فورًا${address}. فتحته لك الآن لتعدّله أو تنسخه.`
        : `I wrote ${draft.title} immediately${address}. Opening it now so you can edit or copy it.`,
      action: () => d.openWriter({
        title: draft.title,
        content: draft.content,
        prompt: text,
      }),
    };
  }

  const greetingText = norm(text);
  if (
    ["hello", "hi", "hey", "good morning", "good evening", "مرحبا", "اهلا", "السلام عليكم", "صباح الخير", "مساء الخير"].some(
      (g) => greetingText === norm(g) || greetingText.startsWith(`${norm(g)} `)
    )
  ) {
    return {
      reply: ar
        ? `أهلًا${address}. أنا ${d.profile.assistantName}. أقدر أقارن الأسعار، أحسب طلبك، أوصّلك للموقع والخريطة، وأجدول احتياجاتك اليومية.`
        : `Hello${address}. I'm ${d.profile.assistantName}. I can compare prices, calculate orders, open vendor sites and maps, and schedule your daily needs.`,
      action: () => d.showResult({
        kind: "answer",
        title: ar ? `أهلًا من ${d.profile.assistantName}` : `Hello from ${d.profile.assistantName}`,
        subtitle: ar ? "قل طلبك بطريقتك الطبيعية — ويمكنك التوقف قليلًا أثناء الكلام." : "Ask naturally — you can pause while speaking and continue when ready.",
        items: [
          { id: "compare", label: ar ? "قارن المنتجات والأسعار" : "Compare products and prices", meta: ar ? "مثال: قارن أفضل أجهزة المنزل الذكي" : "Try: compare the best smart-home products" },
          { id: "calculate", label: ar ? "احسب ولخّص السلة" : "Calculate and summarize your cart", meta: ar ? "يعرض تفاصيل الكميات والإجمالي" : "Shows quantities and the calculated total" },
          { id: "schedule", label: ar ? "جدول احتياجًا يوميًا" : "Schedule a daily need", meta: ar ? "مثال: ذكرني كل يوم الساعة ٩" : "Try: remind me every day at 9" },
        ],
      }),
    };
  }

  if (has(text, "what can you do", "help me", "how can you help", "تقدري تعملي ايه", "ماذا تستطيع", "ساعديني", "المساعده", "المساعدة")) {
    return {
      reply: ar
        ? `أقدر أبحث في كل الأقسام والشركاء، أقارن وأحسب، أضيف للسلة، أفتح الموقع والخريطة، وأعمل لك جدول احتياجات مع تنبيهات.`
        : `I can search every category and vendor, compare and calculate, add to cart, open sites and maps, and build a reminder schedule.`,
      action: () => d.showResult({
        kind: "answer",
        title: ar ? "كيف أساعدك؟" : "What I can do",
        items: [
          { id: "one", label: ar ? "بحث ذكي في الكتالوج" : "Smart catalogue search", meta: ar ? "كل الأقسام والمنتجات والشركاء" : "Every category, product and verified partner" },
          { id: "two", label: ar ? "مقارنة وحساب" : "Compare and calculate", meta: ar ? "أفضل قيمة، كميات، وإجمالي" : "Best value, quantities and totals" },
          { id: "three", label: ar ? "تنفيذ موجّه" : "Guided action", meta: ar ? "السلة والموقع والخريطة بدون دفع تلقائي" : "Cart, official site and map — never auto-pays" },
          { id: "four", label: ar ? "جدولة يومية" : "Daily planning", meta: ar ? "تنبيه في الموعد مع تأكيدك قبل الطلب" : "Timed reminder with your approval before ordering" },
        ],
      }),
    };
  }

  /* ------------------------------- clock ------------------------------- */
  if (has(text, "what time", "what day", "today", "الساعة كام", "الوقت", "النهارده", "اليوم")) {
    const now = new Date();
    const value = new Intl.DateTimeFormat(ar ? "ar-EG" : "en-EG", {
      weekday: "long",
      hour: "numeric",
      minute: "2-digit",
    }).format(now);
    return {
      reply: ar ? `الوقت الآن ${value}${address}.` : `It is ${value}${address}.`,
      action: () => d.showResult({
        kind: "answer",
        title: ar ? "الوقت الآن" : "Current time",
        subtitle: value,
        items: [],
      }),
    };
  }

  /* ----------------------------- scheduling --------------------------- */
  if (has(text, ...WANT_SCHEDULE)) {
    const product = mentions<Product>(trustedProducts, text, (p) => [p.name])[0];
    const vendor = mentions<Vendor>(vendors, text, (v) => [v.name])[0];
    const time = parseTime(text);
    const repeat = has(text, "weekday", "workday", "أيام العمل", "ايام العمل")
      ? "weekdays"
      : has(text, "daily", "every day", "كل يوم", "يوميا", "يوميًا")
        ? "daily"
        : "once";
    const title = product
      ? `${ar ? "طلب" : "Order"} ${product.name}`
      : vendor
        ? `${ar ? "مراجعة" : "Check"} ${vendor.name}`
        : ar
          ? "احتياج مجدول"
          : "Scheduled need";
    return {
      reply: ar
        ? `حاضر${address}. هافكّرك بـ ${title} الساعة ${time}${repeat === "daily" ? " يوميًا" : ""}. ولن أنفّذ أي شراء دون تأكيدك.`
        : `Scheduled${address}: ${title} at ${time}${repeat === "daily" ? " every day" : ""}. I will never purchase without your confirmation.`,
      action: () => {
        const schedule = d.addSchedule({
          title,
          time,
          repeat,
          productId: product?.id,
          vendorId: vendor?.id ?? product?.vendorId,
          quantity: 1,
        });
        d.showResult({
          kind: "schedule",
          title: ar ? "تمت الجدولة" : "Need scheduled",
          subtitle: `${title} · ${time}`,
          items: product
            ? [{ id: product.id, label: product.name, image: product.img, productId: product.id, value: fmtEGP(product.sale ?? product.price) }]
            : [],
          note: `${schedule.repeat} · ${ar ? "يتطلب تأكيدك قبل الطلب" : "Requires confirmation before ordering"}`,
        });
      },
    };
  }

  /* ------------------------- compare live offers ----------------------- */
  if (has(text, ...WANT_COMPARE)) {
    const namedProducts = mentions<Product>(trustedProducts, text, (p) => [p.name]);
    const namedVendors = mentions<Vendor>(vendors, text, (v) => [v.name]);
    const category = mentions(db.categories.filter((c) => !c.hidden), text, (c) => [c.name, SECTOR_AR[c.slug] ?? c.name])[0];
    const comparisonBudget = parseBudget(text);
    let candidates = namedProducts;
    if (namedVendors.length) {
      candidates = [...candidates, ...trustedProducts.filter((p) => namedVendors.some((v) => v.id === p.vendorId))];
    }
    if (!candidates.length && category) candidates = trustedProducts.filter((p) => p.catId === category.id);
    if (!candidates.length) candidates = trustedProducts.filter((p) => p.sale !== null);
    if (comparisonBudget !== null) {
      candidates = candidates.filter((p) => (p.sale ?? p.price) <= comparisonBudget);
    }
    candidates = [...new Map(candidates.map((p) => [p.id, p])).values()]
      .sort((a, b) => (a.sale ?? a.price) - (b.sale ?? b.price))
      .slice(0, 4);
    if (candidates.length) {
      const bestValue = candidates[0];
      return {
        reply: ar
          ? `قارنت ${candidates.length} اختيارات${address}. أفضل سعر حاليًا هو ${bestValue.name} بسعر ${fmtEGP(bestValue.sale ?? bestValue.price)}. فتحت لك المقارنة بالتفاصيل.`
          : `I compared ${candidates.length} options${address}. The best current value is ${bestValue.name} at ${fmtEGP(bestValue.sale ?? bestValue.price)}. Opening the full comparison.`,
        action: () => d.showResult({
          kind: "comparison",
          title: ar ? "مقارنة الأسعار والاختيارات" : "Offer comparison",
          subtitle: ar ? "مرتبة من الأقل سعرًا — راجع البائع والتفاصيل قبل الطلب." : "Sorted by current price — review vendor and details before ordering.",
          items: candidates.map((p, index) => {
            const vendor = vendors.find((v) => v.id === p.vendorId);
            return {
              id: p.id,
              label: p.name,
              value: fmtEGP(p.sale ?? p.price),
              meta: vendor?.name,
              image: p.img,
              productId: p.id,
              vendorId: vendor?.id,
              recommended: index === 0,
            };
          }),
          recommendedProductId: bestValue.id,
          note: ar ? "الأسعار من بيانات الدليل وقد تتغير في الموقع الرسمي." : "Directory prices can change; confirm on the official vendor site.",
        }),
      };
    }
  }

  /* ---------------------------- budget finder -------------------------- */
  const budget = parseBudget(text);
  if (budget !== null) {
    const category = mentions(db.categories.filter((c) => !c.hidden), text, (c) => [c.name, SECTOR_AR[c.slug] ?? c.name])[0];
    const choices = live
      .filter((p) => (!category || p.catId === category.id) && (p.sale ?? p.price) <= budget)
      .sort((a, b) => (b.sale ?? b.price) - (a.sale ?? a.price))
      .slice(0, 6);
    return {
      reply: choices.length
        ? ar
          ? `وجدت ${choices.length} اختيارات ضمن ميزانية ${fmtEGP(budget)}${address}. فتحت لك أفضل النتائج.`
          : `I found ${choices.length} options within ${fmtEGP(budget)}${address}. Opening the strongest matches.`
        : ar
          ? `لم أجد اختيارًا حاليًا تحت ${fmtEGP(budget)}. جرّب ميزانية أعلى أو قسمًا آخر.`
          : `I couldn't find a current option under ${fmtEGP(budget)}. Try a higher budget or another category.`,
      action: () => d.showResult({
        kind: "comparison",
        title: ar ? "نتائج ضمن الميزانية" : "Within your budget",
        subtitle: ar ? `حتى ${fmtEGP(budget)}` : `Up to ${fmtEGP(budget)}`,
        items: choices.map((p, i) => ({
          id: p.id,
          label: p.name,
          value: fmtEGP(p.sale ?? p.price),
          image: p.img,
          productId: p.id,
          vendorId: p.vendorId,
          recommended: i === 0,
        })),
        recommendedProductId: choices[0]?.id,
      }),
    };
  }

  /* ----------------------- calculate / summarize cart ------------------- */
  if (has(text, ...WANT_TOTAL) || has(text, ...WANT_SUMMARY)) {
    const lines = cartLines(db, d.cart);
    if (!lines.length) {
      return {
        reply: ar
          ? `سلتك فارغة${address}. قلّي المنتج أو القسم الذي تبحث عنه وسأساعدك في الاختيار.`
          : `Your cart is empty${address}. Tell me a product or category and I'll help you choose.`,
        action: () => d.showResult({
          kind: "calculation",
          title: ar ? "السلة فارغة" : "Your cart is empty",
          subtitle: ar ? "ابدأ بالمقارنة أو ابحث عن منتج." : "Start with a comparison or product search.",
          items: [],
          total: 0,
        }),
      };
    }
    const count = lines.reduce((sum, x) => sum + x.line.qty, 0);
    return {
      reply: ar
        ? `ملخص طلبك${address}: ${count} منتج بإجمالي ${fmtEGP(d.cartTotal)}. فتحت لك الحساب بالتفصيل قبل التأكيد.`
        : `Order summary${address}: ${count} items totaling ${fmtEGP(d.cartTotal)}. Opening the itemized calculation before confirmation.`,
      action: () => d.showResult({
        kind: has(text, ...WANT_SUMMARY) ? "summary" : "calculation",
        title: ar ? "ملخص وحساب الطلب" : "Order calculation",
        subtitle: ar ? `${count} منتج في السلة` : `${count} items in your cart`,
        items: lines.map(({ line, product, vendor }) => ({
          id: product.id,
          label: product.name,
          value: fmtEGP((product.sale ?? product.price) * line.qty),
          meta: `${line.qty} × ${fmtEGP(product.sale ?? product.price)} · ${vendor?.name ?? ""}`,
          image: product.img,
          productId: product.id,
          vendorId: vendor?.id,
        })),
        total: d.cartTotal,
        totalLabel: ar ? "الإجمالي النهائي" : "Calculated total",
        note: ar ? "لا يشمل رسوم الشحن النهائية إن وجدت." : "Final vendor delivery fees, if any, are not included.",
      }),
    };
  }

  /* ------------------------------- cart ------------------------------- */
  if (has(text, ...WANT_CART) && !has(text, ...WANT_ORDER)) {
    return {
      reply: ar
        ? "فتحت لك السلة — راجع الطلب واضغط «أتمم الطلب بالصوت»."
        : "Opening your cart — review the items and hit checkout.",
      action: () => {
        d.highlight("#shop", ar ? "سلة مشترياتك" : "Your cart", "ok");
        window.dispatchEvent(new CustomEvent("iroopa:open-cart"));
      },
    };
  }

  /* ----------------------------- dashboard ---------------------------- */
  if (has(text, ...WANT_DASH)) {
    return {
      reply: ar ? "جاري فتح لوحة التحكم." : "Opening the admin dashboard now.",
      action: () => d.goto("#/dashboard"),
    };
  }
  if (has(text, ...WANT_THEME)) {
    return {
      reply: ar
        ? "فتحت استوديو الثيمات — اختر من سبعة تصاميم."
        : "Opening the Theme Studio — pick from seven concepts.",
      action: () => window.dispatchEvent(new CustomEvent("iroopa:studio")),
    };
  }

  /* ------------------------ whole-site navigation ---------------------- */
  const navigating = has(
    text,
    "go to",
    "navigate",
    "take me to",
    "open",
    "scroll to",
    "اذهب",
    "روح",
    "خدني",
    "افتح",
    "انقلني"
  );
  if (navigating) {
    const destinations = [
      { terms: ["home", "top", "الرئيسية", "البدايه", "البداية"], selector: "#top", label: ar ? "الصفحة الرئيسية" : "Home" },
      { terms: ["assistant", "voice", "roopa", "المساعد", "الصوت", "روبا"], selector: "#demo", label: ar ? "المساعدة الصوتية" : "Voice assistant" },
      { terms: ["services", "features", "الخدمات", "المميزات"], selector: "#services", label: ar ? "الخدمات" : "Services" },
      { terms: ["vendors", "partners", "brands", "الشركاء", "العلامات"], selector: "#vendors", label: ar ? "الشركاء" : "Vendors" },
      { terms: ["categories", "catalogue", "catalog", "الاقسام", "الأقسام", "الدليل"], selector: "#categories", label: ar ? "دليل الأقسام" : "Catalogue" },
      { terms: ["shop", "products", "store", "المتجر", "المنتجات", "السوق"], selector: "#shop", label: ar ? "المتجر" : "Shop" },
      { terms: ["language", "arabic", "english", "اللغة", "العربيه", "العربية", "الانجليزيه"], selector: "#languages", label: ar ? "اللغات" : "Languages" },
    ];
    const target = destinations.find((dest) => dest.terms.some((term) => has(text, term)));
    if (target) {
      return {
        reply: ar ? `حاضر${address}. انتقلت إلى ${target.label}.` : `Done${address}. Taking you to ${target.label}.`,
        action: () => d.highlight(target.selector, target.label, "ok"),
      };
    }
    if (has(text, "showcase", "3d", "ثلاثي", "العرض")) {
      return {
        reply: ar ? "جاري فتح التجربة ثلاثية الأبعاد." : "Opening the 3D showcase.",
        action: () => d.goto("#/showcase"),
      };
    }
  }

  /* ------------------------------ vendor ------------------------------ */
  const vHit = best<Vendor>(vendors, probe, (v) => [v.name]);
  if (vHit) {
    const v = vHit.item;
    const items = live.filter((p) => p.vendorId === v.id);

    if (has(text, ...WANT_WHERE)) {
      return {
        reply: ar
          ? `${v.name} موجود في ${v.mapQuery}. فتحت لك الخريطة داخل صفحة الشريك.`
          : `${v.name} is at ${v.mapQuery}. I've opened their map inside the partner card.`,
        action: () => {
          d.openVendor(v);
          window.setTimeout(() => window.dispatchEvent(new CustomEvent("iroopa:vendor-tab", { detail: "map" })), 420);
        },
      };
    }
    if (has(text, ...WANT_ORDER) && items[0]) {
      const p = items[0];
      const qty = parseQuantity(text);
      return {
        reply: ar
          ? `أضفت ${qty} من ${p.name} من ${v.name} بإجمالي ${fmtEGP((p.sale ?? p.price) * qty)} إلى سلتك. تحب أوريك مكانهم؟`
          : `Added ${qty} × ${p.name} from ${v.name}, totaling ${fmtEGP((p.sale ?? p.price) * qty)}. Want me to show their location?`,
        action: () => {
          d.addToCart(p.id, qty);
          d.showResult({
            kind: "order",
            title: ar ? "تمت إضافة الطلب" : "Order added for review",
            subtitle: ar
              ? "راجع الملخص والموقع قبل التأكيد النهائي."
              : "Review the summary and vendor location before final confirmation.",
            items: [{
              id: p.id,
              label: p.name,
              value: fmtEGP((p.sale ?? p.price) * qty),
              meta: `${qty} × ${fmtEGP(p.sale ?? p.price)} · ${v.name}`,
              image: p.img,
              productId: p.id,
              vendorId: v.id,
            }],
            total: (p.sale ?? p.price) * qty,
            totalLabel: ar ? "قيمة الإضافة" : "Added value",
            note: ar
              ? "اضغط علامة الموقع لفتح صفحة الشريك والخريطة."
              : "Use the location button to open the partner page and map.",
          });
        },
      };
    }
    return {
      reply: ar
        ? `${v.name} — شريك ${SECTOR_AR[v.sector]} موثّق، ولديه ${items.length} منتجات. فتحت لك صفحته بالموقع والخريطة والريلز.`
        : `${v.name} — a verified ${sectorLabel(v.sector)} partner with ${items.length} products. Opening their page with site, map and reel.`,
      action: () => d.openVendor(v),
    };
  }

  /* ------------------------------ product ----------------------------- */
  const pHit = best<Product>(trustedProducts, probe, (p) => [p.name]);
  if (pHit) {
    const p = pHit.item;
    const vendor = db.vendors.find((v) => v.id === p.vendorId);
    if (has(text, ...WANT_ORDER)) {
      const qty = parseQuantity(text);
      return {
        reply: ar
          ? `تمام — أضفت ${qty} من ${p.name} من ${vendor?.name ?? ""} بإجمالي ${fmtEGP((p.sale ?? p.price) * qty)}. أوريك مكان الفرع؟`
          : `Done — ${qty} × ${p.name} from ${vendor?.name ?? ""}, totaling ${fmtEGP((p.sale ?? p.price) * qty)}. Shall I show you their branch?`,
        action: () => {
          d.addToCart(p.id, qty);
          d.showResult({
            kind: "order",
            title: ar ? "الطلب جاهز للمراجعة" : "Order ready to review",
            subtitle: vendor?.name,
            items: [{
              id: p.id,
              label: p.name,
              value: fmtEGP((p.sale ?? p.price) * qty),
              meta: `${qty} × ${fmtEGP(p.sale ?? p.price)} · ${vendor?.name ?? ""}`,
              image: p.img,
              productId: p.id,
              vendorId: vendor?.id,
            }],
            total: (p.sale ?? p.price) * qty,
            totalLabel: ar ? "قيمة الإضافة" : "Added value",
            note: ar
              ? "لم يتم الدفع بعد. راجع الموقع والخريطة ثم أكّد من السلة."
              : "Nothing has been paid yet. Review the site and map, then confirm from your cart.",
          });
        },
      };
    }
    return {
      reply: ar
        ? `لقيت ${p.name} من ${vendor?.name ?? ""} بسعر ${fmtEGP(p.sale ?? p.price)}. وصّلتك للرف بتاعه.`
        : `Found ${p.name} by ${vendor?.name ?? ""} at ${fmtEGP(p.sale ?? p.price)}. Taking you to its shelf.`,
      action: () => {
        d.filterShop(p.catId, p.subId);
        d.highlight("#shop", ar ? "منتجك هنا" : "Your product", "ok");
      },
    };
  }

  /* --------------------------- subcategory ---------------------------- */
  const subHit = best(
    db.subcategories.filter((s) => !s.hidden),
    probe,
    (s) => [s.name, SUB_AR[s.name] ?? s.name]
  );
  if (subHit) {
    const s = subHit.item;
    const cat = db.categories.find((c) => c.id === s.catId);
    const n = live.filter((p) => p.subId === s.id).length;
    return {
      reply: ar
        ? `عندنا ${n} منتج في ${SUB_AR[s.name] ?? s.name}. فلترت لك الرف.`
        : `We have ${n} products in ${s.name}. Filtering the shelf for you.`,
      action: () => {
        if (cat) d.filterShop(cat.id, s.id);
        d.highlight("#shop", (ar ? SUB_AR[s.name] : s.name) ?? s.name, "ok");
      },
    };
  }

  /* ---------------------------- category ------------------------------ */
  const cHit = best(
    db.categories.filter((c) => !c.hidden),
    probe,
    (c) => [c.name, SECTOR_AR[c.slug] ?? c.name]
  );
  if (cHit) {
    const c = cHit.item;
    const n = live.filter((p) => p.catId === c.id).length;
    const vn = vendors.filter((v) => v.sector === (c.slug as Vendor["sector"])).length;
    return {
      reply: ar
        ? `قسم ${SECTOR_AR[c.slug] ?? c.name}: ${vn} شريك و${n} منتج. فتحت لك القسم.`
        : `${c.name}: ${vn} partners and ${n} products. Opening that aisle.`,
      action: () => {
        d.filterShop(c.id);
        d.highlight("#shop", (ar ? SECTOR_AR[c.slug] : c.name) ?? c.name, "ok");
      },
    };
  }

  /* ------------------------- generic browse --------------------------- */
  if (has(text, ...WANT_SHOW) && has(text, "vendor", "partner", "brand", "شريك", "شركاء", "ماركة", "علامة")) {
    return {
      reply: ar
        ? `عندنا ${vendors.length} شريك موثّق في ${db.categories.length} قطاع. وصّلتك لهم.`
        : `We have ${vendors.length} verified partners across ${db.categories.length} sectors. Taking you there.`,
      action: () => d.highlight("#vendors", ar ? "الشركاء الموثّقون" : "Verified partners", "ok"),
    };
  }
  if (has(text, ...WANT_SHOW)) {
    return {
      reply: ar
        ? "وصّلتك لدليل الأقسام — اختر القسم اللي يناسبك."
        : "Here's the full catalogue — pick the aisle you want.",
      action: () => d.highlight("#categories", ar ? "دليل الأقسام" : "The catalogue", "ok"),
    };
  }

  return null;
}
