import type { LinkProbe, LinkProbeState } from "./store";

/**
 * Browser-side link health.
 *
 * A static page cannot read cross-origin HTTP status codes, so this never
 * pretends to return "404". Instead it combines two signals that DO work
 * from the browser:
 *   1. DNS-over-HTTPS (dns.google) — CORS enabled, proves the host exists.
 *   2. A no-cors fetch — resolves if the server answered at all.
 *
 * States: ok | unreachable | blocked (exists, response unreadable) | missing.
 */

const DNS_CACHE = new Map<string, boolean>();

function hostOf(url: string): string | null {
  try {
    return new URL(url).hostname;
  } catch {
    return null;
  }
}

async function dnsResolves(host: string, signal?: AbortSignal): Promise<boolean | null> {
  if (DNS_CACHE.has(host)) return DNS_CACHE.get(host)!;
  try {
    const res = await fetch(
      `https://dns.google/resolve?name=${encodeURIComponent(host)}&type=A`,
      { signal, headers: { Accept: "application/dns-json" } }
    );
    if (!res.ok) return null;
    const data = (await res.json()) as { Status?: number; Answer?: unknown[] };
    const ok = data.Status === 0 && Array.isArray(data.Answer) && data.Answer.length > 0;
    DNS_CACHE.set(host, ok);
    return ok;
  } catch {
    return null;
  }
}

async function reachable(url: string, timeoutMs: number): Promise<boolean> {
  const ctrl = new AbortController();
  const timer = window.setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    await fetch(url, { mode: "no-cors", signal: ctrl.signal, redirect: "follow" });
    return true;
  } catch {
    return false;
  } finally {
    window.clearTimeout(timer);
  }
}

export async function probeLink(url: string | undefined, timeoutMs = 7000): Promise<LinkProbe> {
  const checkedAt = new Date().toISOString();
  if (!url || !url.trim()) return { state: "missing", detail: "No link saved", checkedAt };

  const host = hostOf(url);
  if (!host) return { state: "missing", detail: "Malformed URL", checkedAt };

  const dns = await dnsResolves(host);
  if (dns === false) {
    return { state: "unreachable", detail: `DNS has no record for ${host}`, checkedAt };
  }

  const alive = await reachable(url, timeoutMs);
  if (alive) return { state: "ok", detail: `${host} responded`, checkedAt };

  if (dns === true) {
    return {
      state: "blocked",
      detail: `${host} resolves but blocked the browser check`,
      checkedAt,
    };
  }
  return { state: "unreachable", detail: `No response from ${host}`, checkedAt };
}

export interface VendorLinkTargets {
  website?: string;
  instagram?: string;
  facebook?: string;
  tiktok?: string;
  youtube?: string;
}

export type VendorLinkReport = Record<keyof VendorLinkTargets, LinkProbe>;

export async function probeVendorLinks(targets: VendorLinkTargets): Promise<VendorLinkReport> {
  const keys = ["website", "instagram", "facebook", "tiktok", "youtube"] as const;
  const out = {} as VendorLinkReport;
  for (const key of keys) {
    out[key] = await probeLink(targets[key]);
  }
  return out;
}

/** Runs probes with bounded concurrency so a big sweep stays responsive. */
export async function runPool<T, R>(
  items: T[],
  limit: number,
  worker: (item: T, index: number) => Promise<R>,
  onProgress?: (done: number, total: number) => void
): Promise<R[]> {
  const results = new Array<R>(items.length);
  let cursor = 0;
  let done = 0;
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (cursor < items.length) {
      const index = cursor++;
      results[index] = await worker(items[index], index);
      done += 1;
      onProgress?.(done, items.length);
    }
  });
  await Promise.all(runners);
  return results;
}

export const PROBE_STYLE: Record<LinkProbeState, { label: string; cls: string }> = {
  ok: { label: "Working", cls: "border-brand/40 bg-brand/10 text-brand" },
  blocked: { label: "Unconfirmed", cls: "border-gold/40 bg-gold/10 text-gold" },
  unreachable: { label: "Broken", cls: "border-rose-400/40 bg-rose-400/10 text-rose-400" },
  missing: { label: "Missing", cls: "border-line text-fg3" },
};
