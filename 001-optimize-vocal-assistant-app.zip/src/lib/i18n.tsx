import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

export type Lang = "en" | "ar";

const dict = {
  /* ---------------------------------- nav --------------------------------- */
  "nav.services": ["Services", "الخدمات"],
  "nav.how": ["How it works", "كيف تعمل"],
  "nav.demo": ["Live demo", "تجربة حيّة"],
  "nav.dashboard": ["Dashboard", "لوحة التحكم"],
  "nav.languages": ["Languages", "اللغات"],
  "nav.cta": ["Get iRoopa", "احصل على iRoopa"],

  /* --------------------------------- hero --------------------------------- */
  "hero.eyebrow": ["Bilingual voice AI · English & العربية", "مساعد صوتي ثنائي اللغة · عربي وإنجليزي"],
  "hero.title.a": ["Life, handled", "حياتك اليومية،"],
  "hero.title.b": ["by voice.", "بصوتك فقط."],
  "hero.sub": [
    "iRoopa listens in Arabic and English, understands what you mean, and helps across the whole experience — search, compare, write, calculate, schedule and navigate.",
    "تسمعك iRoopa بالعربية والإنجليزية، وتفهم مقصدك، وتساعدك في كل التجربة — بحث ومقارنة وكتابة وحساب وجدولة وتنقّل.",
  ],
  "hero.cta.talk": ["Talk to Roopa", "تحدّث مع روبا"],
  "hero.cta.watch": ["See it in action", "شاهدها تعمل"],
  "hero.trust": ["Trusted by 40,000+ households", "موثوقة من أكثر من ٤٠ ألف أسرة"],
  "hero.rating": ["4.9 / 5 user rating", "تقييم ٤٫٩ من ٥"],
  "hero.stat.tasks": ["voice tasks completed", "مهمة صوتية مكتملة"],
  "hero.stat.response": ["avg. response time", "متوسط زمن الاستجابة"],
  "hero.stat.langs": ["dialects understood", "لهجة مفهومة"],

  /* ------------------------------- assistant ------------------------------ */
  "asst.name": ["Roopa", "روبا"],
  "asst.status.online": ["Online · ready when you are", "متصلة · جاهزة عند طلبك"],
  "asst.sim": ["Text ready", "الكتابة متاحة"],
  "asst.live": ["Live mic", "ميكروفون مباشر"],
  "asst.idle": ["Tap the mic, or pick a command", "اضغط الميكروفون أو اختر أمرًا"],
  "asst.listening": ["Listening…", "أستمع إليك…"],
  "asst.processing": ["Understanding intent…", "أفهم طلبك…"],
  "asst.speaking": ["Roopa is speaking", "روبا تتحدث"],
  "asst.you": ["You", "أنت"],
  "asst.hint": [
    "Best in Chrome / Edge · sourced web lookup is used for general knowledge",
    "تعمل بشكل أفضل على كروم أو إيدج · تُستخدم مصادر ويب موثّقة للأسئلة العامة",
  ],
  "asst.chip.0": ["Open Egyptian fashion", "افتح الأزياء المصرية"],
  "asst.chip.1": ["Compare the best-value products", "قارن أفضل المنتجات قيمة"],
  "asst.chip.2": ["Write a polite follow-up email", "اكتب بريد متابعة مهذب"],
  "asst.chip.3": ["Schedule my daily needs", "جدول احتياجاتي اليومية"],

  /* -------------------------------- services ------------------------------ */
  "services.eyebrow": ["One voice, every errand", "صوت واحد، لكل مشاويرك"],
  "services.title": ["A concierge for your", "مساعدك الشخصي"],
  "services.title.b": ["entire day", "طوال يومك"],
  "services.sub": [
    "Roopa plugs into the services you already use and speaks the language of forms, quotes and bookings — so you don't have to.",
    "تتصل روبا بالخدمات التي تستخدمها بالفعل وتتقن لغة النماذج والعروض والحجوزات — لتوفر عليك العناء.",
  ],

  /* --------------------------------- steps -------------------------------- */
  "how.eyebrow": ["Effortless by design", "مصمّمة لتكون سهلة"],
  "how.title": ["Three seconds. Three steps.", "ثلاث ثوانٍ. ثلاث خطوات."],
  "how.sub": [
    "No apps to juggle, no forms to fill. Say it once — Roopa handles the rest.",
    "لا تطبيقات متعددة ولا نماذج مرهقة. قلها مرة واحدة — وروبا تتكفّل بالباقي.",
  ],
  "how.s1.t": ["Speak naturally", "تحدّث بعفوية"],
  "how.s1.d": [
    "Any dialect, any accent — Gulf, Egyptian, Levantine or English. Even mid-sentence code-switching.",
    "بأي لهجة أو لكنة — خليجية، مصرية، شامية أو إنجليزية. حتى لو خلطت اللغتين في جملة واحدة.",
  ],
  "how.s2.t": ["Roopa understands intent", "روبا تفهم المقصد"],
  "how.s2.d": [
    "On-device NLU parses entities, context and your history into a concrete plan.",
    "محرّك فهم لغوي على الجهاز يحوّل الكلام والسياق وسجلّك إلى خطة تنفيذ واضحة.",
  ],
  "how.s3.t": ["Done — and confirmed", "يُنجَز الأمر ويُؤكَّد لك"],
  "how.s3.d": [
    "She executes across your services, then confirms in your language with the details that matter.",
    "تنفّذ عبر خدماتك ثم تؤكد لك بلغتك مع أهم التفاصيل.",
  ],

  /* ------------------------------- dashboard ------------------------------ */
  "dash.eyebrow": ["Control room", "غرفة التحكّم"],
  "dash.title": ["Every command,", "كل أمر،"],
  "dash.title.b": ["accounted for", "موثَّق أمامك"],
  "dash.sub": [
    "A live feed of everything Roopa handled — searchable, reversible, and private by default.",
    "سجلّ حيّ لكل ما أنجزته روبا — قابل للبحث والتراجع، وخاص بشكل افتراضي.",
  ],
  "dash.kpi.tasks": ["Tasks this month", "مهام هذا الشهر"],
  "dash.kpi.response": ["Avg. response", "متوسط الاستجابة"],
  "dash.kpi.saved": ["Hours saved / week", "ساعات تُوفَّر أسبوعيًا"],
  "dash.kpi.csat": ["Satisfaction", "رضا المستخدمين"],
  "dash.chart": ["Commands handled per day", "الأوامر المنفّذة يوميًا"],
  "dash.feed": ["Live activity", "النشاط المباشر"],
  "dash.week": ["Last 7 days", "آخر ٧ أيام"],

  /* -------------------------------- bilingual ----------------------------- */
  "bi.eyebrow": ["Two languages, zero friction", "لغتان، بلا أي حواجز"],
  "bi.title": ["Fluent in", "تتقن"],
  "bi.title.b": ["both worlds", "كلا العالمين"],
  "bi.sub": [
    "Roopa switches between Arabic and English mid-conversation — and renders everything beautifully right-to-left or left-to-right.",
    "تنتقل روبا بين العربية والإنجليزية في منتصف الحوار، وتعرض كل شيء بإتقان من اليمين لليسار أو العكس.",
  ],
  "bi.try": ["Flip the whole experience", "بدّل التجربة بالكامل"],
  "bi.dialects": ["Dialects & accents", "اللهجات واللكنات"],

  /* ---------------------------------- cta --------------------------------- */
  "cta.title.a": ["Your day,", "يومك،"],
  "cta.title.b": ["on voice command.", "بأمر من صوتك."],
  "cta.sub": [
    "Join 40,000+ households that stopped typing errands. Free during beta — Arabic & English.",
    "انضم إلى أكثر من ٤٠ ألف أسرة توقفت عن كتابة المهام. مجاني خلال النسخة التجريبية — بالعربية والإنجليزية.",
  ],
  "cta.button": ["Start talking — it's free", "ابدأ الحديث — مجانًا"],
  "cta.secondary": ["Talk to Roopa first", "جرّب روبا أولًا"],

  /* --------------------------------- footer ------------------------------- */
  "footer.tag": [
    "A bilingual personal AI voice assistant for everyday life.",
    "مساعد ذكي صوتي ثنائي اللغة لحياتك اليومية.",
  ],
  "brand.tagline": ["Buy and sell easily", "اشترِ وبِع بسهولة"],
  "cta.addcompany": ["Add your brand — free", "أضف علامتك — مجانًا"],
  "footer.product": ["Product", "المنتج"],
  "footer.company": ["Company", "الشركة"],
  "footer.legal": ["Legal", "قانوني"],
  "footer.rights": ["© 2026 iRoopa Labs. Crafted for Arabic & English speakers.", "© ٢٠٢٦ iRoopa Labs. صُنعت للناطقين بالعربية والإنجليزية."],
  "footer.privacy": ["Privacy-first", "خصوصية أولًا"],
  "footer.ondevice": ["Local actions · sourced answers", "تنفيذ محلي · إجابات بمصادر"],
  "footer.verifiedlinks": ["Verified links only", "روابط موثّقة فقط"],
  "footer.links.features": ["Features", "المزايا"],
  "footer.links.demo": ["Live demo", "تجربة حيّة"],
  "footer.links.dashboard": ["Dashboard", "لوحة التحكم"],
  "footer.links.languages": ["Languages", "اللغات"],
  "footer.links.about": ["About", "من نحن"],
  "footer.links.careers": ["Careers", "الوظائف"],
  "footer.links.press": ["Press kit", "العدة الصحفية"],
  "footer.links.contact": ["Contact", "تواصل معنا"],
  "footer.links.terms": ["Terms", "الشروط"],
  "footer.links.privacyp": ["Privacy", "الخصوصية"],
  "footer.links.security": ["Security", "الأمان"],

  /* --------------------------------- nav2 --------------------------------- */
  "nav.vendors": ["Brand Companies", "الشركات"],
  "nav.shop": ["Shop", "المتجر"],
  "nav.catalogue": ["Catalogue", "الأقسام"],
  "nav.showcase": ["Showcase", "تجربة ثلاثية الأبعاد"],

  /* ------------------------------- vendors -------------------------------- */
  "v.eyebrow": ["Verified brands + brand discovery", "براندات موثّقة واكتشاف علامات"],
  "v.title.a": ["brand companies,", "شركات مسجلة،"],
  "v.title.b": ["15 sectors", "١٥ قطاعًا"],
  "v.sub": [
    "Official links appear first; brand profiles stay visible and clearly marked until verified.",
    "تظهر الروابط الرسمية أولًا، وتبقى ملفات الشركات ظاهرة بعلامة واضحة حتى يتم التحقق منها.",
  ],
  "v.all": ["All sectors", "كل القطاعات"],
  "v.hotline": ["Hotline", "الخط الساخن"],
  "v.tab.products": ["Products", "المنتجات"],
  "v.tab.visit": ["Visit", "زيارة"],
  "v.tab.map": ["Map", "الخريطة"],
  "v.tab.reel": ["Reel", "ريلز"],
  "v.website": ["Website", "الموقع"],
  "v.site.find": ["Find official site", "ابحث عن الموقع الرسمي"],
  "v.site.verify": ["Verify official site", "تحقق من الموقع الرسمي"],
  "m.move": ["Drag to move", "اسحب للتحريك"],
  "m.center": ["Recenter", "إعادة التوسيط"],
  "m.full": ["Fullscreen", "ملء الشاشة"],
  "m.restore": ["Restore", "استعادة"],
  "m.close": ["Close", "إغلاق"],
  "v.embed.open": ["Open official account", "افتح الحساب الرسمي"],
  "v.embed.notloading": [
    "Not loading? Some platforms restrict embedding.",
    "لا يظهر المحتوى؟ بعض المنصات تمنع التضمين.",
  ],
  "v.embed.needsid": [
    "This channel is saved as a @handle, which YouTube will not embed. Paste the /channel/UC… URL in Dashboard → Link Health to enable in-popup playback.",
    "هذه القناة محفوظة بصيغة @handle ولا يسمح يوتيوب بتضمينها. الصق رابط /channel/UC… في لوحة التحكم ← صحة الروابط لتشغيل الفيديو داخل النافذة.",
  ],
  "v.embed.noplugin": [
    "This page URL is not supported by the Facebook Page Plugin. Open it directly.",
    "هذا الرابط غير مدعوم في أداة صفحات فيسبوك. افتحه مباشرة.",
  ],
  "v.directions": ["Directions", "الاتجاهات"],
  "v.verified": ["Voice-verified company", "شركة موثّقة صوتيًا"],
  "v.b2b": ["B2B · MOQ 300+", "جملة · حد أدنى ٣٠٠ قطعة"],
  "v.hours": ["Sat–Thu · 9:00 — 22:00", "السبت–الخميس · ٩ ص — ١٠ م"],
  "v.openmaps": ["Open in Google Maps", "افتح في خرائط جوجل"],
  "v.contact.na": ["Not verified", "غير موثّق"],
  "v.map.na": ["No verified map", "لا توجد خريطة موثّقة"],
  "v.map.search": ["Search Google Maps", "ابحث في خرائط جوجل"],
  "v.map.discovery": [
    "Google Maps search result — verify the branch before visiting.",
    "نتيجة بحث في خرائط جوجل — تأكد من الفرع قبل الزيارة.",
  ],
  "v.whatsapp.find": ["Find WhatsApp", "ابحث عن واتساب"],
  "v.social.find": ["Discover", "بحث"],
  "v.youtube.shorts": ["YouTube Shorts", "فيديوهات YouTube Shorts"],
  "v.allbrands": ["View all brands", "عرض كل العلامات"],
  "v.searchbrands": ["Search brands…", "ابحث عن علامة…"],
  "v.brandcount": ["brand profiles", "ملف علامة"],
  "v.contact.verified": ["Verified contact from an official source", "بيانات اتصال من مصدر رسمي"],
  "v.entity.brand": ["Brand", "علامة"],
  "v.entity.marketplace": ["Marketplace", "متجر متعدد"],
  "v.entity.manufacturer": ["Manufacturer", "مصنع"],
  "v.entity.store": ["Physical store", "متجر فعلي"],
  "v.entity.brandorig": ["Original brand", "علامة أصلية"],
  "v.entity.retailer": ["Retailer", "تاجر تجزئة"],
  "v.egypt.claimed": ["Made-in-Egypt claimed", "صنع في مصر حسب العلامة"],
  "v.egypt.unverified": ["Egypt status unverified", "حالة التصنيع غير موثّقة"],
  "v.egypt.verified": ["Egyptian source verified", "مصدر مصري موثّق"],
  "v.links.fresh": ["Links verified", "الروابط موثّقة"],
  "v.links.stale": ["Needs recheck", "تحتاج مراجعة"],
  "v.links.unverified": ["Links unverified", "روابط غير موثّقة"],
  "v.price.unverified": ["Live price not verified", "السعر الحالي غير موثّق"],
  "v.audited.price": ["Official price checked", "سعر من المصدر الرسمي"],
  "v.catalog.na": ["Official catalogue not verified", "الكتالوج الرسمي غير موثّق"],
  "v.opensite": ["Open full site", "افتح الموقع كاملًا"],
  "v.sitenote": [
    "Some brands block embedding — use the button to open their official site.",
    "بعض العلامات تمنع العرض المدمج — استخدم الزر لفتح الموقع الرسمي.",
  ],
  "v.official": ["Official reel", "ريلز رسمي"],
  "v.add": ["Add", "أضف"],
  "v.showmore": ["Show more brands", "عرض براندات أكثر"],
  "v.coverage.maps": ["searchable maps", "خريطة قابلة للبحث"],
  "v.coverage.sites": ["official sites", "موقعًا رسميًا"],
  "v.coverage.socials": ["audited brand profiles", "ملفًا اجتماعيًا موثّقًا"],
  "v.coverage.whatsapp": ["verified WhatsApp", "واتساب موثّق"],
  "v.coverage.logos": ["brand logos", "شعارًا معروضًا"],
  "v.audited": ["Audited official account", "حساب رسمي تم التحقق منه"],
  "v.social.unavailable": [
    "No official social profile verified",
    "لم يتم التحقق من حساب اجتماعي رسمي",
  ],
  "v.social.discover": ["Discover official profiles", "ابحث عن الحسابات الرسمية"],
  "v.discover.videos": ["Discover videos", "اكتشف الفيديوهات"],
  "v.discovery.notvideos": [
    "These are discovery searches, not verified videos. Save exact links before publishing.",
    "هذه روابط بحث وليست فيديوهات موثّقة. احفظ الروابط الدقيقة قبل النشر.",
  ],
  "v.officialcatalog": ["Browse original products", "تصفّح المنتجات الأصلية"],
  "v.catalognote": [
    "Official catalogue from the vendor website",
    "الكتالوج الرسمي من موقع العلامة",
  ],
  "v.previewnote": [
    "Directory preview — confirm current product details on the official catalogue.",
    "عرض تعريفي — راجع تفاصيل المنتج الحالية في الكتالوج الرسمي.",
  ],

  /* ------------------------------ categories ------------------------------ */
  "cat.eyebrow": ["The catalogue", "دليل الأقسام"],
  "cat.title.a": ["Every company,", "كل شركة،"],
  "cat.title.b": ["every category", "وكل قسم"],
  "cat.sub": [
    "All categories are synced 1:1 with the brand sectors — tap a subcategory to jump straight into the filtered shelf.",
    "كل الأقسام مرتبطة مباشرة بقطاعات الشركات — اضغط على قسم فرعي لتنتقل فورًا إلى رف المنتجات المفلتر.",
  ],
  "cat.items": ["items", "منتج"],
  "cat.viewall": ["View all", "عرض الكل"],
  "cat.brands": ["Brands", "العلامات"],

  /* -------------------------------- shop ---------------------------------- */
  "shop.eyebrow": ["The marketplace", "السوق"],
  "shop.title.a": ["One cart,", "سلة واحدة،"],
  "shop.title.b": ["every aisle", "لكل الأقسام"],
  "shop.sub": [
    "Browse the full catalogue — tap the pencil to edit any product's image, text or price on the spot.",
    "تصفّح الكتالوج كاملًا — اضغط على القلم لتعديل صورة أي منتج أو نصه أو سعره في الحال.",
  ],
  "shop.new": ["New product", "منتج جديد"],
  "shop.cart": ["Cart", "السلة"],
  "shop.search": ["Search products…", "ابحث عن منتج…"],
  "shop.all": ["All", "الكل"],
  "shop.everything": ["Everything", "كل المنتجات"],
  "shop.none": ["No products match", "لا توجد منتجات مطابقة"],
  "shop.none.sub": ["Try a different category or search term.", "جرّب قسمًا آخر أو كلمة بحث مختلفة."],
  "shop.showmore": ["Show more", "عرض المزيد"],
  "shop.left": ["left", "متبقٍ"],
  "shop.addcart": ["Add to cart", "أضف إلى السلة"],
  "shop.empty": ["Nothing here yet", "السلة فارغة"],
  "shop.empty.sub": ["Add items from any company or the shop below.", "أضف منتجات من أي شركة أو من المتجر بالأسفل."],
  "shop.total": ["Total", "الإجمالي"],
  "shop.checkout": ["Checkout by voice", "أتمم الطلب بالصوت"],
  "shop.yourcart": ["Your cart", "سلة مشترياتك"],
  "shop.ordered": ["Order placed — Roopa confirms by voice shortly.", "تم تنفيذ الطلب — ستؤكده روبا صوتيًا بعد قليل."],
  "shop.added": ["Added to cart", "تمت الإضافة إلى السلة"],

  /* ------------------------------- spotlight ------------------------------ */
  "st.customize": ["Customize themes", "تخصيص الثيمات"],
  "st.studio": ["Theme Studio", "استوديو الثيمات"],
  "st.title": ["Seven concepts. One storefront.", "سبعة تصاميم. متجر واحد."],
  "st.sub": [
    "Flip the entire home experience — palette, typography, hero copy, spotlight and featured products. Your choice persists.",
    "بدّل تجربة الصفحة الرئيسية بالكامل — الألوان والخطوط والعناوين والعروض والمنتجات المميزة. ويُحفظ اختيارك.",
  ],
  "st.editor": ["Open theme editor", "افتح محرّر الثيمات"],
  "st.editor.sub": [
    "Colors, hero copy, spotlight & featured products — with import / export.",
    "الألوان والعناوين والعروض والمنتجات المميزة — مع الاستيراد والتصدير.",
  ],
  "st.godash": ["Go to dashboard", "إلى لوحة التحكم"],
  "st.export": ["Export active theme", "تصدير الثيم الحالي"],
  "st.resetall": ["Reset everything", "إعادة ضبط كل شيء"],
  "st.applied": ["Applied instantly, stored locally", "يُطبّق فورًا ويُحفظ محليًا"],
  "st.dark": ["Dark", "داكن"],
  "st.light": ["Light", "فاتح"],

  /* --------------------------------- misc --------------------------------- */
  "m.demo": [
    "Admin mode: every company, product, order and theme lives in your browser — exportable anytime from the console.",
    "وضع المشرف: كل الشركات والمنتجات والطلبات والثيمات محفوظة في متصفحك — ويمكن تصديرها في أي وقت من لوحة التحكم.",
  ],
  "m.godash": ["Go to Dashboard", "إلى لوحة التحكم"],
} as const;

/* ------------------------- domain label dictionaries ---------------------- */

export const SECTOR_AR: Record<string, string> = {
  insurance: "التأمين",
  realestate: "العقارات",
  startup: "الشركات الناشئة",
  ecommerce: "التجارة الإلكترونية",
  antiques: "التحف والفنون",
  tourism: "السياحة",
  homes: "خدمات المنازل",
  automotive: "السيارات",
  salon: "التجميل والصالونات",
  stocks: "البورصة",
  restaurants: "المطاعم",
  recruitment: "التوظيف",
  offers: "عروض خاصة",
  fashion: "الأزياء المصرية",
  footwear: "اكتشاف الأحذية",
  discovery: "مصادر الاكتشاف",
};

export const SUB_AR: Record<string, string> = {
  Health: "صحي", Motor: "سيارات", Travel: "سفر",
  Apartments: "شقق", Villas: "فيلات", Commercial: "تجاري",
  Product: "تطوير المنتج", Cloud: "سحابة", Growth: "نمو",
  Gadgets: "أجهزة", Audio: "صوتيات", "Smart Home": "منزل ذكي",
  Collectibles: "مقتنيات", Decor: "ديكور", "Art Prints": "لوحات فنية",
  Cruises: "رحلات نيلية", "Day Trips": "رحلات يومية", Adventure: "مغامرات",
  Cleaning: "تنظيف", Repairs: "إصلاحات", Installations: "تركيبات",
  Detailing: "تلميع وعناية", Parts: "قطع غيار", "In-car Tech": "إلكترونيات السيارة",
  Hair: "شعر", "Nails & Spa": "أظافر وسبا", Bridal: "عرائس",
  Courses: "دورات", Signals: "توصيات", Advisory: "استشارات",
  Mains: "أطباق رئيسية", Bundles: "وجبات عائلية", "Private Events": "مناسبات خاصة",
  Candidates: "باحثون عن عمل", Employers: "أصحاب العمل", Reports: "تقارير",
  Vouchers: "كوبونات", "Flash Deals": "عروض سريعة",
  "Women's RTW": "أزياء نسائية جاهزة", Streetwear: "ستريت وير", Modest: "أزياء محتشمة",
  Denim: "جينز", Jewelry: "مجوهرات", "Bags & Leather": "حقائب وجلود",
  Footwear: "أحذية", "Bridal & Couture": "فساتين زفاف وهوت كوتور",
  Activewear: "ملابس رياضية", "Basics & Loungewear": "أساسيات وملابس منزلية",
  "Kids & Swim": "أطفال وملابس بحر", Manufacturers: "مصانع وتصنيع",
  Sources: "مصادر", "Price Indexes": "مؤشرات الأسعار", "Concept Stores": "متاجر متعددة",
  Sneakers: "سنيكرز", Running: "جري", "Football Boots": "أحذية كرة القدم", Casual: "كاجوال",
  Formal: "رسمي", "Sandals & Slides": "صنادل وسلايدز", Boots: "بوتس",
  "Women's": "نسائي", "Men's": "رجالي", "Kids'": "أطفال",
};

export const TIER_AR: Record<string, string> = {
  Platinum: "بلاتيني",
  Gold: "ذهبي",
  Silver: "فضي",
  Verified: "موثّق",
};

export type DictKey = keyof typeof dict;

interface LangCtxValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  toggleLang: () => void;
  t: (k: DictKey) => string;
  rtl: boolean;
}

const LangCtx = createContext<LangCtxValue | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    try {
      return (localStorage.getItem("iroopa-lang") as Lang) || "en";
    } catch {
      return "en";
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    root.lang = lang;
    root.dir = lang === "ar" ? "rtl" : "ltr";
    try {
      localStorage.setItem("iroopa-lang", lang);
    } catch {
      /* private mode */
    }
  }, [lang]);

  const setLang = useCallback((l: Lang) => setLangState(l), []);
  const toggleLang = useCallback(
    () => setLangState((p) => (p === "en" ? "ar" : "en")),
    []
  );
  const t = useCallback(
    (k: DictKey) => (lang === "ar" ? dict[k][1] : dict[k][0]),
    [lang]
  );

  const value = useMemo(
    () => ({ lang, setLang, toggleLang, t, rtl: lang === "ar" }),
    [lang, setLang, toggleLang, t]
  );

  return <LangCtx.Provider value={value}>{children}</LangCtx.Provider>;
}

export function useLang() {
  const ctx = useContext(LangCtx);
  if (!ctx) throw new Error("useLang must be used inside LanguageProvider");
  return ctx;
}
