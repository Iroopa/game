/** The 7 home themes — palettes live in CSS via [data-ht]; this file holds
 *  identity, marketing copy, spotlight content and featured-product hints. */
import type { PoolKey } from "./media";

export type ThemeId =
  | "royal"
  | "neon"
  | "noir"
  | "bazaar"
  | "aurora"
  | "brutal"
  | "linen";

export interface ThemeDef {
  id: ThemeId;
  name: string;
  tagline: string;
  dark: boolean;
  copy: { a: string; b: string; sub: string };
  spotlight: { kicker: string; title: string; desc: string; pool: PoolKey; imgIdx: number };
  featuredSector: string;
  swatches: string[]; // preview chips for the studio card
}

export const THEMES: ThemeDef[] = [
  {
    id: "royal",
    name: "Royal Emerald",
    tagline: "The signature iRoopa look — deep ink and living emerald.",
    dark: true,
    copy: { a: "Life, handled", b: "by voice.", sub: "" },
    spotlight: {
      kicker: "Vendor spotlight",
      title: "Delta Auto Gallery — ceramic season is open",
      desc: "Book the full ceramic pack by voice and get the interior detail free, this week only.",
      pool: "automotive",
      imgIdx: 3,
    },
    featuredSector: "automotive",
    swatches: ["#040906", "#35e0a5", "#2dd4bf", "#f2b968"],
  },
  {
    id: "neon",
    name: "Neon Cyber",
    tagline: "Midnight grid, electric cyan and ultraviolet glow.",
    dark: true,
    copy: {
      a: "Plug into",
      b: "the neon grid.",
      sub: "Sixty-five verified vendors on one command line — your voice. Shop, book and insure at the speed of speech.",
    },
    spotlight: {
      kicker: "Flash spotlight",
      title: "Souq Now — midnight tech deals every Friday",
      desc: "Say “show me flash deals” and Roopa stacks the week's deepest gadget drops.",
      pool: "ecommerce",
      imgIdx: 0,
    },
    featuredSector: "ecommerce",
    swatches: ["#04040c", "#22d3ee", "#e879f9", "#facc15"],
  },
  {
    id: "noir",
    name: "Editorial Noir",
    tagline: "Gallery-grade monochrome with serif swagger.",
    dark: true,
    copy: {
      a: "Commerce,",
      b: "edited in serif.",
      sub: "An editorial storefront for slow browsing and fast buying — antiques, art and rare finds, curated nightly.",
    },
    spotlight: {
      kicker: "The collection",
      title: "Pharaonic Vault — the brass edit",
      desc: "Twelve restored pieces from Old Cairo dealers. Voice-reserve before the weekend gallery opens.",
      pool: "antiques",
      imgIdx: 1,
    },
    featuredSector: "antiques",
    swatches: ["#0b0b0a", "#e8e4d5", "#a39e8d", "#c9b069"],
  },
  {
    id: "bazaar",
    name: "Sunset Bazaar",
    tagline: "Amber souq warmth, copper glow, market energy.",
    dark: true,
    copy: {
      a: "The souq,",
      b: "reinvented.",
      sub: "Haggle-free prices, copper-lit aisles and dinner on the table by seven — speak your order in any dialect.",
    },
    spotlight: {
      kicker: "Tonight's table",
      title: "Ember & Olive — tasting menus by voice",
      desc: "Reserve the chef's counter for two and Roopa syncs it straight to your calendar.",
      pool: "restaurants",
      imgIdx: 0,
    },
    featuredSector: "restaurants",
    swatches: ["#130b06", "#ff9d45", "#ffcf6e", "#c96bf0"],
  },
  {
    id: "aurora",
    name: "Glass Aurora",
    tagline: "Frosted panels over polar light — calm and precise.",
    dark: true,
    copy: {
      a: "Glass-clear",
      b: "voice shopping.",
      sub: "Cool arctic gradients, frosted-glass cards and a checkout that finishes before the kettle boils.",
    },
    spotlight: {
      kicker: "Getaway spotlight",
      title: "Red Sea Escape — winter sun, voice-booked",
      desc: "Say “Red Sea weekend for two” — flights, transfers and reef passes in one go.",
      pool: "tourism",
      imgIdx: 5,
    },
    featuredSector: "tourism",
    swatches: ["#04080e", "#67e8f9", "#5eead4", "#a5b4fc"],
  },
  {
    id: "brutal",
    name: "Brutalist Pop",
    tagline: "Loud cream canvas, hard borders, zero apologies.",
    dark: false,
    copy: {
      a: "NO FORMS.",
      b: "JUST VOICE.",
      sub: "Big type, hard shadows, one microphone. If it can't be said in a sentence, we don't sell it.",
    },
    spotlight: {
      kicker: "DROP 07",
      title: "SprintHire — grads hired in 48 hours",
      desc: "Post one role by voice. Shortlist lands Monday. That is the entire flow.",
      pool: "startup",
      imgIdx: 3,
    },
    featuredSector: "recruitment",
    swatches: ["#f6f1e6", "#ffd400", "#ff4d00", "#121212"],
  },
  {
    id: "linen",
    name: "Minimal Linen",
    tagline: "Warm off-white, soft sage, storefront as slow living.",
    dark: false,
    copy: {
      a: "Quiet commerce,",
      b: "warm linen.",
      sub: "A calm aisle of Egyptian cotton, care rituals and home goods — whisper the list, we pack the box.",
    },
    spotlight: {
      kicker: "Slow goods",
      title: "Glo Spa Maadi — the ritual edit",
      desc: "Keratin, calm and cotton. Ask Roopa for the Sunday reset bundle.",
      pool: "salon",
      imgIdx: 5,
    },
    featuredSector: "salon",
    swatches: ["#f7f4ee", "#2f6f4f", "#b98d4f", "#7a6fbf"],
  },
];

export const themeById = (id: ThemeId) =>
  THEMES.find((t) => t.id === id) ?? THEMES[0];
