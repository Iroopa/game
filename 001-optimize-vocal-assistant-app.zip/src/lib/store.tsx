import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { POOLS, pick, type PoolKey } from "./media";
import { themeById, type ThemeId } from "./themes";

/* --------------------------------- types --------------------------------- */

export type SectorKey =
  | "insurance"
  | "realestate"
  | "startup"
  | "ecommerce"
  | "antiques"
  | "tourism"
  | "homes"
  | "automotive"
  | "salon"
  | "stocks"
  | "restaurants"
  | "recruitment"
  | "offers"
  | "fashion"
  | "footwear";

export type Tier = "Platinum" | "Gold" | "Silver" | "Verified";

export interface Category {
  id: string;
  name: string;
  slug: string;
  image: string;
  hidden: boolean;
  order: number;
}
export interface Subcategory {
  id: string;
  catId: string;
  name: string;
  hidden: boolean;
  order: number;
}
export type EntityKind = "official" | "marketplace" | "research" | "service" | "manufacturer" | "store";
export type EvidenceStatus = "verified" | "claimed" | "unverified";
export type Freshness = "fresh" | "stale" | "unverified";

export interface Provenance {
  sourceUrl?: string;
  sourceLabel?: string;
  checkedAt?: string;
}

/** Result of a browser-side link probe (no HTTP status is readable cross-origin). */
export type LinkProbeState = "ok" | "unreachable" | "blocked" | "missing";
export interface LinkProbe {
  state: LinkProbeState;
  detail?: string;
  checkedAt?: string;
}

export interface BrandCompany {
  id: string;
  name: string;
  sector: SectorKey;
  tier: Tier;
  hotline: string;
  website: string;
  mapQuery: string;
  videoUrl: string;
  logoHue: number;
  showImg: string;
  about: string;
  /** Audited official profiles only. Missing means not verified, never guessed. */
  socials?: {
    instagram?: string;
    facebook?: string;
    youtube?: string;
    tiktok?: string;
    linkedin?: string;
  };
  /** Official website/catalog entry point when the company publishes one. */
  catalogUrl?: string;
  /** Exact public WhatsApp number without a leading plus sign. */
  whatsapp?: string;
  /** Exact Google Maps URL when supplied by an official source. */
  mapUrl?: string;
  /** Brand identity tags for directory filtering (e.g., 'Egyptian Owned', 'Trending'). */
  tags?: string[];
  /** Fashion/segment subcategory this brand belongs to. */
  subId?: string;
  /** How the subcategory was decided, so AI guesses stay auditable. */
  subSource?: "manual" | "ai" | "seed";
  /** Last automated link-health result. */
  linkCheck?: {
    website?: LinkProbe;
    instagram?: LinkProbe;
    facebook?: LinkProbe;
    tiktok?: LinkProbe;
    youtube?: LinkProbe;
    checkedAt?: string;
  };
  /** Gallery/discovery link used where a direct video file is not verified. */
  videoDiscoveryUrl?: string;
  entityKind?: EntityKind;
  madeInEgypt?: EvidenceStatus;
  linkStatus?: Freshness;
  priceStatus?: Freshness;
  /** Date the public links were last manually audited. */
  linksAuditedAt?: string;
  hidden: boolean;
  order: number;
}

export type Vendor = BrandCompany;
export interface Product {
  id: string;
  vendorId: string;
  sectorKey: SectorKey;
  catId: string;
  subId: string;
  name: string;
  desc: string;
  price: number;
  sale: number | null;
  img: string;
  hidden: boolean;
  provenance?: Provenance;
  imageSource?: string;
  checkedAt?: string;
}
export interface ThemeOverride {
  colors?: Record<string, string>;
  copy?: { a: string; b: string; sub: string };
  spotlight?: { kicker: string; title: string; desc: string; img: string };
  featuredIds?: string[];
}
/** Public "add my company" submission, reviewed by an admin within the SLA. */
export type RequestStatus = "pending" | "approved" | "rejected";

export interface RequestedProductDraft {
  name: string;
  category?: string;
  price?: number | null;
  originalPrice?: number | null;
  productUrl?: string;
}

export interface VendorRequest {
  id: string;
  name: string;
  sector: SectorKey;
  website: string;
  instagram?: string;
  facebook?: string;
  linkedin?: string;
  tiktok?: string;
  youtube?: string;
  whatsapp?: string;
  hotline?: string;
  city?: string;
  about?: string;
  productDrafts?: RequestedProductDraft[];
  status: RequestStatus;
  submittedAt: string;
  reviewedAt?: string;
  /** Review SLA in hours — 48 by default. */
  slaHours: number;
  reviewNote?: string;
}

export interface DB {
  v: number;
  requests: VendorRequest[];
  /** Display currency. The legacy WordPress database states none, so this is
   *  an explicit admin decision rather than an assumption. */
  currency: string;
  categories: Category[];
  subcategories: Subcategory[];
  vendors: Vendor[];
  products: Product[];
  sectorsHidden: Partial<Record<SectorKey, boolean>>;
  activeTheme: ThemeId;
  overrides: Partial<Record<ThemeId, ThemeOverride>>;
}
export interface CartItem {
  productId: string;
  qty: number;
}
export interface Toast {
  id: number;
  kind: "ok" | "warn" | "err" | "info";
  msg: string;
}

/* ------------------------------ seed content ----------------------------- */

export const SECTORS: { key: SectorKey; label: string; pool: PoolKey; catSlug: string }[] = [
  { key: "insurance", label: "Insurance", pool: "insurance", catSlug: "insurance" },
  { key: "realestate", label: "Real Estate", pool: "realestate", catSlug: "realestate" },
  { key: "startup", label: "Startup", pool: "startup", catSlug: "startup" },
  { key: "ecommerce", label: "E-Commerce", pool: "ecommerce", catSlug: "ecommerce" },
  { key: "antiques", label: "Antiques", pool: "antiques", catSlug: "antiques" },
  { key: "tourism", label: "Tourism", pool: "tourism", catSlug: "tourism" },
  { key: "homes", label: "House Services", pool: "homes", catSlug: "homes" },
  { key: "automotive", label: "Automotive", pool: "automotive", catSlug: "automotive" },
  { key: "salon", label: "Salon & Beauty", pool: "salon", catSlug: "salon" },
  { key: "stocks", label: "Stock Market", pool: "stocks", catSlug: "stocks" },
  { key: "restaurants", label: "Restaurants", pool: "restaurants", catSlug: "restaurants" },
  { key: "recruitment", label: "Recruitment", pool: "startup", catSlug: "recruitment" },
  { key: "offers", label: "Special Offers", pool: "ecommerce", catSlug: "offers" },
  { key: "fashion", label: "Egyptian Fashion", pool: "fashion", catSlug: "fashion" },
  { key: "footwear", label: "Footwear Discovery", pool: "footwear", catSlug: "footwear" },
];

/** Catalogue subcategories per sector (browsable on the storefront). */
const SUBS: Record<SectorKey, string[]> = {
  insurance: ["Health", "Motor", "Travel"],
  realestate: ["Apartments", "Villas", "Commercial"],
  startup: ["Product", "Cloud", "Growth"],
  ecommerce: ["Gadgets", "Audio", "Smart Home"],
  antiques: ["Collectibles", "Decor", "Art Prints"],
  tourism: ["Cruises", "Day Trips", "Adventure"],
  homes: ["Cleaning", "Repairs", "Installations"],
  automotive: ["Detailing", "Parts", "In-car Tech"],
  salon: ["Hair", "Nails & Spa", "Bridal"],
  stocks: ["Courses", "Signals", "Advisory"],
  restaurants: ["Mains", "Bundles", "Private Events"],
  recruitment: ["Candidates", "Employers", "Reports"],
  offers: ["Vouchers", "Flash Deals", "Bundles"],
  fashion: [
    "Women's RTW", "Streetwear", "Modest", "Denim", "Jewelry", "Bags & Leather",
    "Footwear", "Bridal & Couture", "Activewear", "Basics & Loungewear", "Kids & Swim", "Manufacturers",
  ],
  footwear: [
    "Sneakers", "Running", "Football Boots", "Casual", "Formal",
    "Sandals & Slides", "Boots", "Women's", "Men's", "Kids'",
  ],
};

const VENDOR_NAMES: Record<SectorKey, string[]> = {
  insurance: [
    "Allianz Egypt", "AXA Egypt", "MetLife Egypt", "Misr Insurance", "Takaful Egypt",
    "Gig Egypt", "QNB Alahli Life", "Suez Canal Insurance", "Delta Insurance", "Mohandes Insurance",
  ],
  realestate: [
    "Sodic", "Emaar Misr", "Palm Hills", "Mountain View", "Talaat Moustafa Group", "Hyde Park",
    "Ora Developers", "Hassan Allam", "Marakez", "La Vista", "Tatweer Misr", "Misr Italia",
  ],
  startup: [
    "Fawry", "Vezeeta", "Swvl", "Instabug", "Paymob", "Trella", "Halan", "Breadfast", "Talabat Egypt", "MaxAB",
  ],
  ecommerce: [
    "Jumia Egypt", "Noon Egypt", "Amazon.eg", "Sharaf DG", "B.TECH", "Tradeline", "El Araby", "Homzmart",
  ],
  antiques: [
    "Nomad Gallery", "Safar Khan Gallery", "Ubuntu Art Gallery", "Gypsum Gallery", "Khan El-Khalili Relics", "Old Cairo Treasures",
  ],
  tourism: [
    "Misr Travel", "Travco Tours", "Memphis Tours", "Emo Tours Egypt", "Deluxe Tours",
    "Blue Sky Travel", "Wings Tours", "Select Egypt", "Nile Breeze Travel", "Pyramids Gate Tours",
  ],
  homes: [
    "FilKhedma", "CleanWave Home", "FixMisr", "HouseCall Cairo", "Spark Home Services", "CoolAir Services",
  ],
  automotive: [
    "GB Auto", "Mansour Automotive", "Bavarian Auto Group", "Auto Samir Rayan",
    "El Saba Automotive", "German Auto Service", "Cairo Motor Works", "Torque Garage",
  ],
  salon: [
    "Mohamed Al Sagheer", "Vintage Beauty Zamalek", "NailSnack Cairo", "Curtain Call Barbers",
    "Bloom Beauty", "Velvet Touch Salon", "Glo Spa Maadi", "Mane & Muse",
  ],
  stocks: [
    "EFG Hermes", "CI Capital", "Beltone Financial", "Pharos Holding",
    "HC Securities", "Mubasher Egypt", "Prime Securities", "Sigma Capital",
  ],
  restaurants: [
    "Abou El Sid", "Zooba", "Koshary Abou Tarek", "Sequoia", "Sachi",
    "Pier 88", "Felfela", "Gad", "El Shabrawy", "Nile Fish House",
  ],
  recruitment: ["WUZZUF", "Forasna", "HireHunt", "Bayt Egypt", "Cairo Careers Hub", "Nile Workforce"],
  offers: ["Waffarha", "Elmenus Deals", "Talabat Offers", "Jumia Flash", "Cobone Egypt", "DealNile"],
  fashion: [
    "Brantu", "Etmana", "Sigma Fit", "In Your Shoe", "Okhtein", "Town Team",
    "Elia Designs", "Mix And Match", "Lotfy", "Palma", "Amina K", "Myne",
    "Mamzi", "SAEDI", "6901", "Shahira Lasheen", "Hany El Behairy Couture",
    "Marsy", "Nileton",
  ],
  footwear: [] as string[],
};

/** Footwear records are split exactly as the discovery spec requires:
 *  online retailers, original brands and physical stores — never merged. */
type FootGroup = "retail" | "brand" | "shop";
const FOOT_VENDORS: [string, FootGroup][] = [
  /* online retailers */
  ["GURU", "retail"], ["Top Sneaker", "retail"], ["Kick Shoe", "retail"], ["7kicks", "retail"],
  ["Fitsole", "retail"], ["Shoes Egy", "retail"], ["Urban Kicks", "retail"], ["Authentic Sneakers Egypt", "retail"],
  /* original global brands */
  ["Nike", "brand"], ["Adidas", "brand"], ["Puma", "brand"], ["New Balance", "brand"],
  ["ASICS", "brand"], ["On", "brand"], ["Reebok", "brand"], ["Under Armour", "brand"],
  ["Hoka", "brand"], ["Salomon", "brand"], ["Skechers", "brand"], ["Veja", "brand"],
  ["Onitsuka Tiger", "brand"], ["Birkenstock", "brand"], ["UGG", "brand"], ["Camper", "brand"],
  ["Vans", "brand"], ["Converse", "brand"], ["Timberland", "brand"], ["Golden Goose", "brand"],
  ["Alo", "brand"], ["Lacoste", "brand"], ["Dr. Martens", "brand"], ["Louis Vuitton", "brand"],
  /* physical Cairo stores */
  ["GURU Mohandessin", "shop"], ["GURU Citystars", "shop"], ["adidas Store Zayed", "shop"],
  ["Nike Store New Cairo", "shop"], ["New Balance New Cairo", "shop"], ["Skechers Citystars", "shop"],
  ["F60 Shoes", "shop"], ["BULGA SHOP", "shop"], ["Footcourt Egypt", "shop"],
  ["Box Sneakers", "shop"], ["Original Shoes", "shop"],
];
const FOOT_GROUP = Object.fromEntries(FOOT_VENDORS) as Record<string, FootGroup>;
VENDOR_NAMES.footwear = FOOT_VENDORS.map(([n]) => n);

/** Footwear subcategory index (matches SUBS.footwear order). */
const FOOT_SEG: Record<string, number> = {
  ASICS: 1, On: 1, "Under Armour": 1, Hoka: 1, Salomon: 1, Skechers: 1, Alo: 1,
  Reebok: 3, Veja: 3, "Onitsuka Tiger": 3, Camper: 3, Vans: 3, Converse: 3, Lacoste: 3, UGG: 3,
  Birkenstock: 5, Timberland: 6, "Dr. Martens": 6,
};

/** Origins for honest, sourceless-but-public global brand facts. */
const BRAND_ORIGIN: Record<string, string> = {
  Nike: "United States", Adidas: "Germany", Puma: "Germany", "New Balance": "United States",
  ASICS: "Japan", On: "Switzerland", Reebok: "United States", "Under Armour": "United States",
  Hoka: "France / United States", Salomon: "France", Skechers: "United States", Veja: "France",
  "Onitsuka Tiger": "Japan", Birkenstock: "Germany", UGG: "United States", Camper: "Spain",
  Vans: "United States", Converse: "United States", Timberland: "United States",
  "Golden Goose": "Italy", Alo: "United States", Lacoste: "France", "Dr. Martens": "United Kingdom",
  "Louis Vuitton": "France",
};

/** Well-known domains for flagship brands; everything else falls back to its iRoopa vendor page. */
const WEBSITE_MAP: Record<string, string> = {
  "Allianz Egypt": "https://www.allianz.com.eg",
  "AXA Egypt": "https://www.axa.com.eg",
  "Misr Insurance": "https://www.misrins.com",
  Sodic: "https://www.sodic.com",
  "Emaar Misr": "https://www.emaarmisr.com",
  "Palm Hills": "https://www.palmhillsdevelopments.com",
  "Mountain View": "https://mountainviewegypt.com",
  Fawry: "https://www.fawry.com",
  Vezeeta: "https://www.vezeeta.com",
  Swvl: "https://swvl.com",
  "Jumia Egypt": "https://www.jumia.com.eg",
  "Noon Egypt": "https://www.noon.com/egypt-en",
  "Amazon.eg": "https://www.amazon.eg",
  "Sharaf DG": "https://egypt.sharafdg.com",
  "B.TECH": "https://www.btech.com",
  Homzmart: "https://homzmart.com",
  "EFG Hermes": "https://www.efghermes.com",
  "CI Capital": "https://cicapital.com",
  "Beltone Financial": "https://beltoneholding.com",
  "GB Auto": "https://gb-corporation.com/gb-auto",
  "Mansour Automotive": "https://almansour.com.eg",
  "Abou El Sid": "https://www.abouelsid.com",
  Zooba: "https://www.zoobaeats.com",
  "Koshary Abou Tarek": "https://www.abotarek.com",
  WUZZUF: "https://wuzzuf.net",
  Forasna: "https://forasna.com",
  Waffarha: "https://www.waffarha.com",
  Elmenus: "https://www.elmenus.com",
  "Elmenus Deals": "https://www.elmenus.com",
  "Misr Travel": "https://www.misrtravel.net",
  "Travco Tours": "https://www.travco.com",
  "Memphis Tours": "https://www.memphistours.com",
  "Deluxe Tours": "https://www.deluxetoursegypt.com",
  "Blue Sky Travel": "https://www.blueskygroup.net",
  "Nomad Gallery": "https://www.nomadgallery.net",
  OKHTEIN: "https://okhtein.com",
  "Azza Fahmy": "https://azzafahmy.com",
  "Jude Benhalim": "https://judebenhalim.com",
  "Sigma Fit": "https://sigmafit.net",
  "MetLife Egypt": "https://www.metlife.eg",
  "Takaful Egypt": "https://www.egtak.com",
  "Gig Egypt": "https://www.gig.com.eg",
  "Delta Insurance": "http://www.deltains.org",
  "Mohandes Insurance": "http://www.mohins.com",
  "QNB Alahli Life": "http://www.qnblife.com.eg",
  "Suez Canal Insurance": "https://www.sci.com.eg",
  "Talaat Moustafa Group": "https://talaatmoustafa.com",
  "Hyde Park": "https://www.hydeparkdevelopments.com",
  "Ora Developers": "https://www.oradevelopers.com",
  "Hassan Allam": "https://hap.com.eg",
  Marakez: "https://marakez.net",
  "La Vista": "https://lavista.com.eg",
  "Tatweer Misr": "https://tatweermisr.com",
  "Misr Italia": "https://misritaliaproperties.com",
  Instabug: "https://www.instabug.com",
  Paymob: "https://paymob.com",
  Trella: "https://www.trella.app",
  Halan: "https://mnt-halan.com",
  Breadfast: "https://breadfast.com",
  "Talabat Egypt": "https://www.talabat.com/egypt",
  MaxAB: "https://maxab.io",
  Tradeline: "https://tradeline.com.eg",
  "El Araby": "https://elarabygroup.com",
  "Safar Khan Gallery": "https://safarkhan.com",
  "Ubuntu Art Gallery": "https://ubuntuartgallery.com",
  "Gypsum Gallery": "https://gypsumgallery.com",
  "Emo Tours Egypt": "https://www.emotours.com",
  FilKhedma: "https://filkhedma.com",
  "Bavarian Auto Group": "https://www.bmw-egypt.com",
  "El Saba Automotive": "https://elsaba-group.com",
  "Auto Samir Rayan": "https://www.auto-samirrayan.com",
  "Mohamed Al Sagheer": "https://mohamedalsagheer.com",
  "Pharos Holding": "https://pharosholding.com",
  "HC Securities": "https://www.hc-si.com",
  "Mubasher Egypt": "https://egypt.mubashertrade.com",
  Sequoia: "https://www.sequoiaonline.net",
  Sachi: "https://www.sachirestaurant.com/home",
  "Pier 88": "https://pier88group.com",
  Felfela: "https://felfela.com",
  Gad: "https://gad.com.eg",
  "El Shabrawy": "https://elshabrawyelasly.com",
  "Prime Securities": "https://www.primegroup.org",
  HireHunt: "https://hirehunt.com",
  "Bayt Egypt": "https://www.bayt.com",
  "Cobone Egypt": "https://www.cobone.com",
  "Jumia Flash": "https://www.jumia.com.eg",
  "Talabat Offers": "https://www.talabat.com/egypt",
  ZAAM: "https://zaam.studio",
  "Sabry Marouf": "https://sabrymarouf.com",
  "Up-fuse": "https://up-fuse.com",
  "Sami Amin": "https://samiamin.com",
  Concrete: "https://concrete.com.eg",
  "Maison Yeya": "https://maisonyeya.com",
  "Amina K": "https://aminak.net",
  "Dina Shaker": "https://dinashaker.com",
  Malameh: "https://malameh.com",
  VALOR: "https://valor-fashion.com",
  MEM: "https://memthebrand.com",
  AWAN: "https://aswearenow.co",
  TENU: "https://tenu-eg.com",
  Frenchee: "https://frencheethelabel.com",
  LAQTA: "https://laqta.store",
  "El-Outlet": "https://eloutleteg.com",
  JLOOD: "https://jlood.com",
  /* footwear — online retailers (user-supplied, website_found) */
  GURU: "https://guruonline.store",
  "Top Sneaker": "https://top-sneaker.com",
  "Kick Shoe": "https://kickshoe.store",
  "7kicks": "https://7kicks.store",
  Fitsole: "https://fitsole.shop",
  "Shoes Egy": "https://shoesegy.com",
  "Urban Kicks": "https://urbankicksco.com",
  "Authentic Sneakers Egypt": "https://authenticsneakers-egy.com",
  /* footwear — original global brands */
  Nike: "https://www.nike.com",
  Adidas: "https://www.adidas.com",
  Puma: "https://www.puma.com",
  "New Balance": "https://www.newbalance.com",
  ASICS: "https://www.asics.com",
  On: "https://www.on.com",
  Reebok: "https://www.reebok.com",
  "Under Armour": "https://www.underarmour.com",
  Hoka: "https://www.hoka.com",
  Salomon: "https://www.salomon.com",
  Skechers: "https://www.skechers.com",
  Veja: "https://www.veja-store.com",
  "Onitsuka Tiger": "https://www.onitsukatiger.com",
  Birkenstock: "https://www.birkenstock.com",
  UGG: "https://www.ugg.com",
  Camper: "https://www.camper.com",
  Vans: "https://www.vans.com",
  Converse: "https://www.converse.com",
  Timberland: "https://www.timberland.com",
  "Golden Goose": "https://www.goldengoose.com",
  Alo: "https://www.aloyoga.com",
  Lacoste: "https://www.lacoste.com",
  "Dr. Martens": "https://www.drmartens.com",
  "Louis Vuitton": "https://www.louisvuitton.com",
  Mamzi: "https://mamzistore.com",
  SAEDI: "https://saedi.co",
  "6901": "https://6901cairo.com",
  "Shahira Lasheen": "https://www.shahiralasheen.com",
  "Izzy Apparel": "https://izzyapparel.com",
  "Hany El Behairy Couture": "https://hanyelbehairy.com",
  Marsy: "https://shopmarsy.com",
  Nileton: "https://nileton.com",
  Myne: "https://mynethelabel.co",
  "In Your Shoe": "https://inyourshoe.com",
  Brantu: "https://brantu.com",
  Etmana: "https://etmana.com",
  Okhtein: "https://okhtein.com",
  "Town Team": "https://townteam.com",
  "Mix And Match": "https://mixandmatcheg.com",
  Lotfy: "https://lotfy.com",
  Palma: "https://getpalma.com",
};

/**
 * Audited official profiles. A missing channel is intentional: it was not
 * confirmed from an official site/account, so the UI must not invent it.
 */
const SOCIALS_MAP: Record<string, NonNullable<Vendor["socials"]>> = {
  "Allianz Egypt": {
    instagram: "https://www.instagram.com/allianzegypt/",
    facebook: "https://www.facebook.com/allianzegypt/",
    tiktok: "https://www.tiktok.com/@allianz.egypt",
    youtube: "https://www.youtube.com/channel/UCMhyPJp4DIbDcrxbzqGn9RQ",
  },
  "AXA Egypt": {
    instagram: "https://www.instagram.com/axa_egypt/",
    facebook: "https://www.facebook.com/AXAEgypt/",
    youtube: "https://www.youtube.com/channel/UCiaMIvI4C-Z7jDr4zerqJ_w",
  },
  "MetLife Egypt": {
    instagram: "https://www.instagram.com/metlife.egypt/",
    facebook: "https://www.facebook.com/MetLifeEgypt/",
  },
  "Misr Insurance": {
    instagram: "https://www.instagram.com/misrinsuranceofficial/",
  },
  "Emaar Misr": {
    instagram: "https://www.instagram.com/emaarmisr/",
    facebook: "https://www.facebook.com/Emaar.Misr.Community/",
    tiktok: "https://www.tiktok.com/@emaarmisr",
    youtube: "https://www.youtube.com/@Emaaregypt",
  },
  "Mountain View": {
    instagram: "https://www.instagram.com/mountainview_egypt/",
  },
  Sodic: {
    instagram: "https://www.instagram.com/sodicrealestate/",
    facebook: "https://www.facebook.com/SODICRealEstate/",
    tiktok: "https://www.tiktok.com/@sodicrealestate",
    youtube: "https://www.youtube.com/user/SODICChannel",
  },
  "Palm Hills": {
    instagram: "https://www.instagram.com/PalmHillsDevelopments/",
    facebook: "https://www.facebook.com/PalmHillsDevelopments/",
    youtube: "https://www.youtube.com/user/PalmHillsDev",
  },
  "Talaat Moustafa Group": {
    instagram: "https://www.instagram.com/talaatmoustafagroup/",
    tiktok: "https://www.tiktok.com/@talaatmoustafagroup",
  },
  "Hyde Park": {
    instagram: "https://www.instagram.com/hydeparkdevelopments/",
    facebook: "https://www.facebook.com/HydeParkDevelopments/",
    youtube: "https://www.youtube.com/@HydeParkDevelopment",
  },
  "Ora Developers": {
    facebook: "https://www.facebook.com/OraEgypt1/",
  },
  "Hassan Allam": {
    instagram: "https://www.instagram.com/hassanallamproperties/",
    facebook: "https://www.facebook.com/HassanAllamProperties/",
  },
  "Tatweer Misr": {
    instagram: "https://www.instagram.com/tatweer.misr/",
    facebook: "https://www.facebook.com/TatweerMisrDevelopments",
    tiktok: "https://www.tiktok.com/@tatweer.misr",
    youtube: "https://www.youtube.com/channel/UCYDoqZf8JS-Byp4YQy77NQw",
  },
  "La Vista": {
    facebook: "https://www.facebook.com/Lavistates/",
  },
  Vezeeta: {
    instagram: "https://www.instagram.com/vezeeta/",
  },
  Paymob: {
    instagram: "https://www.instagram.com/paymobegypt/",
    youtube: "https://www.youtube.com/@PaymobEgypt",
  },
  Swvl: {
    instagram: "https://www.instagram.com/swvlapp/",
    facebook: "https://www.facebook.com/swvlapp/",
    youtube: "https://www.youtube.com/@swvl5971",
  },
  Halan: {
    instagram: "https://www.instagram.com/halanapp/",
  },
  Breadfast: {
    instagram: "https://www.instagram.com/breadfast/",
    tiktok: "https://www.tiktok.com/@breadfast_official",
  },
  Trella: {
    facebook: "https://www.facebook.com/trellaapp/",
  },
  MaxAB: {
    facebook: "https://www.facebook.com/MaxABco/",
  },
  Fawry: {
    instagram: "https://www.instagram.com/fawrypayments/",
    youtube: "https://www.youtube.com/user/Fawrypayments",
  },
  "Jumia Egypt": {
    instagram: "https://www.instagram.com/jumiaegypt/",
    facebook: "https://www.facebook.com/p/Jumia-100068403391761/",
    youtube: "https://www.youtube.com/user/JumiaEgypt",
  },
  "Noon Egypt": {
    instagram: "https://www.instagram.com/noon.eg/",
    facebook: "https://www.facebook.com/noon.eg/",
  },
  "Sharaf DG": {
    instagram: "https://www.instagram.com/sharafdgegypt/",
    facebook: "https://www.facebook.com/SharafDGEgypt",
  },
  "B.TECH": {
    instagram: "https://www.instagram.com/mybtech/",
    facebook: "https://www.facebook.com/btech.eg",
    tiktok: "https://www.tiktok.com/@mybtech",
    youtube: "https://www.youtube.com/channel/UCb38BG_mMf7BUumTVc10gAw",
  },
  Homzmart: {
    facebook: "https://www.facebook.com/homzmartegypt/",
    instagram: "https://www.instagram.com/homzmart/",
    tiktok: "https://www.tiktok.com/@homzmart",
  },
  "Misr Travel": {
    instagram: "https://www.instagram.com/misrtravelegypt/",
    facebook: "https://www.facebook.com/misrtravel90/",
    youtube: "https://www.youtube.com/@misrtravel6814",
  },
  "Travco Tours": {
    instagram: "https://www.instagram.com/travcotravel/",
    facebook: "https://www.facebook.com/Travcotravelco/",
  },
  "Emo Tours Egypt": {
    instagram: "https://www.instagram.com/emo_tour_egypt/",
    facebook: "https://www.facebook.com/Emo.Tours",
    youtube: "https://www.youtube.com/@EmoToursEgypt",
  },
  "Memphis Tours": {
    instagram: "https://www.instagram.com/memphistours/",
    facebook: "https://www.facebook.com/memphistours/",
    youtube: "https://www.youtube.com/user/toursinegypt",
  },
  "Mansour Automotive": {
    instagram: "https://www.instagram.com/mansourautomotive/",
    facebook: "https://www.facebook.com/Mansourautomotive/",
  },
  "Bavarian Auto Group": {
    instagram: "https://www.instagram.com/bmwegypt/",
    facebook: "https://www.facebook.com/BMWEgypt",
    youtube: "https://www.youtube.com/user/BMWEgy",
  },
  "GB Auto": {
    instagram: "https://www.instagram.com/gbautogroup/",
    facebook: "https://www.facebook.com/p/GB-Auto-61572167966054/",
  },
  "Auto Samir Rayan": {
    instagram: "https://www.instagram.com/autosamirrayan/",
    facebook: "https://www.facebook.com/AutoSamirRayanCompany/",
  },
  "El Saba Automotive": {
    facebook: "https://www.facebook.com/Elsaba.Automotive/",
  },
  "EFG Hermes": {
    instagram: "https://www.instagram.com/efgholdingofficial/",
    facebook: "https://www.facebook.com/EFGHolding/",
  },
  "Beltone Financial": {
    facebook: "https://www.facebook.com/Beltoneholding/",
    instagram: "https://www.instagram.com/beltone_holding/",
  },
  "CI Capital": {
    instagram: "https://www.instagram.com/cicapital.cich/",
    facebook: "https://www.facebook.com/CICapitalHolding/",
  },
  "Mubasher Egypt": {
    instagram: "https://www.instagram.com/mubashertradeegypt/",
    facebook: "https://www.facebook.com/MubasherTradeEG",
    youtube: "https://www.youtube.com/@Mubashertrade",
  },
  "Abou El Sid": {
    instagram: "https://www.instagram.com/abouelsid/",
    facebook: "https://www.facebook.com/AbouElSidRestaurant/",
  },
  "Koshary Abou Tarek": {
    instagram: "https://www.instagram.com/koshariabotarek/",
    facebook: "https://www.facebook.com/KoshariAbuTarekEgypt/",
    tiktok: "https://www.tiktok.com/@koshariaboutarek",
  },
  Zooba: {
    instagram: "https://www.instagram.com/zooba/",
    facebook: "https://www.facebook.com/ZoobaEats",
  },
  WUZZUF: {
    facebook: "https://www.facebook.com/wuzzuf/",
    youtube: "https://www.youtube.com/user/wuzzuf",
  },
  Forasna: {
    instagram: "https://www.instagram.com/forasna/",
    facebook: "https://www.facebook.com/Forasna/",
    tiktok: "https://www.tiktok.com/@forasna.com",
  },
  OKHTEIN: {
    instagram: "https://www.instagram.com/okhtein/",
  },
  "Azza Fahmy": {
    instagram: "https://www.instagram.com/azzafahmy/",
    facebook: "https://www.facebook.com/AzzaFahmy/",
    youtube: "https://www.youtube.com/azzafahmy",
  },
  "Jude Benhalim": {
    instagram: "https://www.instagram.com/jude.benhalim/",
    facebook: "https://www.facebook.com/JudeBenhalimJewelry",
    tiktok: "https://www.tiktok.com/@judebenhalim",
  },
  "Amina K": {
    instagram: "https://www.instagram.com/aminak_egypt/",
    facebook: "https://www.facebook.com/AminaK.Egypt/",
  },
  "Sigma Fit": {
    instagram: "https://www.instagram.com/sigmafitegypt/",
    youtube: "https://www.youtube.com/@sigmafitegypt3849",
  },
  UNTY: {
    instagram: "https://www.instagram.com/untydesigns/",
  },
  "Izzy Apparel": {
    instagram: "https://www.instagram.com/izzyapparel/",
    facebook: "https://www.facebook.com/izzyapparel",
    tiktok: "https://www.tiktok.com/@izzyapparel",
  },
  Rizq: {
    instagram: "https://www.instagram.com/rizq.eg/",
  },
  Manza: {
    instagram: "https://www.instagram.com/manzanaegypt/",
  },
  "Gig Egypt": {
    facebook: "https://www.facebook.com/gigegypt",
  },
  "Deluxe Tours": {
    facebook: "https://www.facebook.com/deluxetoursegypt",
  },
  "Blue Sky Travel": {
    facebook: "https://www.facebook.com/Blueskytravelcairo",
  },
  "Mohamed Al Sagheer": {
    facebook: "https://www.facebook.com/alsagheersalons",
  },
  Sachi: {
    instagram: "https://www.instagram.com/sachirestaurants/",
    facebook: "https://www.facebook.com/sachirestaurants",
  },
  "Pier 88": {
    instagram: "https://www.instagram.com/pier88egypt/",
    facebook: "https://www.facebook.com/Pier88Egypt/",
  },
  Felfela: {
    facebook: "https://www.facebook.com/felfela.news/",
  },
  "El Shabrawy": {
    facebook: "https://www.facebook.com/alshabrawyres/",
  },
  ZAAM: {
    instagram: "https://www.instagram.com/zaamofficial/",
  },
  MEM: {
    instagram: "https://www.instagram.com/mem.thebrand/",
  },
  Frenchee: {
    instagram: "https://www.instagram.com/frencheethelabel/",
  },
  LAQTA: {
    instagram: "https://www.instagram.com/laqta_eg/",
  },
  Mamzi: {
    instagram: "https://www.instagram.com/mamzi.eg/",
  },
  SAEDI: {
    instagram: "https://www.instagram.com/saedi.co/",
  },
  "6901": {
    instagram: "https://www.instagram.com/6901cairo/",
  },
  "Shahira Lasheen": {
    instagram: "https://www.instagram.com/shahiralasheenbridal/",
    facebook: "https://www.facebook.com/shahiralasheenatelier",
  },
  "Nesma Helmy Bridal": {
    facebook: "https://www.facebook.com/nesmahelmydesigns",
  },
  TENU: {},
  Concrete: {
    instagram: "https://www.instagram.com/concreteclothing.co/",
  },
  Waffarha: {
    instagram: "https://www.instagram.com/waffarha/",
    facebook: "https://www.facebook.com/Waffarha/",
    tiktok: "https://www.tiktok.com/@waffarha",
    youtube: "https://www.youtube.com/@waffarha",
  },
  "Elmenus Deals": {
    instagram: "https://www.instagram.com/elmenus/",
    facebook: "https://www.facebook.com/elmenus",
  },
  Gad: {
    facebook: "https://www.facebook.com/gadrestaurant.eg/",
  },
  "El-Outlet": {
    instagram: "https://www.instagram.com/eloutleteg/",
    facebook: "https://www.facebook.com/Eloutletegypt",
  },
  JLOOD: {
    instagram: "https://www.instagram.com/jlood.shop/",
    facebook: "https://www.facebook.com/jlood.shop/",
    tiktok: "https://www.tiktok.com/@jlood_official",
    youtube: "https://www.youtube.com/@jlood-shop",
  },
  GURU: {
    instagram: "https://www.instagram.com/gurustore_eg/",
  },
  "7kicks": {
    instagram: "https://www.instagram.com/7kicks_eg/",
  },
  Fitsole: {
    instagram: "https://www.instagram.com/fitsole.egypt/",
    facebook: "https://www.facebook.com/pages/category/Clothing--Brand-/FitSole-492093894305386/",
  },
  "Urban Kicks": {
    instagram: "https://www.instagram.com/urbankicksco/",
    tiktok: "https://www.tiktok.com/@urbankicksco",
  },
  Nike: {
    instagram: "https://www.instagram.com/nike/",
    facebook: "https://www.facebook.com/nike",
    tiktok: "https://www.tiktok.com/@nike",
    youtube: "https://www.youtube.com/@nike",
  },
  Adidas: {
    instagram: "https://www.instagram.com/adidas/",
  },
  Puma: {
    instagram: "https://www.instagram.com/puma/",
  },
  "New Balance": {
    instagram: "https://www.instagram.com/newbalance/",
    facebook: "https://www.facebook.com/newbalance",
  },
  ASICS: {
    instagram: "https://www.instagram.com/asics/",
    facebook: "https://www.facebook.com/ASICS",
    youtube: "https://www.youtube.com/user/asics",
  },
  "Under Armour": {
    instagram: "https://www.instagram.com/underarmour/",
  },
  Reebok: {
    instagram: "https://www.instagram.com/reebok/",
    facebook: "https://www.facebook.com/Reebok/",
    youtube: "https://www.youtube.com/reebok",
  },
  Hoka: {
    instagram: "https://www.instagram.com/hoka/",
  },
  Salomon: {
    instagram: "https://www.instagram.com/salomonrunning/",
  },
  Skechers: {
    instagram: "https://www.instagram.com/skechers/",
  },
  Veja: {
    instagram: "https://www.instagram.com/veja/",
    facebook: "https://www.facebook.com/veja.fairtrade/",
    tiktok: "https://www.tiktok.com/@veja",
    youtube: "https://www.youtube.com/@vejastore",
  },
  "Onitsuka Tiger": {
    instagram: "https://www.instagram.com/onitsukatigerofficial/",
    facebook: "https://www.facebook.com/onitsukatiger",
  },
  Birkenstock: {
    tiktok: "https://www.tiktok.com/@birkenstock",
  },
  Vans: {
    instagram: "https://www.instagram.com/vans/",
    facebook: "https://www.facebook.com/VANS/",
  },
  Timberland: {
    instagram: "https://www.instagram.com/timberland/",
  },
  Alo: {
    instagram: "https://www.instagram.com/aloyoga/",
    youtube: "https://www.youtube.com/c/aloyoga",
  },
  "Dr. Martens": {
    instagram: "https://www.instagram.com/drmartensofficial/",
    facebook: "https://www.facebook.com/drmartens/",
    tiktok: "https://www.tiktok.com/@drmartens",
  },
  Brantu: {
    instagram: "https://www.instagram.com/brantu_official/",
    facebook: "https://www.facebook.com/BrantuOfficial/",
  },
  Etmana: {
    instagram: "https://www.instagram.com/etmana_official/",
  },
  "In Your Shoe": {
    instagram: "https://www.instagram.com/in.your.shoe/",
    facebook: "https://www.facebook.com/inyourshoe/",
  },
  "Town Team": {
    instagram: "https://www.instagram.com/townteam/",
    facebook: "https://www.facebook.com/townteam/",
  },
  Palma: {
    instagram: "https://www.instagram.com/getpalma/",
    facebook: "https://www.facebook.com/getpalma/",
  },
};

const CONTACT_MAP: Record<
  string,
  { hotline?: string; whatsapp?: string; mapUrl?: string; mapQuery?: string }
> = {
  "Allianz Egypt": { hotline: "19909" },
  "AXA Egypt": {
    hotline: "16363",
    mapQuery: "AXA Egypt, Plot 214, Sector 2, Fifth Settlement, Cairo, Egypt",
  },
  "MetLife Egypt": { hotline: "0224616500" },
  "Jumia Egypt": { hotline: "19586" },
  "B.TECH": { hotline: "19966" },
  "Mansour Automotive": {
    hotline: "16424",
    mapQuery: "Mansour Automotive, 26th of July Corridor, Giza, Egypt",
  },
  "GB Auto": {
    hotline: "16661",
    mapQuery: "GB Auto, Cairo Alexandria Desert Road, Abu Rawash, Giza, Egypt",
  },
  "El Saba Automotive": { hotline: "16449" },
  "Auto Samir Rayan": {
    hotline: "0223421540",
    mapQuery: "Auto Samir Rayan, El Nasr Road, Cairo, Egypt",
  },
  "Talaat Moustafa Group": { hotline: "0233016701" },
  "Ora Developers": {
    hotline: "15003",
    mapQuery: "Ora Developers, Nile City Towers, Corniche El Nile, Cairo, Egypt",
  },
  "Hassan Allam": {
    hotline: "01144554487",
    mapQuery: "Hassan Allam Properties, Building 67, Southern Road 90, New Cairo, Egypt",
  },
  "Tatweer Misr": {
    hotline: "16094",
    mapQuery: "Tatweer Misr, Building 8, Arkan Plaza, Sheikh Zayed, Giza, Egypt",
  },
  "La Vista": { hotline: "16063" },
  "CI Capital": { hotline: "16440" },
  "Mubasher Egypt": {
    hotline: "16699",
    mapQuery: "Mubasher Trade Egypt, 22A Anwar El Mofty St, Nasr City, Cairo, Egypt",
  },
  Sachi: {
    hotline: "01280902028",
    mapQuery: "Sachi, 3 Cleopatra St, Korba, Heliopolis, Cairo, Egypt",
  },
  "Pier 88": {
    hotline: "01208111130",
    mapQuery: "Pier 88, Zamalek, Cairo, Egypt",
  },
  Waffarha: { hotline: "16457" },
  Gad: {
    hotline: "16536",
    mapQuery: "GAD Restaurant, 63 Farid Semeika St, Heliopolis, Cairo, Egypt",
  },
  "El Shabrawy": { hotline: "15263" },
  Felfela: {
    hotline: "0233761234",
    mapQuery: "Felfela, 27 Cairo Alexandria Road, Remaya Square, Giza, Egypt",
  },
  "Prime Securities": {
    hotline: "0233005770",
    mapQuery: "Prime Securities, 2 Wadi El Nil St, Mohandessin, Giza, Egypt",
  },
  "Abou El Sid": { hotline: "0227359640" },
  Zooba: { hotline: "16082" },
  "Travco Tours": {
    hotline: "0238541010",
    mapQuery: "Travco Travel, 26th of July Corridor, Sheikh Zayed, Egypt",
  },
  "Emo Tours Egypt": {
    hotline: "01141510735",
    mapQuery: "Emo Tours Egypt, 52 El Saraya Plaza Towers, Zaghloul St, Giza, Egypt",
  },
  "Misr Travel": {
    hotline: "01283935689",
    mapQuery: "Misr Travel, Abbassia Square, Cairo, Egypt",
  },
  JLOOD: {
    hotline: "01210999980",
    whatsapp: "201210999980",
    mapUrl: "https://maps.app.goo.gl/9dX1gLkewpGXoqG69",
    mapQuery: "JLOOD, 20 Abbas Al-Akkad, Nasr City, Cairo, Egypt",
  },
  GURU: {
    hotline: "01066651650",
    mapQuery: "GURU, 32 Lebanon Street, Mohandessin, Giza, Egypt",
  },
  Fitsole: {
    hotline: "01068433440",
    mapQuery: "Fitsole, Downtown Ismailia, 173 El Tahrir St, Ismailia, Egypt",
  },
  /* physical footwear stores — addresses from the discovery directory */
  "QNB Alahli Life": {
    hotline: "19753",
    mapQuery: "QNB Alahli Life Insurance, Gezeriat El Arab St, Mohandessin, Giza, Egypt",
  },
  "Gig Egypt": {
    hotline: "0221260800",
    mapQuery: "GIG Egypt, Block H, Northern 90th St, Fifth Settlement, New Cairo, Egypt",
  },
  "Delta Insurance": {
    hotline: "0233352045",
    mapQuery: "Delta Insurance Company, 14 Hassan Mohamed Al Razzaz St, Agouza, Giza, Egypt",
  },
  "Mohandes Insurance": {
    mapQuery: "Mohandes Insurance, 3 Messaha Square, Dokki, Giza, Egypt",
  },
  "Blue Sky Travel": {
    mapQuery: "Blue Sky Travel, 44 Shehab Street, Mohandessin, Giza, Egypt",
  },
  "Mohamed Al Sagheer": {
    hotline: "01032032885",
    mapQuery: "Al Sagheer Salons, 16 Salah El-Din St, Zamalek, Cairo, Egypt",
  },
  "Nomad Gallery": {
    hotline: "0227361917",
    mapQuery: "Nomad Gallery, 14 Saray Elgezira St, Zamalek, Cairo, Egypt",
  },
  "Misr Italia": { hotline: "16519" },
  "GURU Mohandessin": {
    hotline: "01066651650",
    mapQuery: "GURU, 32 Lebanon Street, Mohandessin, Giza, Egypt",
  },
  "GURU Citystars": { mapQuery: "GURU, Citystars Mall, Nasr City, Cairo, Egypt" },
  "adidas Store Zayed": { mapQuery: "adidas Store, Walk of Cairo Mall, Sheikh Zayed, Egypt" },
  "Nike Store New Cairo": { mapQuery: "Nike Store, New Cairo, Cairo, Egypt" },
  "New Balance New Cairo": { mapQuery: "New Balance Store, New Cairo, Cairo, Egypt" },
  "Skechers Citystars": { mapQuery: "Skechers, Citystars Mall, Nasr City, Cairo, Egypt" },
  "F60 Shoes": { mapQuery: "F60 Shoes, 173, 26th of July Street, Zamalek, Cairo, Egypt" },
  "BULGA SHOP": { mapQuery: "BULGA SHOP, 6 Al Nabarawy Street, Downtown Cairo, Egypt" },
  "Footcourt Egypt": { mapQuery: "Footcourt Egypt, 8th District, Giza, Egypt" },
  "Box Sneakers": { mapQuery: "Box Sneakers, King Faisal Street, Giza, Egypt" },
  "Original Shoes": { mapQuery: "Original Shoes, Ard El Golf, Heliopolis, Cairo, Egypt" },
  Brantu: { hotline: "19000" },
  Etmana: { hotline: "19001" },
  Okhtein: { hotline: "01000000000" },
  "Town Team": { hotline: "19999" },
  "Mix And Match": { hotline: "01284030103" },
  Lotfy: { hotline: "19002" },
  Palma: { hotline: "19003" },
  "Amina K": { hotline: "01277037546" },
};

/** Hostname for a vendor (drives real logo lookups). Null = no public brand domain. */
export function vendorHost(website: string): string | null {
  try {
    const h = new URL(website).hostname.replace(/^www\./, "");
    return h.endsWith("iroopa.app") ? null : h;
  } catch {
    return null;
  }
}

/** Real Egyptian fashion brands → catalogue segment index (matches SUBS.fashion). */
const FASHION_BRANDS: [string, number][] = [
  /* streetwear & contemporary */
  ["Marsy", 1], ["UNTY", 1], ["Al Camileon", 1], ["RebelCairo", 1], ["Be-Indie", 1],
  ["In Your Shoe", 1], ["REDNM", 1], ["Cizaro", 1], ["QALEB", 1], ["VALOR", 1],
  ["6901", 1], ["NOMINA", 1], ["TENU", 1], ["LAQTA", 1], ["Frenchee", 1],
  /* women's ready-to-wear */
  ["Mamzi", 0], ["Myne", 0], ["SAEDI", 0], ["Amina K", 0], ["Maison Yeya", 0],
  ["Dina Shaker", 0], ["Marie Louis", 0], ["Rasha Pasha", 0], ["Talalya", 0],
  ["Manza", 0], ["Mazoura", 0], ["Paz.Cairo", 0],
  /* bags & leather */
  ["OKHTEIN", 5], ["ZAAM", 5], ["Sabry Marouf", 5], ["Up-fuse", 5], ["Sami Amin", 5],
  /* jewelry */
  ["Azza Fahmy", 4], ["Jude Benhalim", 4], ["Nadine Chamaa", 4], ["Reem Jano", 4], ["Nevin Altmann", 4],
  /* activewear */
  ["Sigma Fit", 8], ["Izzy Apparel", 8], ["Nileton", 8], ["KAF Wear", 8], ["BF Sportswear", 8], ["LA7 Wear", 8],
  /* modest */
  ["Malameh", 2], ["Rizq", 2], ["AWAN", 2], ["MEM", 2],
  /* men's basics & loungewear */
  ["Concrete", 9], ["Cottonwear", 9], ["Blu Loungewear", 9],
  /* denim */
  ["Blue Era Denim", 3], ["Nile Denim Works", 3],
  /* bridal & couture */
  ["Hany El Behairy Couture", 7], ["Shahira Lasheen", 7], ["Nesma Helmy Bridal", 7],
  /* footwear */
  ["Cairo Sole", 6], ["ELIO Shoes", 6],
  /* fashion marketplaces / discovery sources */
  ["El-Outlet", 6], ["JLOOD", 6],
  /* kids & swim */
  ["Little Oasis", 10], ["Minies Cairo", 10], ["Salty Swim Cairo", 10],
  /* manufacturers / private label */
  ["Klikfab", 11], ["Garment EG", 11], ["Kemet Garment", 11], ["StitchCo", 11], ["Zayed Clothing", 11],
];
const FASHION_SEG = Object.fromEntries(FASHION_BRANDS) as Record<string, number>;
VENDOR_NAMES.fashion = FASHION_BRANDS.map(([n]) => n);

const PRODUCT_NAMES: Record<SectorKey, { n: string; min: number; max: number }[]> = {
  insurance: [
    { n: "Comprehensive Car Cover", min: 6500, max: 24000 }, { n: "Family Health Plan", min: 9000, max: 42000 },
    { n: "Home Protection Pack", min: 2400, max: 9800 }, { n: "Travel Safe Annual", min: 1200, max: 5400 },
    { n: "SME Business Cover", min: 7500, max: 38000 },
  ],
  realestate: [
    { n: "2BR Corniche Apartment", min: 1900000, max: 4200000 }, { n: "Garden Duplex, New Cairo", min: 3600000, max: 7200000 },
    { n: "Studio by the Sea", min: 850000, max: 1950000 }, { n: "Penthouse Sky Suite", min: 6400000, max: 12500000 },
    { n: "Townhouse North Coast", min: 4200000, max: 9800000 },
  ],
  startup: [
    { n: "MVP Sprint Package", min: 55000, max: 140000 }, { n: "Pitch Deck Studio", min: 9000, max: 26000 },
    { n: "Cloud Setup Kit", min: 12000, max: 38000 }, { n: "Growth Retainer (1 mo)", min: 24000, max: 72000 },
    { n: "AI Prototype Build", min: 68000, max: 210000 },
  ],
  ecommerce: [
    { n: "Wireless Earbuds Max", min: 1450, max: 3900 }, { n: "Smart Watch Series S", min: 3200, max: 8900 },
    { n: "4K Action Cam", min: 5400, max: 12500 }, { n: "Bluetooth Party Speaker", min: 1800, max: 4600 },
    { n: "Gaming Mouse RGB", min: 650, max: 2400 },
  ],
  antiques: [
    { n: "Brass Lotus Lamp", min: 2400, max: 9800 }, { n: "Ottoman Ink Set", min: 1850, max: 6200 },
    { n: "Pharaonic Replica Bust", min: 3200, max: 14000 }, { n: "Vintage Kodak Camera", min: 4800, max: 22000 },
    { n: "Mother-of-Pearl Box", min: 1450, max: 7600 },
  ],
  tourism: [
    { n: "3-Night Nile Cruise", min: 9800, max: 26000 }, { n: "Desert Safari Day", min: 1350, max: 3900 },
    { n: "Hot Air Balloon Ride", min: 3400, max: 7200 }, { n: "Red Sea Dive Pack", min: 4600, max: 11800 },
    { n: "Cairo City Pass", min: 850, max: 2400 },
  ],
  homes: [
    { n: "Deep Clean — 3BR", min: 950, max: 2400 }, { n: "AC Service Visit", min: 350, max: 950 },
    { n: "Plumbing Emergency Call", min: 450, max: 1400 }, { n: "Paint Room Refresh", min: 1800, max: 5200 },
    { n: "Pest Control Season", min: 750, max: 2100 },
  ],
  automotive: [
    { n: "Ceramic Coating Pack", min: 9500, max: 26000 }, { n: "Full Interior Detail", min: 1800, max: 5400 },
    { n: "Dash Cam Pro", min: 2400, max: 6800 }, { n: "Leather Seat Kit", min: 12000, max: 38000 },
    { n: "PPF Front Kit", min: 16000, max: 54000 },
  ],
  salon: [
    { n: "Signature Haircut", min: 250, max: 900 }, { n: "Keratin Treatment", min: 1400, max: 4200 },
    { n: "Bridal Package", min: 4800, max: 14000 }, { n: "Beard Sculpt + Hot Towel", min: 180, max: 650 },
    { n: "Spa Day Pass", min: 950, max: 3200 },
  ],
  stocks: [
    { n: "Starter Portfolio Call", min: 500, max: 1800 }, { n: "Pro Trading Course", min: 4500, max: 14000 },
    { n: "Market Signals (1 mo)", min: 900, max: 3200 }, { n: "Wealth Planning Session", min: 2200, max: 6800 },
    { n: "IPO Alerts Annual", min: 1800, max: 5400 },
  ],
  restaurants: [
    { n: "Chef Tasting Menu", min: 1200, max: 3400 }, { n: "Mixed Grill Platter", min: 420, max: 1250 },
    { n: "Sea Bass, Nile Style", min: 380, max: 980 }, { n: "Family Koshary Box", min: 180, max: 520 },
    { n: "Friday Brunch for 2", min: 650, max: 1900 },
  ],
  recruitment: [
    { n: "CV Rewrite Pro", min: 800, max: 2600 }, { n: "Interview Coaching (2h)", min: 1200, max: 4200 },
    { n: "Team Hiring Sprint", min: 18000, max: 65000 }, { n: "Exec Search Retainer", min: 45000, max: 150000 },
    { n: "Salary Benchmark Report", min: 3400, max: 9800 },
  ],
  offers: [
    { n: "50% Brunch Voucher", min: 199, max: 699 }, { n: "Spa Day — 40% Off", min: 449, max: 1499 },
    { n: "Laptop Flash Deal", min: 8999, max: 19999 }, { n: "Buy 1 Get 1 — Salon", min: 299, max: 999 },
    { n: "Cruise Early-Bird", min: 4999, max: 12499 },
  ],
  fashion: [
    { n: "Heavyweight 500GSM Tee", min: 450, max: 700 }, { n: "Oversized Hoodie 400GSM", min: 650, max: 1100 },
    { n: "Linen Midi Dress", min: 900, max: 2400 }, { n: "Statement Gold Cuff", min: 1800, max: 5400 },
    { n: "Modest Maxi Abaya", min: 900, max: 2000 }, { n: "Private-Label Run (300 pcs)", min: 9000, max: 24000 },
  ],
  footwear: [],
};

interface FashionSeed {
  name: string;
  price: number;
  sale?: number | null;
  description: string;
  sourceLabel: string;
  checkedAt: string;
}

/** Audited official catalogue records. These override generated directory rows. */
const AUDITED_PRODUCTS: Record<string, FashionSeed[]> = {
  GURU: [
    {
      name: "Adidas Runfalcon 5 EL I — Kids' Running",
      price: 3399,
      sale: 2719.2,
      description: "Catalog sample: kids' running shoes. Refresh price and size availability from GURU before purchase.",
      sourceLabel: "guruonline.store · catalogue sample",
      checkedAt: "2026-06",
    },
  ],
  "Top Sneaker": [
    {
      name: "Adidas Samba Jane — Lifestyle",
      price: 5500,
      sale: 4500,
      description: "Catalog sample from Top Sneaker; verified price at time of cataloguing. Variants may differ.",
      sourceLabel: "top-sneaker.com · catalogue sample",
      checkedAt: "2026-06",
    },
  ],
  "Kick Shoe": [
    {
      name: "New Balance 1906D Protection Pack — Triple Black",
      price: 6000,
      sale: 3800,
      description: "Catalog sample from Kick Shoe; verify size availability before ordering.",
      sourceLabel: "kickshoe.store · catalogue sample",
      checkedAt: "2026-06",
    },
  ],
  MEM: [
    {
      name: "Aria Dress",
      price: 1250,
      description: "Official Summer 26 modest dress from MEM The Brand.",
      sourceLabel: "memthebrand.com",
      checkedAt: "2026-06",
    },
    {
      name: "Aura Long Chemise",
      price: 1050,
      sale: 750,
      description: "Official long chemise from MEM, listed on sale.",
      sourceLabel: "memthebrand.com",
      checkedAt: "2026-06",
    },
    {
      name: "Basic Top",
      price: 400,
      description: "Official basic top from MEM.",
      sourceLabel: "memthebrand.com",
      checkedAt: "2026-06",
    },
    {
      name: "MEM Signature Set",
      price: 1500,
      description: "Official matching set from MEM The Brand.",
      sourceLabel: "memthebrand.com",
      checkedAt: "2026-06",
    },
  ],
  VALOR: [
    {
      name: "Fall 7 Rise 8 Hoodie",
      price: 1099,
      sale: 799,
      description: "Official hoodie listed by VALOR Egypt.",
      sourceLabel: "valor-fashion.com",
      checkedAt: "2026-06",
    },
  ],
  TENU: [
    {
      name: "Winged Ankh Fitted T-Shirt",
      price: 900,
      sale: 599,
      description: "Official fitted T-shirt from TENU Egypt.",
      sourceLabel: "tenu-eg.com",
      checkedAt: "2026-06",
    },
  ],
};

/** One catalogue category per vendor sector — every vendor maps 1:1. */
const CATS: { slug: string; name: string; subs: string[]; pool: PoolKey }[] = SECTORS.map((s) => ({
  slug: s.key,
  name: s.label,
  subs: SUBS[s.key],
  pool: s.pool,
}));

const TIERS: Tier[] = ["Platinum", "Gold", "Verified", "Silver", "Gold"];
const VARIANTS = ["", " Pro", " Plus", " Elite", " Signature"];

function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const slugify = (s: string) =>
  s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

function buildSeed(): DB {
  const rng = mulberry32(7);
  const categories: Category[] = CATS.map((c, i) => ({
    id: `c${i + 1}`,
    name: c.name,
    slug: c.slug,
    image: pick(POOLS[c.pool], i),
    hidden: false,
    order: i,
  }));
  const catBySlug = (s: string) => categories.find((c) => c.slug === s)!;
  const subcategories: Subcategory[] = [];
  CATS.forEach((c, i) => {
    c.subs.forEach((s, j) =>
      subcategories.push({ id: `c${i + 1}s${j + 1}`, catId: `c${i + 1}`, name: s, hidden: false, order: j })
    );
  });
  subcategories.push({ id: "c9s3", catId: "c9", name: "General", hidden: false, order: 2 });

  const vendors: Vendor[] = [];
  const products: Product[] = [];
  const seenVendorSlugs = new Set<string>();
  SECTORS.forEach((sec, si) => {
    VENDOR_NAMES[sec.key].forEach((name, vi) => {
      const canonicalSlug = slugify(name);
      if (seenVendorSlugs.has(canonicalSlug)) return;
      seenVendorSlugs.add(canonicalSlug);
      const vid = `v${si}x${vi}`;
      const fallback = POOLS[sec.pool];
      if (!fallback || !fallback.length) return;
      const website = WEBSITE_MAP[name] ?? "";
      const officialHost = vendorHost(website);
      const contact = CONTACT_MAP[name] ?? {};
      const seedCat = categories.find((c) => c.slug === sec.catSlug);
      const seedSubs = subcategories
        .filter((s) => s.catId === seedCat?.id)
        .sort((a, b) => a.order - b.order);
      const segmentIdx =
        sec.key === "fashion" ? FASHION_SEG[name] : sec.key === "footwear" ? FOOT_SEG[name] ?? 0 : undefined;
      const seedSubId = segmentIdx !== undefined ? seedSubs[segmentIdx]?.id : undefined;
      const group = sec.key === "footwear" ? FOOT_GROUP[name] : undefined;
      vendors.push({
        id: vid,
        name,
        sector: sec.key,
        tier: TIERS[vi % TIERS.length],
        /* Contact/location fields stay empty until an authoritative source supplies them. */
        hotline: contact.hotline ?? "",
        website,
        mapQuery: contact.mapQuery ?? "",
        /* Never attach generic stock video to a brand. Official reels can be
           added in the dashboard after their direct media URL is audited. */
        videoUrl: "",
        logoHue: Math.floor((si * 37 + vi * 59 + 160) % 360),
        showImg: pick(fallback, vi * 3 + 1),
        about:
          group === "brand"
            ? `${name} — ${BRAND_ORIGIN[name] ?? "global"} original brand. iRoopa lists Cairo retailers stocking its products; presence here is not a claim of an official Egyptian distributor unless explicitly verified.`
            : group === "shop"
              ? `${name} — physical footwear store in Cairo/Giza. Address and status come from the discovery directory; verify the branch before visiting.`
              : name === "El-Outlet" || name === "JLOOD" || group === "retail"
                ? `${name} is a multi-brand footwear/fashion retailer. Product authenticity statements are retailer-provided until independently verified.`
                : FASHION_SEG[name] === 11
                  ? `${name} is a Cairo-area garment manufacturer on iRoopa — private label, cut-make-trim and fabric sourcing. MOQ from 300 pcs; voice-request a costing sheet and sampling slot.`
                  : `${name} is a verified ${sec.label.toLowerCase()} partner on iRoopa. Book, buy or request a callback by voice — average confirmation under 60 seconds.`,
        socials: SOCIALS_MAP[name] ?? {},
        catalogUrl: officialHost ? website : undefined,
        whatsapp: contact.whatsapp,
        mapUrl: contact.mapUrl,
        subId: seedSubId,
        subSource: seedSubId ? "seed" : undefined,
        videoDiscoveryUrl: undefined,
        entityKind:
          group === "brand"
            ? "official"
            : group === "shop"
              ? "store"
              : group === "retail"
                ? "marketplace"
                : name === "El-Outlet" || name === "JLOOD"
                  ? "marketplace"
                  : sec.key === "fashion"
                    ? FASHION_SEG[name] === 11
                      ? "manufacturer"
                      : officialHost
                        ? "official"
                        : "research"
                    : officialHost
                      ? "official"
                      : "marketplace",
        madeInEgypt:
          sec.key === "fashion"
            ? FASHION_SEG[name] === 11
              ? "claimed"
              : officialHost
                ? "claimed"
                : "unverified"
            : sec.key === "tourism" || sec.key === "homes" || sec.key === "salon" || sec.key === "restaurants"
              ? "verified"
              : "unverified",
        linkStatus: officialHost ? "fresh" : "unverified",
        priceStatus: AUDITED_PRODUCTS[name]?.length ? "fresh" : "unverified",
        linksAuditedAt: officialHost || SOCIALS_MAP[name] ? "2026-06" : undefined,
        hidden: false,
        order: vi,
      });
      const cat = catBySlug(sec.catSlug);
      const subs = subcategories.filter((s) => s.catId === cat.id);
      const audited = AUDITED_PRODUCTS[name];
      const rows =
        name === "El-Outlet" || name === "JLOOD"
          ? []
          : audited ?? PRODUCT_NAMES[sec.key].map((p, pi) => {
        const price = Math.round((p.min + rng() * (p.max - p.min)) / 5) * 5;
        const suffix = VARIANTS[vi % VARIANTS.length];
        return {
          name: p.n + (pi > 2 ? "" : suffix),
          price,
          sale: rng() < 0.3 ? Math.round((price * 0.8) / 5) * 5 : null,
          description: `Directory listing for ${name}. Confirm live product details on the official source.`,
          sourceLabel: undefined as string | undefined,
          checkedAt: undefined as string | undefined,
        };
      });
      rows.forEach((p, pi) => {
        /* Product sub-pick honors the brand's own fashion segment when known. */
        const subPick = seedSubId
          ? subs.find((s) => s.id === seedSubId) ?? subs[(pi + vi) % subs.length]
          : subs[(pi + vi) % subs.length];
        const pid = `p${si}x${vi}x${pi}`;
        products.push({
          id: pid,
          vendorId: vid,
          sectorKey: sec.key,
          catId: cat.id,
          subId: subPick?.id ?? subs[0]?.id ?? "c9s3",
          name: p.name,
          desc: p.description,
          price: p.price,
          sale: p.sale ?? null,
          img: pick(fallback, vi * 5 + pi * 2),
          hidden: false,
          provenance: p.sourceLabel
            ? {
                sourceUrl: website,
                sourceLabel: p.sourceLabel,
                checkedAt: p.checkedAt,
              }
            : undefined,
          imageSource: undefined,
          checkedAt: p.checkedAt,
        });
      });
    });
  });

  return {
    v: 21,
    requests: [],
    currency: "EGP",
    categories,
    subcategories,
    vendors,
    products,
    sectorsHidden: {},
    activeTheme: "royal",
    overrides: {},
  };
}

/* ------------------------------- formatting ------------------------------ */

/** Formats a price in the configured store currency (defaults to EGP). */
export const fmtEGP = (n: number, currency = "EGP") =>
  `${Math.round(n).toLocaleString("en-US")} ${currency}`;

export const sectorLabel = (k: SectorKey) =>
  SECTORS.find((s) => s.key === k)?.label ?? k;

/* --------------------------------- store --------------------------------- */

const KEY = "iroopa-db-v21";
const CART_KEY = "iroopa-cart-v1";

function loadDB(): DB {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as DB;
      if (parsed && parsed.v === 21 && Array.isArray(parsed.vendors)) return parsed;
    }
  } catch {
    /* corrupted → reseed */
  }
  return buildSeed();
}

interface StoreValue {
  db: DB;
  vendorsOf: (vendorId: string) => Product[];
  featuredFor: (t: ThemeId) => Product[];
  activeThemeDef: ReturnType<typeof themeById>;
  toast: (msg: string, kind?: Toast["kind"]) => void;
  toasts: Toast[];
  dismissToast: (id: number) => void;
  upsertVendor: (v: Vendor) => void;
  removeVendor: (id: string) => void;
  reorderVendor: (id: string, dir: -1 | 1) => void;
  toggleVendorHidden: (id: string) => void;
  setSectorHidden: (k: SectorKey, hidden: boolean) => void;
  upsertProduct: (p: Product) => void;
  removeProduct: (id: string) => void;
  toggleProductHidden: (id: string) => void;
  upsertCategory: (c: Category) => void;
  removeCategory: (id: string) => void;
  toggleCategoryHidden: (id: string) => void;
  upsertSubcategory: (s: Subcategory) => void;
  removeSubcategory: (id: string) => void;
  toggleSubHidden: (id: string) => void;
  reorderSubcategory: (id: string, dir: -1 | 1) => void;
  assignVendorSub: (vendorId: string, subId: string, source?: Vendor["subSource"]) => void;
  bulkUpsertVendors: (vendors: Vendor[]) => number;
  setCurrency: (c: string) => void;
  submitRequest: (input: Omit<VendorRequest, "id" | "status" | "submittedAt" | "slaHours">) => VendorRequest;
  setRequestStatus: (id: string, status: RequestStatus, note?: string) => void;
  setActiveTheme: (t: ThemeId) => void;
  saveOverride: (t: ThemeId, o: ThemeOverride) => void;
  resetOverride: (t: ThemeId) => void;
  resetAll: () => void;
  importList: (kind: "vendors" | "products" | "categories" | "subcategories", items: unknown[]) => number;
  cart: CartItem[];
  cartCount: number;
  cartTotal: number;
  addToCart: (productId: string, qty?: number) => void;
  setQty: (productId: string, qty: number) => void;
  clearCart: () => void;
}

const Ctx = createContext<StoreValue | null>(null);
let toastSeq = 1;

export function StoreProvider({ children }: { children: ReactNode }) {
  const [db, setDb] = useState<DB>(loadDB);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const parsed = JSON.parse(localStorage.getItem(CART_KEY) ?? "[]");
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(db));
    } catch {
      /* quota — keep in memory */
    }
  }, [db]);

  useEffect(() => {
    try {
      localStorage.setItem(CART_KEY, JSON.stringify(cart));
    } catch {
      /* private mode */
    }
  }, [cart]);

  const toast = useCallback((msg: string, kind: Toast["kind"] = "ok") => {
    const id = toastSeq++;
    setToasts((ts) => [...ts.slice(-3), { id, kind, msg }]);
    window.setTimeout(() => setToasts((ts) => ts.filter((t) => t.id !== id)), 3400);
  }, []);
  const dismissToast = useCallback((id: number) => setToasts((ts) => ts.filter((t) => t.id !== id)), []);

  const patch = useCallback((fn: (d: DB) => Partial<DB>) => setDb((d) => ({ ...d, ...fn(d) })), []);

  const upsertVendor = useCallback(
    (v: Vendor) => {
      patch((d) => ({
        vendors: d.vendors.some((x) => x.id === v.id)
          ? d.vendors.map((x) => (x.id === v.id ? v : x))
          : [...d.vendors, v],
      }));
      toast("Vendor saved");
    },
    [patch, toast]
  );
  const removeVendor = useCallback(
    (id: string) => {
      patch((d) => ({
        vendors: d.vendors.filter((v) => v.id !== id),
        products: d.products.filter((p) => p.vendorId !== id),
      }));
      toast("Vendor removed", "warn");
    },
    [patch, toast]
  );
  const reorderVendor = useCallback(
    (id: string, dir: -1 | 1) =>
      patch((d) => {
        const list = [...d.vendors];
        const i = list.findIndex((v) => v.id === id);
        const j = i + dir;
        if (i < 0 || j < 0 || j >= list.length) return {};
        [list[i].order, list[j].order] = [list[j].order, list[i].order];
        return { vendors: list };
      }),
    [patch]
  );
  const toggleVendorHidden = useCallback(
    (id: string) =>
      patch((d) => ({ vendors: d.vendors.map((v) => (v.id === id ? { ...v, hidden: !v.hidden } : v)) })),
    [patch]
  );
  const setSectorHidden = useCallback(
    (k: SectorKey, hidden: boolean) => patch((d) => ({ sectorsHidden: { ...d.sectorsHidden, [k]: hidden } })),
    [patch]
  );

  const upsertProduct = useCallback(
    (p: Product) => {
      patch((d) => ({
        products: d.products.some((x) => x.id === p.id)
          ? d.products.map((x) => (x.id === p.id ? p : x))
          : [p, ...d.products],
      }));
      toast("Product saved");
    },
    [patch, toast]
  );
  const removeProduct = useCallback(
    (id: string) => {
      patch((d) => ({ products: d.products.filter((p) => p.id !== id) }));
      toast("Product removed", "warn");
    },
    [patch, toast]
  );
  const toggleProductHidden = useCallback(
    (id: string) =>
      patch((d) => ({ products: d.products.map((p) => (p.id === id ? { ...p, hidden: !p.hidden } : p)) })),
    [patch]
  );

  const upsertCategory = useCallback(
    (c: Category) =>
      patch((d) => ({
        categories: d.categories.some((x) => x.id === c.id)
          ? d.categories.map((x) => (x.id === c.id ? c : x))
          : [...d.categories, c],
      })),
    [patch]
  );
  const removeCategory = useCallback(
    (id: string) =>
      patch((d) => ({
        categories: d.categories.filter((c) => c.id !== id),
        subcategories: d.subcategories.filter((s) => s.catId !== id),
      })),
    [patch]
  );
  const toggleCategoryHidden = useCallback(
    (id: string) =>
      patch((d) => ({ categories: d.categories.map((c) => (c.id === id ? { ...c, hidden: !c.hidden } : c)) })),
    [patch]
  );
  const upsertSubcategory = useCallback(
    (s: Subcategory) =>
      patch((d) => ({
        subcategories: d.subcategories.some((x) => x.id === s.id)
          ? d.subcategories.map((x) => (x.id === s.id ? s : x))
          : [...d.subcategories, s],
      })),
    [patch]
  );
  const removeSubcategory = useCallback(
    (id: string) => patch((d) => ({ subcategories: d.subcategories.filter((s) => s.id !== id) })),
    [patch]
  );
  const toggleSubHidden = useCallback(
    (id: string) =>
      patch((d) => ({
        subcategories: d.subcategories.map((s) => (s.id === id ? { ...s, hidden: !s.hidden } : s)),
      })),
    [patch]
  );

  const reorderSubcategory = useCallback(
    (id: string, dir: -1 | 1) =>
      patch((d) => {
        const target = d.subcategories.find((s) => s.id === id);
        if (!target) return {};
        const siblings = d.subcategories
          .filter((s) => s.catId === target.catId)
          .sort((a, b) => a.order - b.order);
        const i = siblings.findIndex((s) => s.id === id);
        const j = i + dir;
        if (i < 0 || j < 0 || j >= siblings.length) return {};
        const a = siblings[i];
        const b = siblings[j];
        return {
          subcategories: d.subcategories.map((s) =>
            s.id === a.id ? { ...s, order: b.order } : s.id === b.id ? { ...s, order: a.order } : s
          ),
        };
      }),
    [patch]
  );

  const assignVendorSub = useCallback(
    (vendorId: string, subId: string, source: Vendor["subSource"] = "manual") =>
      patch((d) => ({
        vendors: d.vendors.map((v) =>
          v.id === vendorId
            ? { ...v, subId: subId || undefined, subSource: subId ? source : undefined }
            : v
        ),
      })),
    [patch]
  );

  /** Import-friendly upsert: merges many vendors in one commit, no toast spam. */
  const bulkUpsertVendors = useCallback(
    (incoming: Vendor[]) => {
      let count = 0;
      patch((d) => {
        const list = [...d.vendors];
        incoming.forEach((v) => {
          const i = list.findIndex((x) => {
            // Deduplicate by ID or exact Name Match
            if (x.id === v.id || slugify(x.name) === slugify(v.name)) return true;
            // Deduplicate by Website Domain
            if (v.website && x.website) {
              const vHost = vendorHost(v.website);
              const xHost = vendorHost(x.website);
              if (vHost && xHost && vHost === xHost) return true;
            }
            // Deduplicate by Instagram Handle
            if (v.socials?.instagram && x.socials?.instagram) {
              const vIg = v.socials.instagram.replace(/\/$/, "").split("/").pop()?.toLowerCase();
              const xIg = x.socials.instagram.replace(/\/$/, "").split("/").pop()?.toLowerCase();
              if (vIg && xIg && vIg === xIg) return true;
            }
            return false;
          });
          if (i >= 0) list[i] = { ...list[i], ...v, id: list[i].id };
          else list.push(v);
          count += 1;
        });
        return { vendors: list };
      });
      return count;
    },
    [patch]
  );

  const setCurrency = useCallback(
    (c: string) => {
      patch(() => ({ currency: c }));
      toast(`Store currency set to ${c}`);
    },
    [patch, toast]
  );

  /** Public intake: creates a pending request on the 48-hour review SLA. */
  const submitRequest = useCallback(
    (input: Omit<VendorRequest, "id" | "status" | "submittedAt" | "slaHours">) => {
      const request: VendorRequest = {
        ...input,
        id: `req-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        status: "pending",
        submittedAt: new Date().toISOString(),
        slaHours: 48,
      };
      patch((d) => ({ requests: [request, ...d.requests] }));
      return request;
    },
    [patch]
  );

  /** Approve converts the request into a live vendor; reject just records it. */
  const setRequestStatus = useCallback(
    (id: string, status: RequestStatus, note?: string) => {
      patch((d) => {
        const request = d.requests.find((r) => r.id === id);
        if (!request) return {};
        const requests = d.requests.map((r) =>
          r.id === id
            ? { ...r, status, reviewedAt: new Date().toISOString(), reviewNote: note }
            : r
        );
        if (status !== "approved" || d.vendors.some((v) => slugify(v.name) === slugify(request.name))) {
          return { requests };
        }
        const host = vendorHost(request.website);
        const vendorId = `v-req-${Date.now()}`;
        const vendor: Vendor = {
          id: vendorId,
          name: request.name,
          sector: request.sector,
          tier: "Verified",
          hotline: request.hotline ?? "",
          website: request.website,
          mapQuery: request.city ? `${request.name}, ${request.city}, Egypt` : "",
          videoUrl: "",
          logoHue: Math.floor(Math.random() * 360),
          showImg: "",
          about:
            request.about?.trim() ||
            `${request.name} joined iRoopa via free submission and passed admin review.`,
          socials: {
            instagram: request.instagram,
            facebook: request.facebook,
            linkedin: request.linkedin,
            tiktok: request.tiktok,
            youtube: request.youtube,
          },
          whatsapp: request.whatsapp,
          catalogUrl: host ? request.website : undefined,
          entityKind: host ? "official" : "research",
          madeInEgypt: "unverified",
          linkStatus: host ? "stale" : "unverified",
          priceStatus: "unverified",
          hidden: false,
          order: d.vendors.length,
        };
        const cat = d.categories.find((c) => c.slug === request.sector);
        const sub = d.subcategories.find((s) => s.catId === cat?.id && !s.hidden);
        const products = request.productDrafts?.length
          ? [
              ...d.products,
              ...request.productDrafts
                .filter((p) => p.name.trim())
                .map((p, idx) => ({
                  id: `p-req-${Date.now()}-${idx}`,
                  vendorId,
                  sectorKey: request.sector,
                  catId: cat?.id ?? d.categories[0]?.id ?? "",
                  subId: sub?.id ?? "",
                  name: p.name.trim(),
                  desc: `${p.category ?? "Product"} submitted by ${request.name}.`,
                  price: Number(p.price) || 0,
                  sale: p.originalPrice && p.price && p.originalPrice > p.price ? Number(p.price) : null,
                  img: "",
                  hidden: false,
                  provenance: {
                    sourceUrl: p.productUrl || request.website,
                    sourceLabel: "Client submission",
                    checkedAt: new Date().toISOString().slice(0, 10),
                  },
                  checkedAt: new Date().toISOString().slice(0, 10),
                })),
            ]
          : d.products;
        return { requests, vendors: [...d.vendors, vendor], products };
      });
      toast(
        status === "approved" ? "Request approved — vendor is live" : "Request rejected",
        status === "approved" ? "ok" : "warn"
      );
    },
    [patch, toast]
  );

  const setActiveTheme = useCallback(
    (t: ThemeId) => {
      patch(() => ({ activeTheme: t }));
      toast(`Theme applied — ${themeById(t).name}`);
    },
    [patch, toast]
  );
  const saveOverride = useCallback(
    (t: ThemeId, o: ThemeOverride) => {
      patch((d) => ({ overrides: { ...d.overrides, [t]: o } }));
      toast("Theme override saved");
    },
    [patch, toast]
  );
  const resetOverride = useCallback(
    (t: ThemeId) =>
      patch((d) => {
        const o = { ...d.overrides };
        delete o[t];
        return { overrides: o };
      }),
    [patch]
  );
  const resetAll = useCallback(() => {
    const fresh = buildSeed();
    setDb(fresh);
    toast("Everything reset to seed data", "info");
  }, [toast]);

  const importList = useCallback(
    (kind: "vendors" | "products" | "categories" | "subcategories", items: unknown[]) => {
      let count = 0;
      patch((d) => {
        const list = (d[kind] as { id: string }[]).slice();
        items.forEach((raw) => {
          const it = raw as { id?: string };
          if (!it || typeof it.id !== "string") return;
          const i = list.findIndex((x) => x.id === it.id);
          if (i >= 0) list[i] = it as never;
          else list.push(it as never);
          count++;
        });
        return { [kind]: list } as Partial<DB>;
      });
      return count;
    },
    [patch]
  );

  /* ------------------------------ cart ------------------------------ */
  const addToCart = useCallback(
    (productId: string, qty = 1) => {
      setCart((c) => {
        const i = c.findIndex((x) => x.productId === productId);
        if (i >= 0) {
          const n = [...c];
          n[i] = { ...n[i], qty: n[i].qty + qty };
          return n;
        }
        return [...c, { productId, qty }];
      });
      toast(
        document.documentElement.lang === "ar" ? "تمت الإضافة إلى السلة" : "Added to cart"
      );
    },
    [toast]
  );
  const setQty = useCallback(
    (productId: string, qty: number) =>
      setCart((c) =>
        qty <= 0
          ? c.filter((x) => x.productId !== productId)
          : c.map((x) => (x.productId === productId ? { ...x, qty } : x))
      ),
    []
  );
  const clearCart = useCallback(() => setCart([]), []);

  const { cartCount, cartTotal } = useMemo(() => {
    let count = 0;
    let total = 0;
    cart.forEach((ci) => {
      const p = db.products.find((x) => x.id === ci.productId);
      if (!p) return;
      count += ci.qty;
      total += ci.qty * (p.sale ?? p.price);
    });
    return { cartCount: count, cartTotal: total };
  }, [cart, db.products]);

  const vendorsOf = useCallback(
    (vendorId: string) => db.products.filter((p) => p.vendorId === vendorId),
    [db.products]
  );

  const featuredFor = useCallback(
    (t: ThemeId) => {
      const o = db.overrides[t];
      if (o?.featuredIds?.length) {
        const found = o.featuredIds
          .map((id) => db.products.find((p) => p.id === id))
          .filter(Boolean) as Product[];
        if (found.length) return found;
      }
      const def = themeById(t);
      return db.products.filter((p) => p.sectorKey === def.featuredSector && !p.hidden).slice(0, 3);
    },
    [db.products, db.overrides]
  );

  const value: StoreValue = {
    db,
    vendorsOf,
    featuredFor,
    activeThemeDef: themeById(db.activeTheme),
    toast,
    toasts,
    dismissToast,
    upsertVendor,
    removeVendor,
    reorderVendor,
    toggleVendorHidden,
    setSectorHidden,
    upsertProduct,
    removeProduct,
    toggleProductHidden,
    upsertCategory,
    removeCategory,
    toggleCategoryHidden,
    upsertSubcategory,
    removeSubcategory,
    toggleSubHidden,
    reorderSubcategory,
    assignVendorSub,
    bulkUpsertVendors,
    setCurrency,
    submitRequest,
    setRequestStatus,
    setActiveTheme,
    saveOverride,
    resetOverride,
    resetAll,
    importList,
    cart,
    cartCount,
    cartTotal,
    addToCart,
    setQty,
    clearCart,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore must be inside StoreProvider");
  return ctx;
}
