/**
 * AI Gateway client.
 *
 * This app ships as a static single-page bundle with no server, so there is no
 * safe place to hide a secret. The gateway key is therefore supplied by the
 * admin at runtime and stored only in this browser's localStorage. Use a
 * restricted/low-budget key, and prefer a server proxy for public deployments.
 */

export interface GatewayConfig {
  baseUrl: string;
  apiKey: string;
  model: string;
  enabled: boolean;
}

const KEY = "iroopa-ai-gateway-v1";

export const DEFAULT_GATEWAY: GatewayConfig = {
  baseUrl: "https://ai-gateway.vercel.sh/v1",
  apiKey: "",
  model: "openai/gpt-4o-mini",
  enabled: false,
};

export function readGateway(): GatewayConfig {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? "null") as Partial<GatewayConfig> | null;
    return raw ? { ...DEFAULT_GATEWAY, ...raw } : DEFAULT_GATEWAY;
  } catch {
    return DEFAULT_GATEWAY;
  }
}

export function writeGateway(cfg: GatewayConfig) {
  try {
    localStorage.setItem(KEY, JSON.stringify(cfg));
  } catch {
    /* private mode — keep in memory for this session only */
  }
}

export function gatewayReady(cfg: GatewayConfig) {
  return cfg.enabled && !!cfg.apiKey.trim() && !!cfg.baseUrl.trim() && !!cfg.model.trim();
}

/* ------------------------------ classification ---------------------------- */

export interface ClassifyInput {
  name: string;
  website?: string;
  notes?: string;
}

export interface ClassifyResult {
  name: string;
  segment: string;
  confidence: number;
  source: "ai" | "rules";
  reason?: string;
}

/** Keyword rules — also used to validate/repair model output. */
const RULES: { segment: string; keys: string[] }[] = [
  { segment: "Manufacturers", keys: ["factory", "garment", "manufactur", "stitch", "textile", "private label", "oem", "fab", "mills", "clothing co"] },
  { segment: "Jewelry", keys: ["jewel", "jewellery", "gold", "silver", "accessor", "fahmy", "benhalim"] },
  { segment: "Bags & Leather", keys: ["bag", "leather", "tote", "backpack", "okhtein", "wallet", "purse"] },
  { segment: "Footwear", keys: ["shoe", "sole", "sneaker", "footwear", "boot", "sandal"] },
  { segment: "Bridal & Couture", keys: ["bridal", "couture", "wedding", "gown", "evening", "atelier"] },
  { segment: "Activewear", keys: ["fit", "sport", "active", "gym", "training", "athleis", "performance"] },
  { segment: "Modest", keys: ["modest", "abaya", "hijab", "veil", "khimar", "islamic"] },
  { segment: "Denim", keys: ["denim", "jean"] },
  { segment: "Kids & Swim", keys: ["kid", "baby", "child", "junior", "swim", "beach"] },
  { segment: "Basics & Loungewear", keys: ["basic", "cotton", "lounge", "sleep", "pajama", "essential", "underwear", "homewear"] },
  { segment: "Streetwear", keys: ["street", "oversized", "hoodie", "tee", "t-shirt", "urban", "drop", "graphic", "unisex"] },
  { segment: "Women's RTW", keys: ["women", "dress", "abito", "maison", "rtw", "ready to wear", "blouse", "skirt", "lady"] },
];

export function heuristicSegment(input: ClassifyInput, allowed: string[]): ClassifyResult {
  const hay = `${input.name} ${input.website ?? ""} ${input.notes ?? ""}`.toLowerCase();
  for (const rule of RULES) {
    if (!allowed.includes(rule.segment)) continue;
    const hit = rule.keys.find((k) => hay.includes(k));
    if (hit) {
      return {
        name: input.name,
        segment: rule.segment,
        confidence: 0.55,
        source: "rules",
        reason: `matched “${hit}”`,
      };
    }
  }
  return {
    name: input.name,
    segment: allowed.includes("Women's RTW") ? "Women's RTW" : allowed[0] ?? "",
    confidence: 0.2,
    source: "rules",
    reason: "no keyword match — needs review",
  };
}

function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1] ?? text;
  const start = fenced.indexOf("[");
  const objStart = fenced.indexOf("{");
  const from = start >= 0 && (objStart < 0 || start < objStart) ? start : objStart;
  if (from < 0) return null;
  const end = Math.max(fenced.lastIndexOf("]"), fenced.lastIndexOf("}"));
  try {
    return JSON.parse(fenced.slice(from, end + 1));
  } catch {
    return null;
  }
}

/**
 * Classifies brands into the supplied subcategory names.
 * Falls back to deterministic rules for anything the model misses.
 */
export async function classifyBrands(
  items: ClassifyInput[],
  allowed: string[],
  cfg: GatewayConfig,
  signal?: AbortSignal
): Promise<{ results: ClassifyResult[]; usedAi: boolean; error?: string }> {
  const fallback = () => items.map((i) => heuristicSegment(i, allowed));
  if (!items.length) return { results: [], usedAi: false };
  if (!gatewayReady(cfg)) return { results: fallback(), usedAi: false };

  const prompt = [
    "You categorize Egyptian fashion brands for a vendor directory.",
    `Allowed categories (use the exact spelling): ${allowed.join(" | ")}`,
    "",
    "Return ONLY a JSON array. Each element:",
    `{"name": "<input name>", "segment": "<one allowed category>", "confidence": <0..1>, "reason": "<max 8 words>"}`,
    "If unsure, pick the closest category and give a low confidence.",
    "",
    "Brands:",
    ...items.map((i, n) => `${n + 1}. ${i.name}${i.website ? ` — ${i.website}` : ""}${i.notes ? ` — ${i.notes}` : ""}`),
  ].join("\n");

  try {
    const res = await fetch(`${cfg.baseUrl.replace(/\/$/, "")}/chat/completions`, {
      method: "POST",
      signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${cfg.apiKey.trim()}`,
      },
      body: JSON.stringify({
        model: cfg.model,
        temperature: 0,
        messages: [
          { role: "system", content: "You are a precise taxonomy classifier. Reply with JSON only." },
          { role: "user", content: prompt },
        ],
      }),
    });

    if (!res.ok) {
      const detail = await res.text().catch(() => "");
      return {
        results: fallback(),
        usedAi: false,
        error: `Gateway ${res.status}${detail ? `: ${detail.slice(0, 140)}` : ""}`,
      };
    }

    const data = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const content = data.choices?.[0]?.message?.content ?? "";
    const parsed = extractJson(content);
    const rows = Array.isArray(parsed) ? parsed : [];
    if (!rows.length) return { results: fallback(), usedAi: false, error: "Model returned no usable JSON" };

    const byName = new Map<string, ClassifyResult>();
    rows.forEach((raw) => {
      const r = raw as { name?: string; segment?: string; confidence?: number; reason?: string };
      if (!r?.name || !r?.segment) return;
      const segment = allowed.find((a) => a.toLowerCase() === String(r.segment).toLowerCase());
      if (!segment) return;
      byName.set(String(r.name).trim().toLowerCase(), {
        name: String(r.name).trim(),
        segment,
        confidence: Math.max(0, Math.min(1, Number(r.confidence) || 0.6)),
        source: "ai",
        reason: r.reason ? String(r.reason).slice(0, 60) : undefined,
      });
    });

    const results = items.map((item) => {
      const hit = byName.get(item.name.trim().toLowerCase());
      return hit ? { ...hit, name: item.name } : heuristicSegment(item, allowed);
    });
    return { results, usedAi: results.some((r) => r.source === "ai") };
  } catch (err) {
    return {
      results: fallback(),
      usedAi: false,
      error: err instanceof Error ? err.message : "Gateway request failed",
    };
  }
}

/* -------------------------------- parsing --------------------------------- */

export interface ParsedVendorRow {
  name: string;
  website?: string;
  logo?: string;
  instagram?: string;
  facebook?: string;
  tiktok?: string;
  youtube?: string;
  linkedin?: string;
  whatsapp?: string;
  mapUrl?: string;
  notes?: string;
}

const HEADER_ALIASES: Record<string, keyof ParsedVendorRow> = {
  name: "name", brand: "name", vendor: "name", company: "name", "brand name": "name",
  website: "website", url: "website", site: "website", domain: "website", shop: "website",
  logo: "logo", "logo url": "logo", image: "logo",
  instagram: "instagram", ig: "instagram",
  facebook: "facebook", fb: "facebook",
  tiktok: "tiktok",
  youtube: "youtube", yt: "youtube",
  linkedin: "linkedin", in: "linkedin",
  whatsapp: "whatsapp", phone: "whatsapp", mobile: "whatsapp",
  map: "mapUrl", maps: "mapUrl", "google maps": "mapUrl", location: "mapUrl",
  notes: "notes", category: "notes", description: "notes", segment: "notes",
};

function splitCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = "";
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (quoted && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else quoted = !quoted;
    } else if ((ch === "," || ch === "\t" || ch === ";") && !quoted) {
      out.push(cur.trim());
      cur = "";
    } else cur += ch;
  }
  out.push(cur.trim());
  return out;
}

const normUrl = (v?: string) => {
  const s = (v ?? "").trim();
  if (!s || s === "-") return undefined;
  if (/^https?:\/\//i.test(s)) return s;
  if (/^[\w-]+\.[\w.-]+/.test(s)) return `https://${s}`;
  return undefined;
};

/** Accepts JSON arrays, CSV/TSV with headers, or one brand per line. */
export function parseVendorInput(text: string): ParsedVendorRow[] {
  const raw = text.trim();
  if (!raw) return [];

  if (raw.startsWith("[") || raw.startsWith("{")) {
    try {
      const data = JSON.parse(raw);
      const arr = Array.isArray(data) ? data : [data];
      return arr
        .map((r) => {
          const row = r as Record<string, unknown>;
          const get = (k: keyof ParsedVendorRow) => {
            const direct = row[k];
            if (typeof direct === "string") return direct;
            const alias = Object.entries(HEADER_ALIASES).find(
              ([h, target]) => target === k && typeof row[h] === "string"
            );
            return alias ? String(row[alias[0]]) : undefined;
          };
          const name = (get("name") ?? "").trim();
          if (!name) return null;
          return {
            name,
            website: normUrl(get("website")),
            logo: normUrl(get("logo")),
            instagram: normUrl(get("instagram")),
            facebook: normUrl(get("facebook")),
            tiktok: normUrl(get("tiktok")),
            youtube: normUrl(get("youtube")),
            linkedin: normUrl(get("linkedin")),
            whatsapp: get("whatsapp")?.replace(/\D/g, "") || undefined,
            mapUrl: normUrl(get("mapUrl")),
            notes: get("notes"),
          } as ParsedVendorRow;
        })
        .filter(Boolean) as ParsedVendorRow[];
    } catch {
      /* fall through to delimited parsing */
    }
  }

  const lines = raw.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (!lines.length) return [];

  const headerCells = splitCsvLine(lines[0]).map((h) => h.toLowerCase().replace(/^"|"$/g, ""));
  const hasHeader = headerCells.some((h) => HEADER_ALIASES[h]);

  if (!hasHeader) {
    return lines
      .map((line) => {
        const cells = splitCsvLine(line);
        const name = cells[0]?.replace(/^"|"$/g, "").trim();
        if (!name) return null;
        return { name, website: normUrl(cells[1]), notes: cells[2] } as ParsedVendorRow;
      })
      .filter(Boolean) as ParsedVendorRow[];
  }

  const map = headerCells.map((h) => HEADER_ALIASES[h]);
  return lines
    .slice(1)
    .map((line) => {
      const cells = splitCsvLine(line);
      const row: ParsedVendorRow = { name: "" };
      map.forEach((field, i) => {
        if (!field) return;
        const value = cells[i]?.replace(/^"|"$/g, "").trim();
        if (!value) return;
        if (field === "name") row.name = value;
        else if (field === "whatsapp") row.whatsapp = value.replace(/\D/g, "") || undefined;
        else if (field === "notes") row.notes = value;
        else row[field] = normUrl(value);
      });
      return row.name ? row : null;
    })
    .filter(Boolean) as ParsedVendorRow[];
}
