import type { Lang } from "./i18n";

export interface GeneratedWriting {
  title: string;
  content: string;
}

function stripCommand(text: string) {
  return text
    .replace(/^(please\s+)?(write|draft|compose|create|make|take a note|note down)\s+/i, "")
    .replace(/^(من فضلك\s+)?(اكتب|اكتبي|صيغي|صيغ|أنشئ|انشئ|اعملي|اعمل|دوّن|دون)\s+/u, "")
    .trim();
}

function topicAfter(text: string, patterns: RegExp[]) {
  for (const pattern of patterns) {
    const hit = text.match(pattern)?.[1]?.trim();
    if (hit) return hit;
  }
  return stripCommand(text);
}

export function looksLikeWritingRequest(text: string) {
  return /\b(write|draft|compose|create (?:a )?(?:message|email|note|list|caption|plan)|take a note|note down)\b/i.test(text) ||
    /(اكتب|اكتبي|صيغي|صيغ|رسالة|بريد|ايميل|إيميل|قائمة|ملاحظة|دوّن|دون)/u.test(text);
}

export function generateWriting(text: string, lang: Lang, userName = ""): GeneratedWriting {
  const ar = lang === "ar";
  const clean = stripCommand(text);
  const isEmail = /\b(email|e-mail|mail)\b/i.test(text) || /(بريد|ايميل|إيميل)/u.test(text);
  const isMessage = /\b(message|whatsapp|text)\b/i.test(text) || /(رسالة|واتساب)/u.test(text);
  const isList = /\b(list|checklist|shopping list)\b/i.test(text) || /(قائمة|ليستة|مشتريات)/u.test(text);
  const isPlan = /\b(plan|schedule|agenda|routine)\b/i.test(text) || /(خطة|جدول|روتين)/u.test(text);
  const isCaption = /\b(caption|post|social post)\b/i.test(text) || /(كابشن|منشور|بوست)/u.test(text);
  const topic = topicAfter(clean, [
    /(?:about|regarding|for)\s+(.+)/i,
    /(?:عن|بخصوص|لـ)\s+(.+)/u,
  ]) || (ar ? "الموضوع المطلوب" : "the requested topic");

  if (isEmail) {
    return {
      title: ar ? `بريد بخصوص ${topic}` : `Email about ${topic}`,
      content: ar
        ? `الموضوع: ${topic}\n\nمرحبًا،\n\nأتواصل معكم بخصوص ${topic}. أرجو التكرم بمراجعة التفاصيل وإفادتي بالخطوة التالية والوقت المناسب للمتابعة.\n\nشكرًا لتعاونكم،\n${userName || "مع التحية"}`
        : `Subject: ${topic}\n\nHello,\n\nI'm writing regarding ${topic}. Please review the details and let me know the recommended next step and a suitable time to follow up.\n\nThank you,\n${userName || "Kind regards"}`,
    };
  }
  if (isList) {
    return {
      title: ar ? `قائمة: ${topic}` : `Checklist: ${topic}`,
      content: ar
        ? `قائمة ${topic}\n\n□ حدّد المطلوب بدقة\n□ راجع الكمية أو الميزانية\n□ قارن أفضل الخيارات\n□ تأكد من الموعد والموقع\n□ راجع الملخص قبل التأكيد`
        : `${topic} checklist\n\n□ Define the exact need\n□ Confirm quantity or budget\n□ Compare the strongest options\n□ Check timing and location\n□ Review the summary before confirming`,
    };
  }
  if (isPlan) {
    return {
      title: ar ? `خطة: ${topic}` : `Plan: ${topic}`,
      content: ar
        ? `خطة ${topic}\n\n1. الهدف: حدّد النتيجة المطلوبة.\n2. الأولوية: اختر أهم خطوة لليوم.\n3. التنفيذ: خصص وقتًا واضحًا للمهمة.\n4. المراجعة: راجع التقدم والميزانية.\n5. المتابعة: حدّد الخطوة التالية والموعد.`
        : `${topic} plan\n\n1. Outcome: define the result you need.\n2. Priority: choose today's most important step.\n3. Action: reserve a clear time block.\n4. Review: check progress and budget.\n5. Follow-up: set the next action and date.`,
    };
  }
  if (isCaption) {
    return {
      title: ar ? `منشور: ${topic}` : `Post: ${topic}`,
      content: ar
        ? `${topic} ✨\n\nتفاصيل تستحق الاهتمام، وتجربة مصممة لتكون أبسط وأوضح. أخبرونا برأيكم وما الذي تودون رؤيته بعد ذلك.\n\n#تجربة_أفضل #اختيارات_ذكية`
        : `${topic} ✨\n\nThoughtful details, a clearer experience, and a simpler way to get results. Tell us what you think and what you would like to see next.\n\n#BetterExperience #SmartChoices`,
    };
  }
  if (isMessage) {
    return {
      title: ar ? `رسالة: ${topic}` : `Message: ${topic}`,
      content: ar
        ? `مرحبًا، أتواصل معك بخصوص ${topic}. هل يمكن تأكيد التفاصيل والوقت المناسب؟ شكرًا لك.`
        : `Hi, I'm reaching out about ${topic}. Could you please confirm the details and the most suitable time? Thank you.`,
    };
  }
  return {
    title: ar ? `ملاحظة: ${topic}` : `Note: ${topic}`,
    content: ar
      ? `${topic}\n\n- المطلوب:\n- التفاصيل المهمة:\n- الموعد أو الأولوية:\n- الخطوة التالية:`
      : `${topic}\n\n- Objective:\n- Important details:\n- Timing or priority:\n- Next action:`,
  };
}