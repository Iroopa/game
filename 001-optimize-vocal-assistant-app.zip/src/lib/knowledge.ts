import type { Lang } from "./i18n";

export interface KnowledgeAnswer {
  title: string;
  answer: string;
  sourceUrl: string;
  sourceLabel: string;
  image?: string;
}

interface WikiPage {
  pageid?: number;
  title?: string;
  extract?: string;
  fullurl?: string;
  thumbnail?: { source?: string };
  index?: number;
}

interface WikiResponse {
  query?: { pages?: WikiPage[] | Record<string, WikiPage> };
}

function cleanQuestion(question: string) {
  return question
    .replace(/^(please\s+)?(tell me|explain|what is|what are|who is|who was|where is|when was|give me information about)\s+/i, "")
    .replace(/^(من هو|من هي|ما هو|ما هي|اشرح لي|احكي لي عن|أخبرني عن|معلومات عن)\s+/u, "")
    .replace(/[?؟]+$/g, "")
    .trim();
}

function concise(extract: string, lang: Lang) {
  const cleaned = extract.replace(/\s+/g, " ").trim();
  if (!cleaned) return "";
  const sentences = cleaned.match(/[^.!؟]+[.!؟]+/g) ?? [cleaned];
  const limit = lang === "ar" ? 620 : 680;
  let out = "";
  for (const sentence of sentences) {
    if (out.length + sentence.length > limit && out) break;
    out += `${sentence.trim()} `;
    if (out.length > 360) break;
  }
  return out.trim() || cleaned.slice(0, limit);
}

/**
 * Fetches a concise, sourced answer from the Arabic or English Wikipedia
 * Action API. Anonymous CORS requests explicitly include origin=*.
 */
export async function askWorldKnowledge(
  question: string,
  lang: Lang,
  signal?: AbortSignal
): Promise<KnowledgeAnswer | null> {
  const query = cleanQuestion(question);
  if (query.length < 2) return null;
  const domain = lang === "ar" ? "ar.wikipedia.org" : "en.wikipedia.org";
  const params = new URLSearchParams({
    action: "query",
    generator: "search",
    gsrsearch: query,
    gsrlimit: "3",
    prop: "extracts|info|pageimages",
    exintro: "1",
    explaintext: "1",
    exsentences: "5",
    inprop: "url",
    piprop: "thumbnail",
    pithumbsize: "480",
    redirects: "1",
    format: "json",
    formatversion: "2",
    origin: "*",
  });

  try {
    const response = await fetch(`https://${domain}/w/api.php?${params}`, {
      signal,
      headers: { Accept: "application/json" },
    });
    if (!response.ok) return null;
    const data = (await response.json()) as WikiResponse;
    const raw = data.query?.pages;
    const pages = Array.isArray(raw) ? raw : raw ? Object.values(raw) : [];
    const page = pages
      .filter((p) => p.extract && p.title)
      .sort((a, b) => (a.index ?? 99) - (b.index ?? 99))[0];
    if (!page?.extract || !page.title) return null;
    const answer = concise(page.extract, lang);
    if (!answer) return null;
    return {
      title: page.title,
      answer,
      sourceUrl:
        page.fullurl ??
        `https://${domain}/wiki/${encodeURIComponent(page.title.replace(/ /g, "_"))}`,
      sourceLabel: lang === "ar" ? "ويكيبيديا العربية" : "Wikipedia",
      image: page.thumbnail?.source,
    };
  } catch {
    return null;
  }
}

/** Avoid sending commands, private writing, or transactional text to search. */
export function looksLikeKnowledgeQuestion(text: string) {
  const q = text.trim();
  if (q.length < 4) return false;
  return /^(what|who|where|when|why|how|tell me|explain|define|which|ما|من|متى|أين|اين|لماذا|كيف|اشرح|عرف|عرّف|احكي)/i.test(q);
}