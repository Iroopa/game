import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { useStore } from "./store";

export interface ConciergeProfile {
  userName: string;
  assistantName: string;
  silenceMs: number;
  sensitivity: number;
  speakingRate: number;
  pitch: number;
  voiceNameEn: string;
  voiceNameAr: string;
}

export type ScheduleRepeat = "once" | "daily" | "weekdays";

export interface NeedSchedule {
  id: string;
  title: string;
  time: string;
  repeat: ScheduleRepeat;
  productId?: string;
  vendorId?: string;
  quantity?: number;
  active: boolean;
  createdAt: string;
  lastRun?: string;
}

export type SmartResultKind =
  | "comparison"
  | "order"
  | "calculation"
  | "schedule"
  | "summary"
  | "answer";

export interface SmartResultItem {
  id: string;
  label: string;
  value?: string;
  meta?: string;
  image?: string;
  productId?: string;
  vendorId?: string;
  recommended?: boolean;
}

export interface SmartResult {
  kind: SmartResultKind;
  title: string;
  subtitle?: string;
  items: SmartResultItem[];
  total?: number;
  totalLabel?: string;
  note?: string;
  recommendedProductId?: string;
  sourceUrl?: string;
  sourceLabel?: string;
  createdAt?: string;
}

export interface WritingDocument {
  title: string;
  content: string;
  prompt: string;
  createdAt: string;
}

interface ConciergeValue {
  profile: ConciergeProfile;
  updateProfile: (patch: Partial<ConciergeProfile>) => void;
  schedules: NeedSchedule[];
  addSchedule: (input: Omit<NeedSchedule, "id" | "createdAt" | "active">) => NeedSchedule;
  updateSchedule: (id: string, patch: Partial<NeedSchedule>) => void;
  removeSchedule: (id: string) => void;
  result: SmartResult | null;
  showResult: (result: SmartResult) => void;
  closeResult: () => void;
  settingsOpen: boolean;
  plannerOpen: boolean;
  writing: WritingDocument | null;
  openSettings: () => void;
  openPlanner: () => void;
  openWriter: (draft: Omit<WritingDocument, "createdAt">) => void;
  updateWriting: (patch: Partial<WritingDocument>) => void;
  closeWriter: () => void;
  closePanels: () => void;
  enableNotifications: () => Promise<boolean>;
}

const PROFILE_KEY = "iroopa-concierge-profile-v1";
const SCHEDULE_KEY = "iroopa-concierge-schedules-v1";

const DEFAULT_PROFILE: ConciergeProfile = {
  userName: "Friend",
  assistantName: "Roopa",
  silenceMs: 2200,
  sensitivity: 0.72,
  speakingRate: 0.96,
  pitch: 1.08,
  voiceNameEn: "",
  voiceNameAr: "",
};

function readProfile(): ConciergeProfile {
  try {
    const parsed = JSON.parse(localStorage.getItem(PROFILE_KEY) ?? "null") as Partial<ConciergeProfile> | null;
    return parsed ? { ...DEFAULT_PROFILE, ...parsed } : DEFAULT_PROFILE;
  } catch {
    return DEFAULT_PROFILE;
  }
}

function readSchedules(): NeedSchedule[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(SCHEDULE_KEY) ?? "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

const Ctx = createContext<ConciergeValue | null>(null);

export function ConciergeProvider({ children }: { children: ReactNode }) {
  const { db, toast } = useStore();
  const [profile, setProfile] = useState<ConciergeProfile>(readProfile);
  const [schedules, setSchedules] = useState<NeedSchedule[]>(readSchedules);
  const [result, setResult] = useState<SmartResult | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [plannerOpen, setPlannerOpen] = useState(false);
  const [writing, setWriting] = useState<WritingDocument | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
    } catch {
      /* private mode */
    }
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem(SCHEDULE_KEY, JSON.stringify(schedules));
    } catch {
      /* private mode */
    }
  }, [schedules]);

  const updateProfile = useCallback((patch: Partial<ConciergeProfile>) => {
    setProfile((p) => ({ ...p, ...patch }));
  }, []);

  const addSchedule = useCallback(
    (input: Omit<NeedSchedule, "id" | "createdAt" | "active">) => {
      const item: NeedSchedule = {
        ...input,
        id: `need-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        active: true,
        createdAt: new Date().toISOString(),
      };
      setSchedules((s) => [item, ...s]);
      return item;
    },
    []
  );

  const updateSchedule = useCallback((id: string, patch: Partial<NeedSchedule>) => {
    setSchedules((s) => s.map((item) => (item.id === id ? { ...item, ...patch } : item)));
  }, []);

  const removeSchedule = useCallback((id: string) => {
    setSchedules((s) => s.filter((item) => item.id !== id));
  }, []);

  const showResult = useCallback((next: SmartResult) => {
    setSettingsOpen(false);
    setPlannerOpen(false);
    setWriting(null);
    setResult({ ...next, createdAt: next.createdAt ?? new Date().toISOString() });
  }, []);

  const closeResult = useCallback(() => setResult(null), []);
  const openWriter = useCallback((draft: Omit<WritingDocument, "createdAt">) => {
    setResult(null);
    setSettingsOpen(false);
    setPlannerOpen(false);
    setWriting({ ...draft, createdAt: new Date().toISOString() });
  }, []);
  const updateWriting = useCallback((patch: Partial<WritingDocument>) => {
    setWriting((current) => (current ? { ...current, ...patch } : current));
  }, []);
  const closeWriter = useCallback(() => setWriting(null), []);
  const closePanels = useCallback(() => {
    setSettingsOpen(false);
    setPlannerOpen(false);
    setResult(null);
    setWriting(null);
  }, []);

  const enableNotifications = useCallback(async () => {
    try {
      if (!("Notification" in window)) return false;
      if (Notification.permission === "granted") return true;
      const permission = await Notification.requestPermission();
      return permission === "granted";
    } catch {
      return false;
    }
  }, []);

  /* Minute-level local scheduler. It never purchases without confirmation. */
  useEffect(() => {
    const check = () => {
      const now = new Date();
      const hhmm = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
      const today = now.toISOString().slice(0, 10);
      const weekday = now.getDay() !== 0 && now.getDay() !== 6;

      setSchedules((current) => {
        let changed = false;
        const next = current.map((schedule) => {
          const eligible =
            schedule.active &&
            schedule.time === hhmm &&
            schedule.lastRun !== today &&
            (schedule.repeat !== "weekdays" || weekday);
          if (!eligible) return schedule;

          changed = true;
          const product = schedule.productId
            ? db.products.find((p) => p.id === schedule.productId)
            : undefined;
          const message =
            document.documentElement.lang === "ar"
              ? `حان موعد ${schedule.title}. راجع الطلب قبل التأكيد.`
              : `It is time for ${schedule.title}. Review it before confirming.`;
          toast(message, "info");
          if ("Notification" in window && Notification.permission === "granted") {
            try {
              new Notification(profile.assistantName, {
                body: message,
                icon: "/images/roopa-realistic.png",
              });
            } catch {
              /* browser blocked an OS-level notification; in-app toast remains */
            }
          }
          setResult({
            kind: "schedule",
            title: schedule.title,
            subtitle: message,
            items: product
              ? [
                  {
                    id: product.id,
                    label: product.name,
                    image: product.img,
                    productId: product.id,
                    value: `${schedule.quantity ?? 1}x`,
                  },
                ]
              : [],
            note:
              document.documentElement.lang === "ar"
                ? "لن يتم الشراء تلقائيًا — أنت تؤكد كل طلب."
                : "Nothing is purchased automatically — you confirm every order.",
            createdAt: new Date().toISOString(),
          });
          return {
            ...schedule,
            lastRun: today,
            active: schedule.repeat === "once" ? false : schedule.active,
          };
        });
        return changed ? next : current;
      });
    };

    check();
    const id = window.setInterval(check, 30_000);
    return () => window.clearInterval(id);
  }, [db.products, profile.assistantName, toast]);

  const value = useMemo<ConciergeValue>(
    () => ({
      profile,
      updateProfile,
      schedules,
      addSchedule,
      updateSchedule,
      removeSchedule,
      result,
      showResult,
      closeResult,
      settingsOpen,
      plannerOpen,
      writing,
      openSettings: () => {
        setResult(null);
        setPlannerOpen(false);
        setWriting(null);
        setSettingsOpen(true);
      },
      openPlanner: () => {
        setResult(null);
        setSettingsOpen(false);
        setWriting(null);
        setPlannerOpen(true);
      },
      openWriter,
      updateWriting,
      closeWriter,
      closePanels,
      enableNotifications,
    }),
    [
      profile,
      updateProfile,
      schedules,
      addSchedule,
      updateSchedule,
      removeSchedule,
      result,
      showResult,
      closeResult,
      settingsOpen,
      plannerOpen,
      writing,
      openWriter,
      updateWriting,
      closeWriter,
      closePanels,
      enableNotifications,
    ]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useConcierge() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useConcierge must be inside ConciergeProvider");
  return ctx;
}