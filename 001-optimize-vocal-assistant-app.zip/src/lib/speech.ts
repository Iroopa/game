import { useCallback, useEffect, useRef, useState } from "react";
import type { MutableRefObject } from "react";
import type { Lang } from "./i18n";

export type AsstState = "idle" | "listening" | "processing" | "speaking";

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((e: any) => void) | null;
  onerror: ((e: any) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  }
}

/* ---------------------- female voice selection (Roopa) -------------------- */

/** Known-female voice names across Chrome / Edge / Safari / Android. */
const FEMALE_EN = [
  "google uk english female", "google us english", "samantha", "victoria", "karen",
  "moira", "tessa", "fiona", "serena", "allison", "ava", "susan", "zira", "aria",
  "jenny", "michelle", "sonia", "libby", "natasha", "clara", "female",
];
const FEMALE_AR = [
  "hoda", "salma", "zariyah", "amina", "laila", "layla", "maged female",
  "google عربي", "arabic female", "fatima", "noura", "hala", "female",
];
/** Voices that must never be chosen (clearly male). */
const MALE_HINT = ["male", "daniel", "alex", "fred", "george", "thomas", "rishi", "maged", "hamed", "shakir", "david", "mark", "guy"];

export function pickFemaleVoice(
  voices: SpeechSynthesisVoice[],
  wantAr: boolean,
  preferredName = ""
): SpeechSynthesisVoice | null {
  if (!voices.length) return null;
  if (preferredName) {
    const preferred = voices.find((v) => v.name === preferredName);
    if (preferred) return preferred;
  }
  const prefix = wantAr ? "ar" : "en";
  const pool = voices.filter((v) => v.lang?.toLowerCase().startsWith(prefix));
  const names = wantAr ? FEMALE_AR : FEMALE_EN;
  const isMale = (v: SpeechSynthesisVoice) => {
    const n = v.name.toLowerCase();
    return MALE_HINT.some((m) => n.includes(m)) && !n.includes("female");
  };

  /* 1 — explicit female name match, in preference order */
  for (const key of names) {
    const hit = pool.find((v) => v.name.toLowerCase().includes(key) && !isMale(v));
    if (hit) return hit;
  }
  /* 2 — any non-male voice in the right language (prefer local/high quality) */
  const clean = pool.filter((v) => !isMale(v));
  const local = clean.find((v) => v.localService);
  if (local) return local;
  if (clean.length) return clean[0];
  /* 3 — language fallback, then any female-sounding voice at all */
  if (pool.length) return pool[0];
  return voices.find((v) => names.some((k) => v.name.toLowerCase().includes(k))) ?? null;
}

/* ------------------------------ the engine ------------------------------ */

export interface SpeechEngine {
  state: AsstState;
  transcript: string;
  reply: string;
  typing: boolean;
  supportedSR: boolean;
  simulation: boolean;
  levelRef: MutableRefObject<number>;
  toggleMic: () => void;
  runCommand: (text: string) => void;
  stop: () => void;
}

export interface VoiceReply {
  reply: string;
  action?: () => void;
}

interface EngineOpts {
  lang: Lang;
  /** Live catalogue resolver — runs before the built-in intent replies. */
  resolve?: (text: string, lang: Lang) => VoiceReply | null | Promise<VoiceReply | null>;
  silenceMs?: number;
  sensitivity?: number;
  speakingRate?: number;
  pitch?: number;
  voiceNameEn?: string;
  voiceNameAr?: string;
}

export function useSpeechEngine({
  lang,
  resolve,
  silenceMs = 2200,
  sensitivity = 0.72,
  speakingRate = 0.96,
  pitch = 1.08,
  voiceNameEn = "",
  voiceNameAr = "",
}: EngineOpts): SpeechEngine {
  const [state, setState] = useState<AsstState>("idle");
  const [transcript, setTranscript] = useState("");
  const [reply, setReply] = useState("");
  const [typing, setTyping] = useState(false);
  const [simulation, setSimulation] = useState(false);

  const levelRef = useRef(0);
  const stateRef = useRef<AsstState>("idle");
  const transcriptRef = useRef("");
  const langRef = useRef<Lang>(lang);
  const recogRef = useRef<SpeechRecognitionLike | null>(null);
  const timers = useRef<number[]>([]);
  const rafRef = useRef(0);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const manualStopRef = useRef(false);
  const speakFlags = useRef({ typed: false, tts: true });
  const mountedRef = useRef(true);
  const finalBufferRef = useRef("");
  const finalizeTimerRef = useRef(0);
  const speechLangRef = useRef<Lang>(lang);
  const prefsRef = useRef({ silenceMs, sensitivity, speakingRate, pitch, voiceNameEn, voiceNameAr });

  langRef.current = lang;
  prefsRef.current = { silenceMs, sensitivity, speakingRate, pitch, voiceNameEn, voiceNameAr };
  const supportedSR =
    typeof window !== "undefined" &&
    !!(window.SpeechRecognition || window.webkitSpeechRecognition);

  const setPhase = useCallback((s: AsstState) => {
    stateRef.current = s;
    if (mountedRef.current) setState(s);
  }, []);

  const setTx = useCallback((tx: string) => {
    transcriptRef.current = tx;
    if (mountedRef.current) setTranscript(tx);
  }, []);

  const later = useCallback((fn: () => void, ms: number) => {
    const id = window.setTimeout(() => {
      if (mountedRef.current) fn();
    }, ms);
    timers.current.push(id);
  }, []);

  /* --------------------------- amplitude loop ---------------------------- */
  const startLevelLoop = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    const buf = new Uint8Array(256);
    const tick = (t: number) => {
      const st = stateRef.current;
      let target = 0;
      const ana = analyserRef.current;
      if (st === "listening" && ana) {
        ana.getByteTimeDomainData(buf);
        let sum = 0;
        for (let i = 0; i < buf.length; i += 2) {
          const v = (buf[i] - 128) / 128;
          sum += v * v;
        }
        const rms = Math.sqrt(sum / (buf.length / 2));
        target = Math.min(1, rms * (2.2 + prefsRef.current.sensitivity * 3.8));
      } else if (st === "listening") {
        target =
          0.34 + 0.18 * Math.sin(t / 260) + 0.1 * Math.sin(t / 67) + Math.random() * 0.06;
      } else if (st === "speaking") {
        target =
          0.5 + 0.24 * Math.sin(t / 210) + 0.12 * Math.sin(t / 89) + Math.random() * 0.08;
      } else if (st === "processing") {
        target = 0.16 + 0.05 * Math.sin(t / 300);
      }
      levelRef.current += (target - levelRef.current) * 0.22;
      if (levelRef.current < 0.001) levelRef.current = 0;
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
  }, []);

  /* ------------------------------ mic input ------------------------------ */
  const attachMic = useCallback(async () => {
    try {
      if (!navigator.mediaDevices?.getUserMedia) return;
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true },
      });
      if (!mountedRef.current || stateRef.current !== "listening") {
        stream.getTracks().forEach((tr) => tr.stop());
        return;
      }
      streamRef.current = stream;
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (!Ctx) return;
      const ctx = new Ctx();
      audioCtxRef.current = ctx;
      const src = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      analyser.smoothingTimeConstant = 0.55;
      src.connect(analyser);
      analyserRef.current = analyser;
    } catch {
      /* mic denied → simulated levels, still fine */
    }
  }, []);

  const detachMic = useCallback(() => {
    analyserRef.current = null;
    streamRef.current?.getTracks().forEach((tr) => tr.stop());
    streamRef.current = null;
    void audioCtxRef.current?.close().catch(() => undefined);
    audioCtxRef.current = null;
  }, []);

  /* ------------------------------ synthesis ------------------------------ */
  const finishSpeakCheck = useCallback(() => {
    if (speakFlags.current.typed && speakFlags.current.tts) {
      setPhase("idle");
      later(() => cancelAnimationFrame(rafRef.current), 250);
    }
  }, [later, setPhase]);

  const speak = useCallback(
    (text: string) => {
      setPhase("speaking");
      setTyping(true);
      if (mountedRef.current) setReply("");
      speakFlags.current = { typed: false, tts: false };
      startLevelLoop();

      /* visual typewriter */
      const total = text.length;
      let i = 0;
      const typeStep = () => {
        i += Math.max(1, Math.round(total / 95));
        if (mountedRef.current) setReply(text.slice(0, i));
        if (i < total) {
          later(typeStep, 26);
        } else {
          setTyping(false);
          speakFlags.current.typed = true;
          finishSpeakCheck();
        }
      };
      typeStep();

      /* audio TTS — Roopa is female in both languages */
      try {
        const synth = window.speechSynthesis;
        if (!synth) throw new Error("no tts");
        synth.cancel();
        const u = new SpeechSynthesisUtterance(text);
        const wantAr = speechLangRef.current === "ar";
        u.lang = wantAr ? "ar-EG" : "en-US";
        const preferred = wantAr ? prefsRef.current.voiceNameAr : prefsRef.current.voiceNameEn;
        const match = pickFemaleVoice(synth.getVoices(), wantAr, preferred);
        if (match) u.voice = match;
        /* Arabic benefits from a slightly more deliberate cadence. */
        u.rate = prefsRef.current.speakingRate * (wantAr ? 0.96 : 1);
        u.pitch = prefsRef.current.pitch;
        u.onend = () => {
          speakFlags.current.tts = true;
          finishSpeakCheck();
        };
        u.onerror = () => {
          speakFlags.current.tts = true;
          finishSpeakCheck();
        };
        synth.speak(u);
        later(() => {
          if (!synth.speaking && !speakFlags.current.tts) {
            speakFlags.current.tts = true;
            finishSpeakCheck();
          }
        }, 900);
      } catch {
        speakFlags.current.tts = true;
      }
      /* safety cap */
      later(() => {
        speakFlags.current = { typed: true, tts: true };
        finishSpeakCheck();
        setTyping(false);
      }, 14000);
    },
    [finishSpeakCheck, later, setPhase, startLevelLoop]
  );

  const resolveRef = useRef(resolve);
  resolveRef.current = resolve;

  const respond = useCallback(
    (text: string) => {
      setPhase("processing");
      startLevelLoop();
      later(
        async () => {
          const effectiveLang: Lang = /[\u0600-\u06ff]/.test(text) ? "ar" : langRef.current;
          speechLangRef.current = effectiveLang;
          const hit = await resolveRef.current?.(text, effectiveLang);
          if (!mountedRef.current) return;
          if (hit) {
            speak(hit.reply);
            if (hit.action) later(hit.action, 420);
            return;
          }
          speak(
            effectiveLang === "ar"
              ? "لم أجد إجابة موثوقة لهذا الطلب. جرّب صياغته بشكل أوضح، أو اطلب مني الكتابة أو البحث داخل الموقع."
              : "I couldn't find a reliable answer for that request. Try rephrasing it, or ask me to write or search inside the site."
          );
        },
        700 + Math.random() * 380
      );
    },
    [later, setPhase, speak, startLevelLoop]
  );

  /** Type out a command as if the user spoke it, then respond. */
  const runCommand = useCallback(
    (text: string) => {
      timers.current.forEach(clearTimeout);
      timers.current = [];
      try {
        window.speechSynthesis?.cancel();
      } catch {
        /* noop */
      }
      recogRef.current?.abort();
      detachMic();
      if (mountedRef.current) setReply("");
      setTx("");
      setPhase("listening");
      startLevelLoop();
      const words = text.split(" ");
      let i = 0;
      const step = () => {
        i += 1;
        setTx(words.slice(0, i).join(" "));
        if (i < words.length) {
          later(step, 90 + Math.random() * 80);
        } else {
          later(() => respond(text), 350);
        }
      };
      later(step, 420);
    },
    [detachMic, later, respond, setPhase, startLevelLoop]
  );

  /* ------------------------------ recognition ---------------------------- */
  const stopListeningSession = useCallback(() => {
    window.clearTimeout(finalizeTimerRef.current);
    finalizeTimerRef.current = 0;
    finalBufferRef.current = "";
    detachMic();
    recogRef.current?.abort();
    recogRef.current = null;
  }, [detachMic]);

  const startListening = useCallback(() => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
    try {
      window.speechSynthesis?.cancel();
    } catch {
      /* noop */
    }
    if (mountedRef.current) setReply("");
    window.clearTimeout(finalizeTimerRef.current);
    finalBufferRef.current = "";
    setTx("");
    setPhase("listening");
    startLevelLoop();

    if (!supportedSR) {
      setSimulation(true);
      setPhase("idle");
      window.dispatchEvent(new CustomEvent("iroopa:text-mode"));
      window.dispatchEvent(
        new CustomEvent("iroopa:voice-error", {
          detail:
            langRef.current === "ar"
              ? "هذا المتصفح لا يدعم التعرّف الصوتي المباشر. استخدم خانة الكتابة أو افتح الموقع في Chrome أو Edge."
              : "Live speech recognition is not supported here. Use the text box, or open the site in Chrome or Edge.",
        })
      );
      return;
    }

    const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition;
    const rec = new Ctor!();
    recogRef.current = rec;
    manualStopRef.current = false;
    rec.lang = langRef.current === "ar" ? "ar-EG" : "en-US";
    /* no time limit — keep the mic open until the user speaks or stops it */
    rec.continuous = true;
    rec.interimResults = true;
    rec.maxAlternatives = 1;

    rec.onresult = (e: any) => {
      let interim = "";
      let final = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const chunk = e.results[i][0]?.transcript ?? "";
        if (e.results[i].isFinal) final += chunk;
        else interim += chunk;
      }
      const accumulated = [finalBufferRef.current, final, interim].filter(Boolean).join(" ").trim();
      setTx(accumulated);
      if (final) {
        finalBufferRef.current = [finalBufferRef.current, final].filter(Boolean).join(" ").trim();
        window.clearTimeout(finalizeTimerRef.current);
        /* Natural turn-taking: give the user a few seconds to continue. */
        finalizeTimerRef.current = window.setTimeout(() => {
          const complete = finalBufferRef.current.trim();
          if (!complete || stateRef.current !== "listening") return;
          manualStopRef.current = true;
          finalBufferRef.current = "";
          setTx(complete);
          try {
            rec.stop();
          } catch {
            /* already stopped */
          }
          respond(complete);
        }, prefsRef.current.silenceMs);
      }
    };
    rec.onerror = (ev: any) => {
      const code = ev?.error;
      /* silence / no-speech is NOT an error here — onend will restart the mic */
      if (code === "no-speech" || code === "aborted") return;
      if (code === "not-allowed" || code === "service-not-allowed") {
        setSimulation(true);
        window.dispatchEvent(
          new CustomEvent("iroopa:voice-error", {
            detail:
              langRef.current === "ar"
                ? "تم رفض إذن الميكروفون — فعّله من إعدادات المتصفح."
                : "Microphone blocked — enable it in your browser settings.",
          })
        );
      } else if (code === "network") {
        window.dispatchEvent(
          new CustomEvent("iroopa:voice-error", {
            detail:
              langRef.current === "ar"
                ? "مشكلة في الشبكة — التعرّف على الصوت غير متاح الآن."
                : "Network issue — speech recognition is unavailable.",
          })
        );
      }
      if (stateRef.current === "listening" && !manualStopRef.current) {
        setPhase("idle");
        detachMic();
      }
    };
    rec.onend = () => {
      /* Chrome force-ends after silence — restart so the user has unlimited
         time to think before speaking. Only a manual stop truly ends it. */
      if (
        stateRef.current === "listening" &&
        !manualStopRef.current &&
        mountedRef.current &&
        recogRef.current === rec
      ) {
        try {
          rec.start();
          return;
        } catch {
          /* engine busy → fall through to idle */
        }
      }
      detachMic();
      if (stateRef.current === "listening" && !manualStopRef.current && mountedRef.current) {
        setPhase("idle");
        later(() => cancelAnimationFrame(rafRef.current), 400);
      }
    };
    try {
      rec.start();
      attachMic();
    } catch {
      setPhase("idle");
      detachMic();
    }
  }, [attachMic, detachMic, later, respond, setPhase, startLevelLoop, supportedSR]);

  const stop = useCallback(() => {
    manualStopRef.current = true;
    stopListeningSession();
    timers.current.forEach(clearTimeout);
    timers.current = [];
    try {
      window.speechSynthesis?.cancel();
    } catch {
      /* noop */
    }
    setTyping(false);
    setPhase("idle");
    later(() => cancelAnimationFrame(rafRef.current), 400);
  }, [later, setPhase, stopListeningSession]);

  const toggleMic = useCallback(() => {
    if (stateRef.current === "idle") startListening();
    else if (stateRef.current === "listening") {
      manualStopRef.current = true;
      stopListeningSession();
      const cur = transcriptRef.current.trim();
      if (cur) respond(cur);
      else {
        setPhase("idle");
        later(() => cancelAnimationFrame(rafRef.current), 400);
      }
    } else stop();
  }, [later, respond, setPhase, startListening, stop, stopListeningSession]);

  /* ------------------------------ lifecycle ------------------------------ */
  const detachMicRef = useRef(detachMic);
  detachMicRef.current = detachMic;

  /* warm up the voice list — getVoices() is empty until the engine loads */
  useEffect(() => {
    const synth = window.speechSynthesis;
    if (!synth) return;
    const warm = () => synth.getVoices();
    warm();
    synth.addEventListener?.("voiceschanged", warm);
    return () => synth.removeEventListener?.("voiceschanged", warm);
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      timers.current.forEach(clearTimeout);
      window.clearTimeout(finalizeTimerRef.current);
      cancelAnimationFrame(rafRef.current);
      recogRef.current?.abort();
      try {
        window.speechSynthesis?.cancel();
      } catch {
        /* noop */
      }
      detachMicRef.current?.();
    };
  }, []);

  useEffect(() => {
    /* abort an in-flight session when language flips mid-flight */
    if (stateRef.current !== "idle") stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lang]);

  return {
    state,
    transcript,
    reply,
    typing,
    supportedSR,
    simulation: simulation || !supportedSR,
    levelRef,
    toggleMic,
    runCommand,
    stop,
  };
}
