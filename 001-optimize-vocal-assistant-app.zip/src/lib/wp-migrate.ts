/**
 * WordPress → iRoopa migration bridge.
 *
 * Consumes the "extracted website data" JSON produced from the legacy iROOPA
 * WordPress database. The legacy SQL contains NO WooCommerce products and no
 * vendor directory, so this parser never fabricates products, sellers, prices
 * or media. It extracts what exists and reports what is missing.
 */

export interface WpPageRecord {
  id: string;
  wpId: number;
  title: string;
  slug: string;
  type: string;
  status: string;
  content: string;
  excerpt?: string;
  isPlaceholder: boolean;
  placeholderReason?: string;
  mediaRefs: string[];
  importedAt: string;
}

export interface WpNavItem {
  label: string;
  url: string;
  order: number;
}

export interface WpTermRecord {
  taxonomy: string;
  name: string;
  slug: string;
  count: number;
}

export interface MigrationReport {
  bundleTagline?: string;
  tablesDetected: number;
  pages: number;
  placeholders: number;
  navItems: number;
  terms: number;
  mediaReferences: number;
  /** Always reported honestly — the legacy DB has none. */
  productsFound: number;
  vendorsFound: number;
  missingMedia: string[];
  currenciesDetected: string[];
  notes: string[];
}

export interface ParsedBundle {
  pages: WpPageRecord[];
  nav: WpNavItem[];
  terms: WpTermRecord[];
  report: MigrationReport;
}

/* ------------------------------ tolerant parsing ------------------------- */

type Row = Record<string, unknown>;

const str = (v: unknown): string =>
  typeof v === "string" ? v : typeof v === "number" ? String(v) : "";

const num = (v: unknown): number => {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};

/** Finds the first array of objects under any of the given keys, at any depth. */
function findRows(root: unknown, keys: string[]): Row[] {
  const seen = new Set<unknown>();
  const queue: unknown[] = [root];
  while (queue.length) {
    const node = queue.shift();
    if (!node || typeof node !== "object" || seen.has(node)) continue;
    seen.add(node);
    if (Array.isArray(node)) {
      const arr = node as unknown[];
      if (arr.length && typeof arr[0] === "object") return arr as Row[];
      continue;
    }
    for (const [k, v] of Object.entries(node as Row)) {
      if (keys.includes(k.toLowerCase())) {
        if (Array.isArray(v) && v.length && typeof v[0] === "object") return v as Row[];
      }
      queue.push(v);
    }
  }
  return [];
}

const MEDIA_RE = /(?:https?:\/\/[^\s"')]*|\/)?wp-content\/uploads\/[^\s"')]+/gi;

function extractMediaRefs(...texts: string[]): string[] {
  const out = new Set<string>();
  texts.forEach((text) => {
    if (!text) return;
    const matches = text.match(MEDIA_RE);
    matches?.forEach((m) => out.add(m));
  });
  return [...out];
}

const PLACEHOLDER_PATTERNS: { test: RegExp; reason: string }[] = [
  { test: /lorem ipsum/i, reason: "Contains lorem ipsum filler" },
  { test: /^(sample|test|demo|draft|untitled)/i, reason: "Placeholder title" },
  { test: /\[woocommerce/i, reason: "Unrendered WooCommerce shortcode" },
  { test: /\[elementor/, reason: "Unrendered Elementor shortcode" },
];

function classifyPlaceholder(title: string, content: string): { is: boolean; reason?: string } {
  const text = `${title} ${content}`;
  for (const p of PLACEHOLDER_PATTERNS) {
    if (p.test.test(text)) return { is: true, reason: p.reason };
  }
  if (content.replace(/\s/g, "").length < 40) {
    return { is: true, reason: "Page body is empty or near-empty" };
  }
  return { is: false };
}

/** Pulls a currency hint out of content without asserting one. */
function detectCurrencies(pages: Row[]): string[] {
  const found = new Set<string>();
  pages.forEach((p) => {
    const text = `${str(p.post_title)} ${str(p.post_content)}`;
    if (/\bEGP\b|جنيه/.test(text)) found.add("EGP");
    if (/\bUSD\b|\$/.test(text)) found.add("USD");
    if (/\bEUR\b|€/.test(text)) found.add("EUR");
    if (/\bAED\b/.test(text)) found.add("AED");
    if (/\bSAR\b/.test(text)) found.add("SAR");
  });
  return [...found];
}

/**
 * Accepts the extracted-JSON bundle in any of the common shapes:
 * a bare array of rows, { posts: [...] }, { data: { posts: [...] } },
 * or a full { tables: { wp_posts: [...] } } inventory.
 */
export function parseWordPressBundle(raw: unknown, tablesDetected = 50): ParsedBundle {
  const pages: WpPageRecord[] = [];
  const nav: WpNavItem[] = [];
  const terms: WpTermRecord[] = [];
  const missingMedia = new Set<string>();
  let tagline: string | undefined;

  /* --- tagline: frequently stored as an option row --- */
  const optionRows = findRows(raw, ["options", "wp_options", "settings"]);
  optionRows.forEach((o) => {
    const name = str(o.option_name);
    const value = str(o.option_value);
    if (name === "blogdescription" && value) tagline = value;
  });

  /* --- content rows (posts + pages + attachments) --- */
  const contentRows = findRows(raw, [
    "posts", "wp_posts", "content", "records", "pages", "items", "data",
  ]);

  contentRows.forEach((row, index) => {
    const type = str(row.post_type) || str(row.type) || "post";
    const title = str(row.post_title) || str(row.title) || "";
    const content = str(row.post_content) || str(row.content) || "";
    const status = str(row.post_status) || str(row.status) || "publish";
    const slug = str(row.post_name) || str(row.slug) || `wp-${index}`;
    const wpId = num(row.ID ?? row.id ?? index);

    /* Attachments are media references, not content pages. */
    if (type === "attachment" || type === "media") {
      extractMediaRefs(str(row.guid), str(row.post_mime_type), content).forEach((m) =>
        missingMedia.add(m)
      );
      return;
    }

    if (type !== "page" && type !== "post" && type !== "revision") return;
    if (type === "revision") return;

    const mediaRefs = extractMediaRefs(content, str(row.guid));
    mediaRefs.forEach((m) => missingMedia.add(m));

    const ph = classifyPlaceholder(title, content);
    pages.push({
      id: `wp-${wpId}-${index}`,
      wpId,
      title: title || "(untitled)",
      slug,
      type,
      status,
      content,
      isPlaceholder: ph.is,
      placeholderReason: ph.reason,
      mediaRefs,
      importedAt: new Date().toISOString(),
    });
  });

  /* --- navigation --- */
  const navRows = findRows(raw, ["nav", "navigation", "menu", "menus", "nav_menu"]);
  navRows.forEach((row, index) => {
    const label = str(row.title) || str(row.post_title) || str(row.menu_item_title) || "";
    const url = str(row.url) || str(row.guid) || "";
    if (!label && !url) return;
    nav.push({ label: label || "(unlabelled)", url, order: num(row.menu_order) || index });
  });

  /* --- taxonomy terms --- */
  const termRows = findRows(raw, ["terms", "wp_terms", "taxonomies", "term_relationships"]);
  termRows.forEach((row) => {
    const name = str(row.name) || str(row.term_name);
    if (!name) return;
    terms.push({
      taxonomy: str(row.taxonomy) || str(row.term_taxonomy) || "category",
      name,
      slug: str(row.slug) || str(row.term_slug) || name.toLowerCase(),
      count: num(row.count),
    });
  });

  /* --- dedupe media refs --- */
  const missingMediaList = [...missingMedia];

  const report: MigrationReport = {
    bundleTagline: tagline,
    tablesDetected,
    pages: pages.length,
    placeholders: pages.filter((p) => p.isPlaceholder).length,
    navItems: nav.length,
    terms: terms.length,
    mediaReferences: missingMediaList.length,
    /* Reported honestly: the legacy database contains neither. */
    productsFound: 0,
    vendorsFound: 0,
    missingMedia: missingMediaList,
    currenciesDetected: detectCurrencies(contentRows),
    notes: [
      "Legacy SQL contains no WooCommerce product records — no products were invented.",
      "No fashion-vendor directory exists in the source — no vendors were invented.",
      "Media files are not present in the SQL; image URLs are reported as missing assets.",
      "The RAR archive holds WP Rocket plugin files, not site source or content.",
    ],
  };

  return { pages, nav, terms, report };
}

/** Builds a downloadable migration report for record-keeping. */
export function buildReportJson(bundle: ParsedBundle, currency: string) {
  return {
    generatedAt: new Date().toISOString(),
    source: "iROOPA legacy WordPress database",
    tagline: bundle.report.bundleTagline,
    currencyConfirmed: currency,
    summary: {
      tablesDetected: bundle.report.tablesDetected,
      pages: bundle.report.pages,
      placeholderPages: bundle.report.placeholders,
      navigationItems: bundle.report.navItems,
      taxonomyTerms: bundle.report.terms,
      mediaReferences: bundle.report.mediaReferences,
      productsFound: bundle.report.productsFound,
      vendorsFound: bundle.report.vendorsFound,
    },
    currenciesDetectedInContent: bundle.report.currenciesDetected,
    missingMedia: bundle.report.missingMedia,
    placeholderPages: bundle.pages
      .filter((p) => p.isPlaceholder)
      .map((p) => ({ title: p.title, slug: p.slug, reason: p.placeholderReason })),
    navigation: bundle.nav,
    notes: bundle.report.notes,
  };
}
