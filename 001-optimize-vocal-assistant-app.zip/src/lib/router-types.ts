export type RouteName = "home" | "dashboard" | "showcase" | "submit";

export interface Route {
  name: RouteName;
  sub?: string;
}

export function parseRoute(hash: string): Route {
  if (hash.startsWith("#/")) {
    const parts = hash.slice(2).split("/").filter(Boolean);
    if (parts[0] === "dashboard") return { name: "dashboard", sub: parts[1] };
    if (parts[0] === "showcase") return { name: "showcase" };
    if (parts[0] === "submit") return { name: "submit" };
  }
  return { name: "home" };
}
