import { Sparkles } from "lucide-react";
import { useMemo, useRef, useState } from "react";

interface DarkWoodButtonProps {
  label?: string;
  onClick?: () => void;
  viewMode?: "text" | "icon";
  className?: string;
}

export function DarkWoodButton({
  label = "Get Started",
  onClick,
  viewMode = "text",
  className = "",
}: DarkWoodButtonProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isPressed, setIsPressed] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const dimensions = useMemo(() => {
    if (viewMode === "icon") {
      return { width: 46, height: 46 };
    } else {
      return { width: 142, height: 46 };
    }
  }, [viewMode]);

  return (
    <div className={`relative inline-block ${className}`}>
      <button
        ref={buttonRef}
        onClick={onClick}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => {
          setIsHovered(false);
          setIsPressed(false);
        }}
        onMouseDown={() => setIsPressed(true)}
        onMouseUp={() => setIsPressed(false)}
        style={{
          width: `${dimensions.width}px`,
          height: `${dimensions.height}px`,
          position: "relative",
          background: "transparent",
          border: "none",
          cursor: "pointer",
          outline: "none",
          borderRadius: "100px",
          transform: isPressed ? "translateY(2px)" : "translateY(0)",
          transition: "transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)",
        }}
        aria-label={label}
      >
        {/* Shadow Layer */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: "100px",
            background: "rgba(0,0,0,0.4)",
            transform: isPressed ? "translateY(0)" : "translateY(4px)",
            transition: "transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)",
            zIndex: 1,
            filter: "blur(4px)",
          }}
        />

        {/* Base Layer - Dark Wood/Blue effect */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: "100px",
            background: "linear-gradient(145deg, #1a202c, #2d3748)",
            boxShadow: isHovered
              ? "inset 0 0 0 1px rgba(255,255,255,0.2), 0 0 15px rgba(59,130,246,0.4)"
              : "inset 0 0 0 1px rgba(255,255,255,0.1)",
            transition: "all 0.3s ease",
            overflow: "hidden",
            zIndex: 2,
          }}
        >
          {/* Animated Highlight / Grain */}
          <div
            style={{
              position: "absolute",
              inset: "-50%",
              background: "linear-gradient(45deg, transparent 40%, rgba(96,165,250,0.3) 50%, transparent 60%)",
              backgroundSize: "200% 200%",
              animation: isHovered ? "wood-shine 3s linear infinite" : "none",
              opacity: isHovered ? 1 : 0,
              transition: "opacity 0.3s ease",
            }}
          />
          <style>
            {`
              @keyframes wood-shine {
                0% { background-position: 200% 0; }
                100% { background-position: -200% 0; }
              }
            `}
          </style>
        </div>

        {/* Content Layer */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 3,
            color: "#e2e8f0",
          }}
        >
          {viewMode === "icon" ? (
            <Sparkles size={16} />
          ) : (
            <span
              style={{
                fontSize: "13px",
                fontWeight: 600,
                textShadow: "0px 1px 2px rgba(0, 0, 0, 0.8)",
                whiteSpace: "nowrap",
              }}
            >
              {label}
            </span>
          )}
        </div>
      </button>
    </div>
  );
}
