import { useEffect, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  AlertTriangle,
  CheckCircle2,
  Crosshair,
  GripVertical,
  Info,
  Maximize2,
  Minimize2,
  X,
  type LucideIcon,
} from "lucide-react";
import { useStore } from "../../lib/store";
import { cn } from "../../utils/cn";

/* --------------------------------- modal --------------------------------- */

type ModalSize = "sm" | "md" | "lg" | "xl";

export function Modal({
  open,
  onClose,
  children,
  wide,
  labelledBy,
  size,
  resizable = false,
  chrome = false,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  /** Legacy boolean kept for compatibility — maps to size="lg". */
  wide?: boolean;
  labelledBy?: string;
  size?: ModalSize;
  /** Adds a drag handle so the dialog can be resized vertically. */
  resizable?: boolean;
  /** Adds window chrome: move, recenter and fullscreen controls. */
  chrome?: boolean;
}) {
  const [height, setHeight] = useState<number | null>(null);
  const dragRef = useRef<{ startY: number; startH: number } | null>(null);
  const sheetRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  /* free positioning */
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [isFull, setIsFull] = useState(false);
  const moveRef = useRef<{ mx: number; my: number; ox: number; oy: number } | null>(null);

  useEffect(() => {
    if (!open) return;
    setHeight(null);
    setOffset({ x: 0, y: 0 });
    setIsFull(false);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    const clamp = () =>
      setHeight((h) => (h ? Math.min(h, window.innerHeight * 0.94) : h));
    document.addEventListener("keydown", onKey);
    window.addEventListener("resize", clamp);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.requestAnimationFrame(() => scrollRef.current?.scrollTo({ top: 0 }));
    return () => {
      document.removeEventListener("keydown", onKey);
      window.removeEventListener("resize", clamp);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  /* move the whole dialog by dragging the chrome bar (desktop / touch) */
  const startMove = (e: React.PointerEvent) => {
    if (isFull) return;
    moveRef.current = { mx: e.clientX, my: e.clientY, ox: offset.x, oy: offset.y };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const doMove = (e: React.PointerEvent) => {
    const m = moveRef.current;
    if (!m) return;
    setOffset({ x: m.ox + (e.clientX - m.mx), y: m.oy + (e.clientY - m.my) });
  };
  const endMove = (e: React.PointerEvent) => {
    if (!moveRef.current) return;
    moveRef.current = null;
    (e.currentTarget as HTMLElement).releasePointerCapture?.(e.pointerId);
  };

  /* pointer-based vertical resize */
  const startDrag = (e: React.PointerEvent) => {
    const startH = sheetRef.current?.offsetHeight ?? window.innerHeight * 0.9;
    dragRef.current = { startY: e.clientY, startH };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };
  const moveDrag = (e: React.PointerEvent) => {
    if (!dragRef.current) return;
    const delta = dragRef.current.startY - e.clientY;
    const next = Math.min(
      window.innerHeight * 0.95,
      Math.max(window.innerHeight * 0.4, dragRef.current.startH + delta)
    );
    setHeight(next);
  };
  const endDrag = (e: React.PointerEvent) => {
    if (!dragRef.current) return;
    dragRef.current = null;
    (e.currentTarget as HTMLElement).releasePointerCapture?.(e.pointerId);
  };

  const resolved: ModalSize = size ?? (wide ? "lg" : "md");
  const maxWidth =
    resolved === "sm"
      ? "max-w-md"
      : resolved === "md"
        ? "max-w-lg"
        : resolved === "lg"
          ? "max-w-4xl"
          : "max-w-6xl";

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.22 }}
          className="fixed inset-0 z-[70] flex items-end justify-center overflow-hidden bg-black/60 p-0 backdrop-blur-sm sm:items-center sm:p-5 lg:p-8"
          onClick={onClose}
          role="presentation"
        >
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-labelledby={labelledBy}
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            onClick={(e) => e.stopPropagation()}
            ref={sheetRef}
            className={cn(
              "card-surface relative flex w-full flex-col overflow-hidden rounded-t-3xl shadow-[0_28px_100px_-24px_rgba(0,0,0,.75)]",
              isFull
                ? "h-[96dvh] max-h-[96dvh] max-w-[calc(100vw-1rem)] sm:h-[94dvh] sm:max-h-[94dvh] sm:max-w-[calc(100vw-2.5rem)] sm:rounded-3xl"
                : "h-[96dvh] max-h-[96dvh] max-w-[calc(100vw-1rem)] sm:h-auto sm:max-h-[92dvh] sm:max-w-[calc(100vw-2.5rem)] sm:rounded-3xl",
              maxWidth
            )}
            style={{
              ...(height && !isFull ? { height: `${height}px` } : {}),
              ...(isFull ? {} : { x: offset.x, y: offset.y }),
            }}
          >
            {/* window chrome: drag to move, recenter, fullscreen, close */}
            {chrome && (
              <div className="z-40 flex shrink-0 items-center gap-1.5 border-b border-line bg-elev/90 px-2 py-1.5 backdrop-blur-xl sm:px-3">
                <div
                  onPointerDown={startMove}
                  onPointerMove={doMove}
                  onPointerUp={endMove}
                  onPointerCancel={endMove}
                  role="separator"
                  aria-orientation="horizontal"
                  aria-label="Move dialog"
                  tabIndex={0}
                  className="flex h-7 min-w-0 flex-1 cursor-grab touch-none select-none items-center gap-2 rounded-lg px-2 text-[10px] font-semibold text-fg3 transition-colors hover:bg-ink/50 hover:text-fg active:cursor-grabbing"
                >
                  <GripVertical className="h-3.5 w-3.5 shrink-0" aria-hidden />
                  <span className="truncate">{isFull ? "" : "Drag to move"}</span>
                </div>
                <button
                  type="button"
                  onClick={() => { setOffset({ x: 0, y: 0 }); setIsFull(false); setHeight(null); }}
                  aria-label="Recenter dialog"
                  title="Recenter"
                  className="hidden h-7 w-7 place-items-center rounded-lg text-fg3 transition-colors hover:bg-ink/50 hover:text-fg sm:grid"
                >
                  <Crosshair className="h-3.5 w-3.5" aria-hidden />
                </button>
                <button
                  type="button"
                  onClick={() => setIsFull((v) => !v)}
                  aria-label={isFull ? "Restore dialog" : "Fullscreen dialog"}
                  title={isFull ? "Restore" : "Fullscreen"}
                  className="grid h-7 w-7 place-items-center rounded-lg text-fg3 transition-colors hover:bg-ink/50 hover:text-fg"
                >
                  {isFull ? <Minimize2 className="h-3.5 w-3.5" aria-hidden /> : <Maximize2 className="h-3.5 w-3.5" aria-hidden />}
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  aria-label="Close dialog"
                  title="Close"
                  className="grid h-7 w-7 place-items-center rounded-lg text-fg3 transition-colors hover:bg-rose-500/15 hover:text-rose-400"
                >
                  <X className="h-3.5 w-3.5" aria-hidden />
                </button>
              </div>
            )}
            {resizable && !isFull && (
              <div
                onPointerDown={startDrag}
                onPointerMove={moveDrag}
                onPointerUp={endDrag}
                onPointerCancel={endDrag}
                role="separator"
                aria-orientation="horizontal"
                aria-label="Resize dialog"
                tabIndex={0}
                className="group absolute inset-x-0 top-0 z-30 flex h-4 shrink-0 cursor-row-resize touch-none items-center justify-center"
              >
                <span className="h-1 w-12 rounded-full bg-line2 transition-colors group-hover:bg-brand/70" />
              </div>
            )}
            {/* independently scrollable body so long content never clips the controls */}
            <div
              ref={scrollRef}
              className="min-h-0 flex-1 overflow-x-hidden overflow-y-auto overscroll-contain [scrollbar-gutter:stable]"
            >
              {children}
            </div>
            {!chrome && (
              <button
                type="button"
                onClick={onClose}
                aria-label="Close dialog"
                className="absolute end-3 top-3 z-50 grid h-10 w-10 place-items-center rounded-full border border-line bg-panel/90 text-fg2 shadow-lg backdrop-blur-xl transition-all hover:border-brand/50 hover:text-fg active:scale-95"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* --------------------------------- toasts -------------------------------- */

const TOAST_ICON: Record<string, LucideIcon> = {
  ok: CheckCircle2,
  warn: AlertTriangle,
  err: AlertTriangle,
  info: Info,
};
const TOAST_COLOR: Record<string, string> = {
  ok: "text-brand border-brand/60 shadow-[0_0_0_3px_color-mix(in_oklab,var(--c-brand)_14%,transparent),0_18px_40px_-16px_color-mix(in_oklab,var(--c-brand)_60%,transparent)]",
  warn: "text-gold border-gold/60 shadow-[0_0_0_3px_color-mix(in_oklab,var(--c-gold)_14%,transparent),0_18px_40px_-16px_color-mix(in_oklab,var(--c-gold)_55%,transparent)]",
  err: "text-rose-400 border-rose-400/60 shadow-[0_0_0_3px_rgba(244,63,94,0.14),0_18px_40px_-16px_rgba(244,63,94,0.6)]",
  info: "text-accent border-accent/60 shadow-[0_0_0_3px_color-mix(in_oklab,var(--c-accent)_14%,transparent),0_18px_40px_-16px_color-mix(in_oklab,var(--c-accent)_55%,transparent)]",
};
const TOAST_BAR: Record<string, string> = {
  ok: "bg-brand",
  warn: "bg-gold",
  err: "bg-rose-400",
  info: "bg-accent",
};

export function ToastViewport() {
  const { toasts, dismissToast } = useStore();
  return (
    <div className="pointer-events-none fixed end-4 top-16 z-[90] flex w-[min(92vw,340px)] flex-col gap-2" aria-live="polite">
      <AnimatePresence>
        {toasts.map((t) => {
          const Icon = TOAST_ICON[t.kind];
          return (
            <motion.div
              key={t.id}
              layout
              initial={{ opacity: 0, x: 44 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 44 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className={cn(
                "glass pointer-events-auto relative overflow-hidden rounded-xl border px-3.5 py-3",
                TOAST_COLOR[t.kind]
              )}
            >
              <div className="flex items-start gap-2.5">
                <motion.span
                  animate={{ scale: [1, 1.18, 1] }}
                  transition={{ duration: 1.1, repeat: 2 }}
                  className="mt-0.5 shrink-0"
                >
                  <Icon className="h-4 w-4" aria-hidden />
                </motion.span>
                <p className="flex-1 text-xs font-semibold leading-snug text-fg" dir="auto">
                  {t.msg}
                </p>
                <button
                  type="button"
                  onClick={() => dismissToast(t.id)}
                  className="text-fg3 transition-colors hover:text-fg"
                  aria-label="Dismiss notification"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
              {/* countdown highlight bar */}
              <motion.span
                initial={{ scaleX: 1 }}
                animate={{ scaleX: 0 }}
                transition={{ duration: 3.4, ease: "linear" }}
                className={cn("absolute inset-x-0 bottom-0 h-0.5 origin-left", TOAST_BAR[t.kind])}
              />
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}

/* ---------------------------- form primitives ---------------------------- */

export function L({ children }: { children: ReactNode }) {
  return (
    <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-widest text-fg3">
      {children}
    </label>
  );
}

export const inputCls =
  "w-full rounded-xl border border-line bg-ink/60 px-3.5 py-2.5 text-sm text-fg outline-none transition-colors placeholder:text-fg3/70 focus:border-brand/60";

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div>
      <L>{label}</L>
      {children}
    </div>
  );
}

/* ---------------------------- resilient image ---------------------------- */

export function ImgWithFallback({
  src,
  alt,
  letter,
  hue = 160,
  className,
}: {
  src: string;
  alt: string;
  letter: string;
  hue?: number;
  className?: string;
}) {
  const [err, setErr] = useState(false);
  if (err || !src) {
    return (
      <div
        className={cn("grid place-items-center", className)}
        style={{ background: `linear-gradient(135deg, hsl(${hue} 60% 42% / 0.9), hsl(${(hue + 60) % 360} 70% 30% / 0.95))` }}
        aria-label={alt}
        role="img"
      >
        <span className="font-display text-2xl font-bold text-white/90">{letter}</span>
      </div>
    );
  }
  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      decoding="async"
      referrerPolicy="no-referrer"
      onError={() => setErr(true)}
      className={className}
    />
  );
}

/* ------------------------------ file helpers ----------------------------- */

export function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}

export function downloadJSON(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function importJSONFile<T>(file: File): Promise<T> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => {
      try {
        res(JSON.parse(String(r.result)) as T);
      } catch (e) {
        rej(e);
      }
    };
    r.onerror = rej;
    r.readAsText(file);
  });
}

/* --------------------------- two-step delete ----------------------------- */

export function TwoStepDelete({ onConfirm, className }: { onConfirm: () => void; className?: string }) {
  const [armed, setArmed] = useState(false);
  useEffect(() => {
    if (!armed) return;
    const t = window.setTimeout(() => setArmed(false), 2600);
    return () => window.clearTimeout(t);
  }, [armed]);
  return (
    <button
      type="button"
      onClick={() => (armed ? onConfirm() : setArmed(true))}
      className={cn(
        "rounded-lg border px-2.5 py-1.5 text-[11px] font-bold transition-all",
        armed
          ? "border-rose-400/60 bg-rose-500/15 text-rose-400"
          : "border-line bg-elev/60 text-fg3 hover:border-rose-400/40 hover:text-rose-400",
        className
      )}
    >
      {armed ? "Sure?" : "Delete"}
    </button>
  );
}
