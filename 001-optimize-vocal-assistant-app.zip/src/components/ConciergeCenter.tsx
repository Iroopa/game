import { useEffect, useMemo, useState } from "react";
import {
  AlarmClock,
  BellRing,
  Calculator,
  CalendarClock,
  Check,
  Clipboard,
  Clock3,
  Download,
  ExternalLink,
  MapPin,
  Mic2,
  PackageCheck,
  Plus,
  Settings2,
  ShoppingCart,
  Sparkles,
  Trash2,
  Trophy,
  UserRound,
  Volume2,
  WandSparkles,
} from "lucide-react";
import { motion } from "framer-motion";
import { useLang } from "../lib/i18n";
import {
  useConcierge,
  type NeedSchedule,
  type ScheduleRepeat,
  type SmartResultKind,
} from "../lib/concierge";
import { fmtEGP, useStore } from "../lib/store";
import { Field, ImgWithFallback, Modal, inputCls } from "./ui";
import { cn } from "../utils/cn";

const RESULT_ICON: Record<SmartResultKind, typeof Sparkles> = {
  comparison: Trophy,
  order: PackageCheck,
  calculation: Calculator,
  schedule: CalendarClock,
  summary: ShoppingCart,
  answer: Sparkles,
};

function useSystemVoices() {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  useEffect(() => {
    const synth = window.speechSynthesis;
    if (!synth) return;
    const load = () => setVoices(synth.getVoices());
    load();
    synth.addEventListener?.("voiceschanged", load);
    return () => synth.removeEventListener?.("voiceschanged", load);
  }, []);
  return voices;
}

function SettingsPanel() {
  const { lang } = useLang();
  const ar = lang === "ar";
  const { profile, updateProfile, enableNotifications, closePanels } = useConcierge();
  const { toast } = useStore();
  const voices = useSystemVoices();
  const enVoices = useMemo(() => voices.filter((v) => v.lang.toLowerCase().startsWith("en")), [voices]);
  const arVoices = useMemo(() => voices.filter((v) => v.lang.toLowerCase().startsWith("ar")), [voices]);

  const preview = () => {
    const synth = window.speechSynthesis;
    synth.cancel();
    const u = new SpeechSynthesisUtterance(
      ar
        ? `أهلاً ${profile.userName}. أنا ${profile.assistantName}، جاهزة أساعدك.`
        : `Hello ${profile.userName}. I'm ${profile.assistantName}, ready to help.`
    );
    u.lang = ar ? "ar-EG" : "en-US";
    const wanted = ar ? profile.voiceNameAr : profile.voiceNameEn;
    const selected = voices.find((v) => v.name === wanted);
    if (selected) u.voice = selected;
    u.rate = profile.speakingRate;
    u.pitch = profile.pitch;
    synth.speak(u);
  };

  return (
    <div className="p-6 sm:p-7">
      <div className="flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-brand to-accent text-onbrand">
          <Settings2 className="h-5 w-5" aria-hidden />
        </span>
        <div>
          <h2 id="concierge-settings" className="font-display text-xl font-bold">
            {ar ? "خصّص مساعدك" : "Personalize your concierge"}
          </h2>
          <p className="text-xs text-fg3">
            {ar ? "اسمك، اسم المساعدة، وطريقة الاستماع والرد" : "Names, listening behavior and natural voice"}
          </p>
        </div>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Field label={ar ? "اسمك" : "Your name"}>
          <div className="relative">
            <UserRound className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg3" aria-hidden />
            <input
              className={cn(inputCls, "ps-9")}
              value={profile.userName}
              onChange={(e) => updateProfile({ userName: e.target.value.slice(0, 28) })}
              placeholder={ar ? "مثال: أحمد" : "e.g. Maya"}
            />
          </div>
        </Field>
        <Field label={ar ? "اسم المساعدة" : "Assistant name"}>
          <div className="relative">
            <Sparkles className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-brand" aria-hidden />
            <input
              className={cn(inputCls, "ps-9")}
              value={profile.assistantName}
              onChange={(e) => updateProfile({ assistantName: e.target.value.slice(0, 24) })}
              placeholder={ar ? "مثال: روبا" : "e.g. Roopa"}
            />
          </div>
        </Field>
      </div>

      <div className="mt-5 rounded-2xl border border-line bg-elev/45 p-4">
        <p className="flex items-center gap-2 text-xs font-bold text-fg">
          <Mic2 className="h-4 w-4 text-brand" aria-hidden />
          {ar ? "حساسية الاستماع وانتظار نهاية السؤال" : "Listening sensitivity and turn timing"}
        </p>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <label className="text-[11px] font-semibold text-fg2">
            <span className="mb-2 flex justify-between">
              <span>{ar ? "حساسية الميكروفون" : "Microphone sensitivity"}</span>
              <span className="text-brand">{Math.round(profile.sensitivity * 100)}%</span>
            </span>
            <input
              type="range"
              min={0.25}
              max={1}
              step={0.05}
              value={profile.sensitivity}
              onChange={(e) => updateProfile({ sensitivity: Number(e.target.value) })}
              className="w-full accent-[var(--c-brand)]"
            />
          </label>
          <label className="text-[11px] font-semibold text-fg2">
            <span className="mb-2 flex justify-between">
              <span>{ar ? "وقت الانتظار بعد كلامك" : "Wait after you finish"}</span>
              <span className="text-brand">{(profile.silenceMs / 1000).toFixed(1)}s</span>
            </span>
            <input
              type="range"
              min={900}
              max={4500}
              step={100}
              value={profile.silenceMs}
              onChange={(e) => updateProfile({ silenceMs: Number(e.target.value) })}
              className="w-full accent-[var(--c-brand)]"
            />
          </label>
        </div>
      </div>

      <div className="mt-4 rounded-2xl border border-line bg-elev/45 p-4">
        <p className="flex items-center gap-2 text-xs font-bold text-fg">
          <Volume2 className="h-4 w-4 text-violet" aria-hidden />
          {ar ? "الصوت الطبيعي" : "Natural voice"}
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Field label={ar ? "الصوت الإنجليزي" : "English voice"}>
            <select
              className={inputCls}
              value={profile.voiceNameEn}
              onChange={(e) => updateProfile({ voiceNameEn: e.target.value })}
            >
              <option value="">{ar ? "أفضل صوت أنثوي تلقائي" : "Best automatic female voice"}</option>
              {enVoices.map((v) => (
                <option key={`${v.name}-${v.lang}`} value={v.name}>{v.name} · {v.lang}</option>
              ))}
            </select>
          </Field>
          <Field label={ar ? "الصوت العربي" : "Arabic voice"}>
            <select
              className={inputCls}
              value={profile.voiceNameAr}
              onChange={(e) => updateProfile({ voiceNameAr: e.target.value })}
            >
              <option value="">{ar ? "أفضل صوت أنثوي تلقائي" : "Best automatic female voice"}</option>
              {arVoices.map((v) => (
                <option key={`${v.name}-${v.lang}`} value={v.name}>{v.name} · {v.lang}</option>
              ))}
            </select>
          </Field>
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <label className="text-[11px] font-semibold text-fg2">
            <span className="mb-2 flex justify-between"><span>{ar ? "سرعة الكلام" : "Speaking rate"}</span><span>{profile.speakingRate.toFixed(2)}x</span></span>
            <input type="range" min={0.75} max={1.3} step={0.01} value={profile.speakingRate} onChange={(e) => updateProfile({ speakingRate: Number(e.target.value) })} className="w-full accent-[var(--c-violet)]" />
          </label>
          <label className="text-[11px] font-semibold text-fg2">
            <span className="mb-2 flex justify-between"><span>{ar ? "درجة الصوت" : "Voice pitch"}</span><span>{profile.pitch.toFixed(2)}</span></span>
            <input type="range" min={0.85} max={1.25} step={0.01} value={profile.pitch} onChange={(e) => updateProfile({ pitch: Number(e.target.value) })} className="w-full accent-[var(--c-violet)]" />
          </label>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-2.5">
        <button type="button" onClick={preview} className="inline-flex items-center gap-2 rounded-full border border-line bg-elev/70 px-5 py-2.5 text-xs font-bold text-fg transition-colors hover:border-violet/50">
          <Volume2 className="h-4 w-4 text-violet" aria-hidden /> {ar ? "جرّب الصوت" : "Preview voice"}
        </button>
        <button
          type="button"
          onClick={async () => {
            const ok = await enableNotifications();
            toast(ok ? (ar ? "تم تفعيل تنبيهات المواعيد" : "Schedule notifications enabled") : (ar ? "تعذر تفعيل التنبيهات" : "Notifications were not enabled"), ok ? "ok" : "warn");
          }}
          className="inline-flex items-center gap-2 rounded-full border border-line bg-elev/70 px-5 py-2.5 text-xs font-bold text-fg transition-colors hover:border-brand/50"
        >
          <BellRing className="h-4 w-4 text-brand" aria-hidden /> {ar ? "فعّل التنبيهات" : "Enable reminders"}
        </button>
        <button type="button" onClick={closePanels} className="ms-auto rounded-full bg-gradient-to-r from-brand to-brand-deep px-6 py-2.5 text-xs font-bold text-onbrand">
          <Check className="me-1 inline h-4 w-4" aria-hidden /> {ar ? "حفظ" : "Save"}
        </button>
      </div>
    </div>
  );
}

function ScheduleRow({ schedule }: { schedule: NeedSchedule }) {
  const { lang } = useLang();
  const ar = lang === "ar";
  const { db } = useStore();
  const { updateSchedule, removeSchedule } = useConcierge();
  const product = schedule.productId ? db.products.find((p) => p.id === schedule.productId) : undefined;
  return (
    <div className={cn("flex items-center gap-3 rounded-2xl border border-line bg-elev/45 p-3", !schedule.active && "opacity-50")}>
      {product ? (
        <div className="h-11 w-11 shrink-0 overflow-hidden rounded-xl">
          <ImgWithFallback src={product.img} alt={product.name} letter={product.name[0]} className="h-full w-full object-cover" />
        </div>
      ) : (
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand/10 text-brand"><AlarmClock className="h-5 w-5" /></span>
      )}
      <div className="min-w-0 flex-1">
        <p className="truncate text-xs font-bold text-fg">{schedule.title}</p>
        <p className="mt-0.5 text-[10px] text-fg3">
          {schedule.time} · {schedule.repeat === "daily" ? (ar ? "يوميًا" : "Daily") : schedule.repeat === "weekdays" ? (ar ? "أيام العمل" : "Weekdays") : (ar ? "مرة واحدة" : "Once")}
        </p>
      </div>
      <button type="button" onClick={() => updateSchedule(schedule.id, { active: !schedule.active })} className={cn("rounded-full border px-2.5 py-1 text-[10px] font-bold", schedule.active ? "border-brand/40 text-brand" : "border-line text-fg3")}>
        {schedule.active ? (ar ? "نشط" : "On") : (ar ? "متوقف" : "Off")}
      </button>
      <button type="button" onClick={() => removeSchedule(schedule.id)} className="grid h-8 w-8 place-items-center rounded-full border border-line text-fg3 transition-colors hover:border-rose-400/40 hover:text-rose-400" aria-label="Delete schedule">
        <Trash2 className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}

function PlannerPanel() {
  const { lang } = useLang();
  const ar = lang === "ar";
  const { db } = useStore();
  const { schedules, addSchedule, closePanels, enableNotifications } = useConcierge();
  const [title, setTitle] = useState("");
  const [time, setTime] = useState("09:00");
  const [repeat, setRepeat] = useState<ScheduleRepeat>("daily");
  const [productId, setProductId] = useState("");

  const add = () => {
    const product = db.products.find((p) => p.id === productId);
    const finalTitle = title.trim() || product?.name || (ar ? "احتياج يومي" : "Daily need");
    addSchedule({ title: finalTitle, time, repeat, productId: productId || undefined, vendorId: product?.vendorId, quantity: 1 });
    setTitle("");
  };

  return (
    <div className="p-6 sm:p-7">
      <div className="flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-brand to-accent text-onbrand"><CalendarClock className="h-5 w-5" /></span>
        <div>
          <h2 id="concierge-planner" className="font-display text-xl font-bold">{ar ? "جدول احتياجاتك" : "Your needs planner"}</h2>
          <p className="text-xs text-fg3">{ar ? "تذكير ذكي — ولا يتم الشراء دون تأكيدك" : "Smart reminders — nothing buys without your approval"}</p>
        </div>
      </div>

      <div className="mt-6 rounded-2xl border border-line bg-elev/45 p-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label={ar ? "عنوان الاحتياج" : "Need title"}>
            <input className={inputCls} value={title} onChange={(e) => setTitle(e.target.value)} placeholder={ar ? "مثال: طلب القهوة" : "e.g. Reorder coffee"} />
          </Field>
          <Field label={ar ? "المنتج (اختياري)" : "Product (optional)"}>
            <select className={inputCls} value={productId} onChange={(e) => setProductId(e.target.value)}>
              <option value="">{ar ? "بدون منتج محدد" : "No specific product"}</option>
              {db.products.filter((p) => !p.hidden).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </Field>
          <Field label={ar ? "الوقت" : "Time"}>
            <input type="time" className={inputCls} value={time} onChange={(e) => setTime(e.target.value)} />
          </Field>
          <Field label={ar ? "التكرار" : "Repeat"}>
            <select className={inputCls} value={repeat} onChange={(e) => setRepeat(e.target.value as ScheduleRepeat)}>
              <option value="daily">{ar ? "يوميًا" : "Daily"}</option>
              <option value="weekdays">{ar ? "أيام العمل" : "Weekdays"}</option>
              <option value="once">{ar ? "مرة واحدة" : "Once"}</option>
            </select>
          </Field>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <button type="button" onClick={add} className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand to-brand-deep px-5 py-2.5 text-xs font-bold text-onbrand">
            <Plus className="h-4 w-4" /> {ar ? "أضف للجدول" : "Add to schedule"}
          </button>
          <button type="button" onClick={() => void enableNotifications()} className="inline-flex items-center gap-2 rounded-full border border-line px-5 py-2.5 text-xs font-bold text-fg2 hover:text-fg">
            <BellRing className="h-4 w-4 text-brand" /> {ar ? "تنبيهات المتصفح" : "Browser alerts"}
          </button>
        </div>
      </div>

      <div className="mt-5 space-y-2">
        {schedules.length ? schedules.map((s) => <ScheduleRow key={s.id} schedule={s} />) : (
          <div className="rounded-2xl border border-dashed border-line2 py-9 text-center">
            <Clock3 className="mx-auto h-7 w-7 text-fg3/60" />
            <p className="mt-2 text-xs font-semibold text-fg2">{ar ? "لا توجد احتياجات مجدولة بعد" : "No scheduled needs yet"}</p>
          </div>
        )}
      </div>
      <button type="button" onClick={closePanels} className="mt-5 w-full rounded-full border border-line py-2.5 text-xs font-bold text-fg2 hover:text-fg">{ar ? "إغلاق" : "Close"}</button>
    </div>
  );
}

function ResultPanel() {
  const { lang } = useLang();
  const ar = lang === "ar";
  const { db, addToCart } = useStore();
  const { result, closeResult, openPlanner } = useConcierge();
  if (!result) return null;
  const Icon = RESULT_ICON[result.kind];

  return (
    <div className="p-6 sm:p-7">
      <div className="flex items-start gap-3 pe-9">
        <motion.span initial={{ scale: 0.6, rotate: -12 }} animate={{ scale: 1, rotate: 0 }} className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-brand to-accent text-onbrand shadow-lg">
          <Icon className="h-5 w-5" />
        </motion.span>
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-brand">{ar ? "نتيجة ذكية" : "Smart result"}</p>
          <h2 id="concierge-result" className="mt-1 font-display text-xl font-bold leading-tight">{result.title}</h2>
          {result.subtitle && <p className="mt-1 text-xs leading-relaxed text-fg2">{result.subtitle}</p>}
        </div>
      </div>

      <div className="mt-6 space-y-2.5">
        {result.items.map((item, i) => {
          const product = item.productId ? db.products.find((p) => p.id === item.productId) : undefined;
          const vendor = item.vendorId ? db.vendors.find((v) => v.id === item.vendorId) : undefined;
          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              className={cn("flex items-center gap-3 rounded-2xl border bg-elev/45 p-3", item.recommended ? "border-brand/55 shadow-[0_0_24px_-12px_color-mix(in_oklab,var(--c-brand)_70%,transparent)]" : "border-line")}
            >
              {item.image && <div className="h-14 w-14 shrink-0 overflow-hidden rounded-xl"><ImgWithFallback src={item.image} alt={item.label} letter={item.label[0]} className="h-full w-full object-cover" /></div>}
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-1.5 truncate text-xs font-bold text-fg">
                  {item.label}
                  {item.recommended && <span className="rounded-full bg-brand/10 px-2 py-0.5 text-[8px] uppercase tracking-wider text-brand">{ar ? "أفضل قيمة" : "Best value"}</span>}
                </p>
                {item.meta && <p className="mt-0.5 line-clamp-2 text-[10px] leading-relaxed text-fg3">{item.meta}</p>}
              </div>
              {item.value && <p className="shrink-0 text-xs font-bold text-brand">{item.value}</p>}
              {product && (
                <button type="button" onClick={() => addToCart(product.id)} className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-brand text-onbrand" aria-label="Add to cart"><Plus className="h-3.5 w-3.5" /></button>
              )}
              {vendor && (
                <button
                  type="button"
                  onClick={() => {
                    closeResult();
                    window.setTimeout(() => {
                      window.dispatchEvent(new CustomEvent("iroopa:open-vendor", { detail: vendor.id }));
                      window.setTimeout(
                        () => window.dispatchEvent(new CustomEvent("iroopa:vendor-tab", { detail: "map" })),
                        320
                      );
                    }, 180);
                  }}
                  className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-line text-brand"
                  aria-label="Open location"
                >
                  <MapPin className="h-3.5 w-3.5" />
                </button>
              )}
            </motion.div>
          );
        })}
      </div>

      {result.total !== undefined && (
        <div className="mt-5 flex items-center justify-between rounded-2xl border border-brand/30 bg-brand/[0.07] p-4">
          <span className="text-xs font-semibold text-fg2">{result.totalLabel ?? (ar ? "الإجمالي" : "Total")}</span>
          <span className="font-display text-xl font-bold text-brand">{fmtEGP(result.total)}</span>
        </div>
      )}
      {result.note && <p className="mt-3 rounded-xl border border-line bg-ink/40 p-3 text-[10px] leading-relaxed text-fg3">{result.note}</p>}

      <div className="mt-5 flex flex-wrap gap-2.5">
        {result.sourceUrl && (
          <a
            href={result.sourceUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full border border-line px-5 py-2.5 text-xs font-bold text-fg2 transition-colors hover:border-brand/50 hover:text-brand"
          >
            <ExternalLink className="h-4 w-4" /> {result.sourceLabel ?? (ar ? "المصدر" : "Source")}
          </a>
        )}
        {result.recommendedProductId && (
          <button type="button" onClick={() => addToCart(result.recommendedProductId!)} className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand to-brand-deep px-5 py-2.5 text-xs font-bold text-onbrand">
            <ShoppingCart className="h-4 w-4" /> {ar ? "أضف الأفضل للسلة" : "Add best value"}
          </button>
        )}
        <button type="button" onClick={openPlanner} className="inline-flex items-center gap-2 rounded-full border border-line px-5 py-2.5 text-xs font-bold text-fg2 hover:text-fg">
          <CalendarClock className="h-4 w-4 text-brand" /> {ar ? "جدولة" : "Schedule"}
        </button>
        <button type="button" onClick={closeResult} className="ms-auto rounded-full border border-line px-5 py-2.5 text-xs font-bold text-fg2 hover:text-fg">{ar ? "تم" : "Done"}</button>
      </div>
    </div>
  );
}

function WritingPanel() {
  const { lang } = useLang();
  const ar = lang === "ar";
  const { toast } = useStore();
  const {
    writing,
    updateWriting,
    closeWriter,
    openPlanner,
  } = useConcierge();
  const [displayed, setDisplayed] = useState("");
  const [generating, setGenerating] = useState(true);

  useEffect(() => {
    if (!writing) return;
    setDisplayed("");
    setGenerating(true);
    let i = 0;
    const chunk = Math.max(1, Math.ceil(writing.content.length / 130));
    const id = window.setInterval(() => {
      i = Math.min(writing.content.length, i + chunk);
      setDisplayed(writing.content.slice(0, i));
      if (i >= writing.content.length) {
        window.clearInterval(id);
        setGenerating(false);
      }
    }, 16);
    return () => window.clearInterval(id);
  }, [writing?.createdAt]);

  if (!writing) return null;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(writing.content);
      toast(ar ? "تم نسخ النص" : "Writing copied", "ok");
    } catch {
      toast(ar ? "تعذر النسخ تلقائيًا" : "Could not copy automatically", "warn");
    }
  };
  const download = () => {
    const blob = new Blob([writing.content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${writing.title.replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-|-$/g, "") || "roopa-writing"}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="relative overflow-hidden p-6 sm:p-7">
      {/* sparkle activity while writing appears */}
      {generating && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
          {Array.from({ length: 14 }, (_, i) => (
            <motion.span
              key={i}
              initial={{ opacity: 0, scale: 0.2, x: `${10 + (i * 37) % 80}%`, y: `${15 + (i * 29) % 70}%` }}
              animate={{ opacity: [0, 0.9, 0], scale: [0.2, 1.2, 0.3], y: [`${20 + (i * 29) % 65}%`, `${5 + (i * 17) % 45}%`] }}
              transition={{ duration: 1.15 + (i % 4) * 0.18, repeat: Infinity, delay: i * 0.07 }}
              className="absolute text-brand"
            >
              <Sparkles className="h-3 w-3" />
            </motion.span>
          ))}
        </div>
      )}

      <div className="relative flex items-center gap-3 pe-9">
        <motion.span
          animate={generating ? { rotate: [0, 12, -8, 0], scale: [1, 1.12, 1] } : { rotate: 0, scale: 1 }}
          transition={{ duration: 1, repeat: generating ? Infinity : 0 }}
          className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-brand via-accent to-violet text-onbrand shadow-lg"
        >
          <WandSparkles className="h-5 w-5" />
        </motion.span>
        <div className="min-w-0">
          <h2 id="concierge-writing" className="sr-only">
            {ar ? "مساحة الكتابة" : "Writing workspace"}
          </h2>
          <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.18em] text-brand">
            {generating ? (ar ? "تتم الكتابة الآن" : "Writing now") : (ar ? "جاهز للتعديل" : "Ready to edit")}
            {generating && <span className="voice-wave [transform:scale(.55)]"><span /><span /><span /><span /><span /></span>}
          </p>
          <input
            value={writing.title}
            onChange={(e) => updateWriting({ title: e.target.value })}
            className="mt-1 w-full bg-transparent font-display text-lg font-bold text-fg outline-none sm:text-xl"
            aria-label={ar ? "عنوان المستند" : "Document title"}
          />
        </div>
      </div>

      <div className="relative mt-5 rounded-2xl border border-line bg-ink/55 p-1 shadow-inner">
        <textarea
          value={generating ? displayed : writing.content}
          onChange={(e) => {
            setGenerating(false);
            setDisplayed(e.target.value);
            updateWriting({ content: e.target.value });
          }}
          className="min-h-[330px] w-full resize-y bg-transparent p-4 text-sm leading-7 text-fg outline-none"
          dir="auto"
          aria-label={ar ? "النص المكتوب" : "Generated writing"}
        />
        {generating && <span className="absolute bottom-5 end-5 h-5 w-0.5 animate-blink bg-brand" aria-hidden />}
      </div>

      <p className="mt-2 text-[10px] text-fg3">
        {ar ? "تمت الكتابة محليًا كمسودة قابلة للتعديل. راجع الأسماء والتفاصيل قبل الإرسال." : "Created locally as an editable draft. Review names and details before sending."}
      </p>
      <div className="mt-5 flex flex-wrap gap-2.5">
        <button type="button" onClick={copy} className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand to-brand-deep px-5 py-2.5 text-xs font-bold text-onbrand">
          <Clipboard className="h-4 w-4" /> {ar ? "نسخ" : "Copy"}
        </button>
        <button type="button" onClick={download} className="inline-flex items-center gap-2 rounded-full border border-line px-5 py-2.5 text-xs font-bold text-fg2 hover:text-fg">
          <Download className="h-4 w-4 text-brand" /> {ar ? "تنزيل" : "Download"}
        </button>
        <button type="button" onClick={openPlanner} className="inline-flex items-center gap-2 rounded-full border border-line px-5 py-2.5 text-xs font-bold text-fg2 hover:text-fg">
          <CalendarClock className="h-4 w-4 text-brand" /> {ar ? "جدولة متابعة" : "Schedule follow-up"}
        </button>
        <button type="button" onClick={closeWriter} className="ms-auto rounded-full border border-line px-5 py-2.5 text-xs font-bold text-fg2 hover:text-fg">
          {ar ? "تم" : "Done"}
        </button>
      </div>
    </div>
  );
}

export function ConciergeCenter() {
  const {
    settingsOpen,
    plannerOpen,
    result,
    writing,
    closePanels,
    closeResult,
    closeWriter,
  } = useConcierge();
  return (
    <>
      <Modal open={settingsOpen} onClose={closePanels} wide labelledBy="concierge-settings"><SettingsPanel /></Modal>
      <Modal open={plannerOpen} onClose={closePanels} labelledBy="concierge-planner"><PlannerPanel /></Modal>
      <Modal open={!!result} onClose={closeResult} wide labelledBy="concierge-result"><ResultPanel /></Modal>
      <Modal open={!!writing} onClose={closeWriter} wide labelledBy="concierge-writing"><WritingPanel /></Modal>
    </>
  );
}