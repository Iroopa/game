import { motion } from "framer-motion";
import { ArrowLeftRight, Languages, Sparkles } from "lucide-react";
import { useLang } from "../lib/i18n";
import { Eyebrow, Reveal } from "./Reveal";
import { cn } from "../utils/cn";

const DIALECTS = [
  "الخليجية · Gulf",
  "المصرية · Egyptian",
  "الشامية · Levantine",
  "المغربية · Maghrebi",
  "الفصحى · MSA",
  "English · US / UK",
];

const CHAT: { from: "user" | "roopa"; text: string; dir: "rtl" | "ltr" }[] = [
  { from: "user", text: "روبا، قارني لي تأمين السيارة وجددي الأرخص", dir: "rtl" },
  { from: "roopa", text: "قارنت ١٢ شركة. الأفضل قيمة: تغطية شاملة بـ ٨٦٠ دولارًا سنويًا. جددتها لك.", dir: "rtl" },
  { from: "user", text: "Perfect. And email me the policy in English please.", dir: "ltr" },
  { from: "roopa", text: "Done — policy sent to your inbox. Anything else in Arabic or English?", dir: "ltr" },
];

export function Bilingual() {
  const { t, lang, setLang } = useLang();

  return (
    <section id="languages" className="relative overflow-hidden py-24 sm:py-32">
      <div
        aria-hidden
        className="aurora-blob start-[35%] top-[-10%] h-[400px] w-[400px] opacity-[0.13]"
        style={{ background: "var(--c-accent)" }}
      />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          {/* copy */}
          <div className="order-2 lg:order-1">
            <Reveal>
              <Eyebrow>{t("bi.eyebrow")}</Eyebrow>
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-5 font-display text-4xl font-bold leading-[1.08] tracking-[-0.02em] sm:text-5xl">
                {t("bi.title")} <span className="text-gradient">{t("bi.title.b")}</span>
              </h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mt-4 max-w-lg text-base leading-relaxed text-fg2 sm:text-lg">
                {t("bi.sub")}
              </p>
            </Reveal>

            <Reveal delay={0.22}>
              <div className="mt-8">
                <p className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-fg3">
                  <ArrowLeftRight className="h-3.5 w-3.5 text-brand" aria-hidden />
                  {t("bi.try")}
                </p>
                <div className="inline-flex rounded-full border border-line bg-elev/70 p-1">
                  {(
                    [
                      ["ar", "العربية · RTL"],
                      ["en", "English · LTR"],
                    ] as const
                  ).map(([code, label]) => (
                    <button
                      key={code}
                      type="button"
                      onClick={() => setLang(code)}
                      className={cn(
                        "relative rounded-full px-5 py-2 text-sm font-semibold transition-colors duration-300",
                        lang === code ? "text-onbrand" : "text-fg2 hover:text-fg"
                      )}
                    >
                      {lang === code && (
                        <motion.span
                          layoutId="lang-pill"
                          className="absolute inset-0 rounded-full bg-gradient-to-r from-brand to-brand-deep"
                          transition={{ type: "spring", stiffness: 380, damping: 32 }}
                        />
                      )}
                      <span className="relative">{label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </Reveal>

            <Reveal delay={0.3}>
              <p className="mt-9 mb-3 text-xs font-semibold uppercase tracking-widest text-fg3">
                {t("bi.dialects")}
              </p>
              <div className="flex max-w-md flex-wrap gap-2">
                {DIALECTS.map((d) => (
                  <span
                    key={d}
                    className="rounded-full border border-line bg-elev/60 px-3 py-1.5 text-[11px] font-medium text-fg2 transition-colors duration-300 hover:border-brand/40 hover:text-fg"
                  >
                    {d}
                  </span>
                ))}
              </div>
            </Reveal>
          </div>

          {/* chat card */}
          <div className="order-1 lg:order-2">
            <Reveal delay={0.12}>
              <div className="card-surface noise relative overflow-hidden rounded-[26px] p-5 sm:p-7">
                <div className="mb-5 flex items-center gap-3 border-b border-line pb-4">
                  <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand to-accent">
                    <Languages className="h-4.5 w-4.5 text-onbrand" aria-hidden />
                  </span>
                  <div>
                    <p className="text-sm font-bold">Roopa · iRoopa</p>
                    <p className="text-[11px] text-fg3">Auto-detect · العربية / English</p>
                  </div>
                  <Sparkles className="ms-auto h-4 w-4 text-gold" aria-hidden />
                </div>
                <div className="space-y-3">
                  {CHAT.map((m, i) => (
                    <Reveal key={i} delay={0.12 + 0.14 * i} y={18}>
                      <div
                        className={cn(
                          "flex",
                          m.from === "user" ? "justify-start" : "justify-end"
                        )}
                      >
                        <div
                          dir={m.dir}
                          className={cn(
                            "max-w-[82%] rounded-2xl px-4 py-3 text-sm font-medium leading-relaxed",
                            m.from === "user"
                              ? "rounded-es-md border border-line bg-elev text-fg"
                              : "rounded-ee-md border border-brand/30 bg-gradient-to-br from-brand/[0.14] to-transparent text-fg"
                          )}
                        >
                          {m.from === "roopa" && (
                            <p className="mb-1 flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-widest text-brand">
                              Roopa
                              <span className="voice-wave [transform:scale(0.55)]" aria-hidden>
                                <span /><span /><span /><span /><span />
                              </span>
                            </p>
                          )}
                          {m.text}
                        </div>
                      </div>
                    </Reveal>
                  ))}
                </div>
                <div className="mt-5 flex items-center gap-2 rounded-full border border-line bg-ink/60 px-4 py-3">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-brand" aria-hidden />
                  <p className="text-xs text-fg3" dir="auto">
                    {t("asst.listening")}
                  </p>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
