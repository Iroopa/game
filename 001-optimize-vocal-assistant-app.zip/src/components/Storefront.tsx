import { useEffect, useMemo, useRef, useState } from "react";
import {
  ImagePlus,
  Minus,
  PackageSearch,
  Pencil,
  Plus,
  Search,
  ShoppingBag,
  ShoppingCart,
  Trash2,
  Upload,
} from "lucide-react";
import {
  fmtEGP,
  sectorLabel,
  slugify,
  useStore,
  type Product,
} from "../lib/store";
import { SECTOR_AR, SUB_AR, useLang } from "../lib/i18n";
import {
  Field,
  ImgWithFallback,
  Modal,
  TwoStepDelete,
  inputCls,
  readFileAsDataURL,
} from "./ui";
import { Eyebrow, Reveal } from "./Reveal";
import { cn } from "../utils/cn";

/* ------------------------------ product dialog ---------------------------- */

export function ProductDialog({
  open,
  onClose,
  product,
}: {
  open: boolean;
  onClose: () => void;
  product: Product | null;
}) {
  const { db, upsertProduct, removeProduct } = useStore();
  const [draft, setDraft] = useState<Product | null>(product);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    setDraft(
      product ?? {
        id: `p-custom-${Date.now()}`,
        vendorId: db.vendors[0]?.id ?? "",
        sectorKey: db.vendors[0]?.sector ?? "ecommerce",
        catId: db.categories[0]?.id ?? "",
        subId: db.subcategories[0]?.id ?? "",
        name: "",
        desc: "",
        price: 999,
        sale: null,
        img: "",
        hidden: false,
      }
    );
  }, [open, product, db.vendors, db.categories, db.subcategories]);

  if (!draft) return null;
  const subs = db.subcategories.filter((s) => s.catId === draft.catId);

  return (
    <Modal open={open} onClose={onClose} wide labelledBy="product-editor">
      <div className="p-6">
        <p id="product-editor" className="font-display text-lg font-bold">
          {product ? "Edit product" : "New product"}
        </p>
        <p className="mt-0.5 text-xs text-fg3">Changes save instantly to your local storefront.</p>

        <div className="mt-5 grid gap-4 sm:grid-cols-[200px_1fr]">
          {/* image */}
          <div>
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="group relative block aspect-[4/3] w-full overflow-hidden rounded-2xl border border-dashed border-line2 bg-ink/50"
            >
              {draft.img ? (
                <ImgWithFallback src={draft.img} alt={draft.name || "product"} letter="P" className="h-full w-full object-cover" />
              ) : (
                <span className="grid h-full place-items-center text-fg3">
                  <span className="flex flex-col items-center gap-1.5">
                    <ImagePlus className="h-6 w-6" aria-hidden />
                    <span className="text-[10px] font-bold uppercase tracking-widest">Upload image</span>
                  </span>
                </span>
              )}
              <span className="absolute inset-0 grid place-items-center bg-black/45 opacity-0 transition-opacity group-hover:opacity-100">
                <Upload className="h-5 w-5 text-white" aria-hidden />
              </span>
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (f) setDraft({ ...draft, img: await readFileAsDataURL(f) });
                e.target.value = "";
              }}
            />
            <input
              className={cn(inputCls, "mt-2 text-xs")}
              placeholder="…or paste image URL"
              value={draft.img.startsWith("data:") ? "" : draft.img}
              onChange={(e) => setDraft({ ...draft, img: e.target.value })}
            />
          </div>

          {/* fields */}
          <div className="grid gap-3">
            <Field label="Name">
              <input className={inputCls} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="Product name" />
            </Field>
            <Field label="Description">
              <textarea className={cn(inputCls, "min-h-[70px] resize-y")} value={draft.desc} onChange={(e) => setDraft({ ...draft, desc: e.target.value })} placeholder="Short sales description" />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Price (EGP)">
                <input type="number" min={0} className={inputCls} value={draft.price} onChange={(e) => setDraft({ ...draft, price: Number(e.target.value) || 0 })} />
              </Field>
              <Field label="Sale price (optional)">
                <input type="number" min={0} className={inputCls} value={draft.sale ?? ""} onChange={(e) => setDraft({ ...draft, sale: e.target.value === "" ? null : Number(e.target.value) || 0 })} placeholder="—" />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Vendor">
                <select className={inputCls} value={draft.vendorId} onChange={(e) => {
                  const v = db.vendors.find((x) => x.id === e.target.value);
                  setDraft({ ...draft, vendorId: e.target.value, sectorKey: v?.sector ?? draft.sectorKey });
                }}>
                  {db.vendors.map((v) => (
                    <option key={v.id} value={v.id}>{v.name}</option>
                  ))}
                </select>
              </Field>
              <Field label="Category">
                <select className={inputCls} value={draft.catId} onChange={(e) => {
                  const catId = e.target.value;
                  const firstSub = db.subcategories.find((s) => s.catId === catId);
                  setDraft({ ...draft, catId, subId: firstSub?.id ?? "" });
                }}>
                  {db.categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </Field>
            </div>
            <Field label="Subcategory">
              <select className={inputCls} value={draft.subId} onChange={(e) => setDraft({ ...draft, subId: e.target.value })}>
                {subs.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </Field>
          </div>
        </div>

        <div className="mt-6 flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => {
              if (!draft.name.trim()) return;
              upsertProduct({ ...draft, name: draft.name.trim(), desc: draft.desc || `Verified offering — ${slugify(draft.name)}` });
              onClose();
            }}
            disabled={!draft.name.trim()}
            className="rounded-full bg-gradient-to-r from-brand to-brand-deep px-6 py-2.5 text-sm font-bold text-onbrand transition-all hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Save product
          </button>
          {product && (
            <TwoStepDelete
              onConfirm={() => {
                removeProduct(draft.id);
                onClose();
              }}
            />
          )}
          <button type="button" onClick={onClose} className="ms-auto rounded-full border border-line px-5 py-2.5 text-sm font-semibold text-fg2 transition-colors hover:text-fg">
            Cancel
          </button>
        </div>
      </div>
    </Modal>
  );
}

/* -------------------------------- cart modal ------------------------------ */

function CartModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { db, cart, setQty, clearCart, cartTotal, toast } = useStore();
  const { t } = useLang();
  const lines = cart
    .map((ci) => ({ ci, p: db.products.find((x) => x.id === ci.productId) }))
    .filter((x) => x.p);

  return (
    <Modal open={open} onClose={onClose} labelledBy="cart-title">
      <div className="p-6">
        <p id="cart-title" className="font-display text-lg font-bold">{t("shop.yourcart")}</p>
        {lines.length === 0 ? (
          <div className="py-10 text-center">
            <ShoppingBag className="mx-auto h-10 w-10 text-fg3/50" aria-hidden />
            <p className="mt-3 text-sm font-semibold text-fg2">{t("shop.empty")}</p>
            <p className="mt-1 text-xs text-fg3">{t("shop.empty.sub")}</p>
          </div>
        ) : (
          <>
            <ul className="mt-5 max-h-[46dvh] space-y-3 overflow-y-auto pe-1">
              {lines.map(({ ci, p }) => {
                const prod = p!;
                return (
                  <li key={ci.productId} className="flex items-center gap-3 rounded-2xl border border-line bg-elev/50 p-2.5">
                    <div className="h-12 w-12 overflow-hidden rounded-xl">
                      <ImgWithFallback src={prod.img} alt={prod.name} letter={prod.name[0]} className="h-full w-full object-cover" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-bold text-fg">{prod.name}</p>
                      <p className="text-[11px] font-semibold text-brand">{fmtEGP(prod.sale ?? prod.price)}</p>
                    </div>
                    <div className="flex items-center gap-1 rounded-full border border-line bg-ink/50 px-1 py-0.5">
                      <button type="button" className="grid h-6 w-6 place-items-center rounded-full text-fg2 hover:text-fg" onClick={() => setQty(ci.productId, ci.qty - 1)} aria-label="Decrease quantity">
                        <Minus className="h-3 w-3" />
                      </button>
                      <span className="w-5 text-center text-xs font-bold tabular-nums">{ci.qty}</span>
                      <button type="button" className="grid h-6 w-6 place-items-center rounded-full text-fg2 hover:text-fg" onClick={() => setQty(ci.productId, ci.qty + 1)} aria-label="Increase quantity">
                        <Plus className="h-3 w-3" />
                      </button>
                    </div>
                    <button type="button" className="text-fg3 transition-colors hover:text-rose-400" onClick={() => setQty(ci.productId, 0)} aria-label="Remove from cart">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </li>
                );
              })}
            </ul>
            <div className="mt-5 flex items-center justify-between border-t border-line pt-4">
              <p className="text-xs text-fg3">{t("shop.total")}</p>
              <p className="font-display text-xl font-bold text-brand">{fmtEGP(cartTotal)}</p>
            </div>
            <button
              type="button"
              onClick={() => {
                clearCart();
                onClose();
                toast(t("shop.ordered"), "ok");
              }}
              className="mt-4 w-full rounded-full bg-gradient-to-r from-brand to-brand-deep py-3 text-sm font-bold text-onbrand transition-all hover:brightness-110 active:scale-[0.98]"
            >
              {t("shop.checkout")}
            </button>
          </>
        )}
      </div>
    </Modal>
  );
}

/* ------------------------------- the section ------------------------------ */

export function StorefrontSection() {
  const { db, addToCart, cartCount } = useStore();
  const { t, lang } = useLang();
  const [cat, setCat] = useState<string>("all");
  const [sub, setSub] = useState<string>("all");
  const [q, setQ] = useState("");
  const [shown, setShown] = useState(12);
  const [editing, setEditing] = useState<Product | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);

  /* deep-links from the categories section */
  useEffect(() => {
    const handler = (e: Event) => {
      const d = (e as CustomEvent).detail as { catId?: string; subId?: string };
      if (d?.catId) {
        setCat(d.catId);
        setSub(d.subId ?? "all");
        setShown(12);
      }
    };
    const openCart = () => setCartOpen(true);
    window.addEventListener("iroopa:shop-filter", handler);
    window.addEventListener("iroopa:open-cart", openCart);
    return () => {
      window.removeEventListener("iroopa:shop-filter", handler);
      window.removeEventListener("iroopa:open-cart", openCart);
    };
  }, []);

  const cats = db.categories.filter((c) => !c.hidden);
  const subs = db.subcategories.filter((s) => s.catId === cat && !s.hidden);

  const products = useMemo(() => {
    let list = db.products.filter((p) => !p.hidden);
    if (cat !== "all") list = list.filter((p) => p.catId === cat);
    if (sub !== "all") list = list.filter((p) => p.subId === sub);
    const query = q.trim().toLowerCase();
    if (query) list = list.filter((p) => p.name.toLowerCase().includes(query) || p.desc.toLowerCase().includes(query));
    return list;
  }, [db.products, cat, sub, q]);

  const openEdit = (p: Product | null) => {
    setEditing(p);
    setDialogOpen(true);
  };

  return (
    <section id="shop" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-xl">
            <Reveal>
              <Eyebrow>{t("shop.eyebrow")}</Eyebrow>
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-5 font-display text-4xl font-bold leading-[1.08] tracking-[-0.02em] sm:text-5xl">
                {t("shop.title.a")} <span className="text-gradient">{t("shop.title.b")}</span>
              </h2>
            </Reveal>
            <Reveal delay={0.14}>
              <p className="mt-4 inline-flex flex-wrap items-center gap-1.5 text-base leading-relaxed text-fg2">
                <Pencil className="h-3.5 w-3.5 text-brand" aria-hidden /> {t("shop.sub")}
              </p>
            </Reveal>
          </div>
          <Reveal delay={0.18} className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => openEdit(null)}
              className="inline-flex items-center gap-2 rounded-full border border-line bg-elev/70 px-5 py-2.5 text-xs font-bold text-fg transition-colors hover:border-brand/50"
            >
              <Plus className="h-4 w-4 text-brand" aria-hidden /> {t("shop.new")}
            </button>
            <button
              type="button"
              onClick={() => setCartOpen(true)}
              className="relative inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand to-brand-deep px-5 py-2.5 text-xs font-bold text-onbrand transition-all hover:brightness-110"
            >
              <ShoppingCart className="h-4 w-4" aria-hidden /> {t("shop.cart")}
              {cartCount > 0 && (
                <span className="absolute -end-1.5 -top-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-gold px-1 text-[10px] font-bold text-[#241500]">
                  {cartCount}
                </span>
              )}
            </button>
          </Reveal>
        </div>

        {/* filters */}
        <Reveal delay={0.2}>
          <div className="relative -mx-4 mt-9 px-4">
            <div className="absolute end-4 top-0 z-10 h-full w-14 bg-gradient-to-l from-[var(--c-ink)] to-transparent pointer-events-none" aria-hidden />
            <div className="no-scrollbar flex flex-nowrap items-center gap-2 overflow-x-auto pb-1">
              <div className="relative shrink-0">
                <Search className="absolute start-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-fg3" aria-hidden />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder={t("shop.search")}
                  className={cn(inputCls, "w-48 rounded-full ps-9 text-xs")}
                />
              </div>
            <button
              type="button"
              onClick={() => { setCat("all"); setSub("all"); }}
              className={cn("shrink-0 rounded-full border px-4 py-2 text-xs font-bold transition-all", cat === "all" ? "border-transparent bg-gradient-to-r from-brand to-brand-deep text-onbrand" : "border-line bg-elev/60 text-fg2 hover:text-fg")}
            >
              {t("shop.all")}
            </button>
            {cats.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => { setCat(c.id); setSub("all"); }}
                className={cn("shrink-0 rounded-full border px-4 py-2 text-xs font-bold transition-all", cat === c.id ? "border-transparent bg-gradient-to-r from-brand to-brand-deep text-onbrand" : "border-line bg-elev/60 text-fg2 hover:text-fg")}
              >
                {lang === "ar" ? SECTOR_AR[c.slug] ?? c.name : c.name}
              </button>
            ))}
            </div>
          </div>
        </Reveal>
        {cat !== "all" && subs.length > 0 && (
          <div className="mt-2.5 flex flex-wrap gap-2">
            <button type="button" onClick={() => setSub("all")} className={cn("rounded-full border px-3 py-1.5 text-[11px] font-semibold transition-all", sub === "all" ? "border-brand/50 text-brand" : "border-line text-fg3 hover:text-fg")}>
              {t("shop.everything")}
            </button>
            {subs.map((s) => (
              <button key={s.id} type="button" onClick={() => setSub(s.id)} className={cn("rounded-full border px-3 py-1.5 text-[11px] font-semibold transition-all", sub === s.id ? "border-brand/50 text-brand" : "border-line text-fg3 hover:text-fg")}>
                {lang === "ar" ? SUB_AR[s.name] ?? s.name : s.name}
              </button>
            ))}
          </div>
        )}

        {/* grid */}
        {products.length === 0 ? (
          <div className="mt-16 text-center">
            <PackageSearch className="mx-auto h-10 w-10 text-fg3/50" aria-hidden />
            <p className="mt-3 text-sm font-semibold text-fg2">{t("shop.none")}</p>
            <p className="mt-1 text-xs text-fg3">{t("shop.none.sub")}</p>
          </div>
        ) : (
          <>
            <div className="mt-8 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3 xl:grid-cols-4">
              {products.slice(0, shown).map((p, i) => {
                const vendor = db.vendors.find((v) => v.id === p.vendorId);
                const off = p.sale ? Math.round((1 - p.sale / p.price) * 100) : 0;
                return (
                  <Reveal key={p.id} delay={0.03 * (i % 4)} className="h-full">
                    <article className="card-surface card-spotlight group flex h-full flex-col overflow-hidden rounded-3xl transition-transform duration-500 hover:-translate-y-1">
                      <div className="relative aspect-[4/3] overflow-hidden">
                        <ImgWithFallback src={p.img} alt={p.name} letter={p.name[0]} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                        {off > 0 && (
                          <span className="absolute start-3 top-3 rounded-full bg-rose-500 px-2 py-0.5 text-[9px] font-bold text-white">-{off}%</span>
                        )}
                        <button
                          type="button"
                          onClick={() => openEdit(p)}
                          aria-label={`Edit ${p.name}`}
                          className="absolute end-3 top-3 grid h-8 w-8 place-items-center rounded-full border border-white/20 bg-black/45 text-white opacity-0 backdrop-blur-sm transition-all hover:bg-black/70 group-hover:opacity-100"
                        >
                          <Pencil className="h-3.5 w-3.5" aria-hidden />
                        </button>
                      </div>
                      <div className="flex flex-1 flex-col p-4">
                        <p className="truncate text-sm font-bold text-fg">{p.name}</p>
                        <p className="mt-0.5 truncate text-[11px] text-fg3">
                          <span dir="ltr">{vendor?.name ?? "—"}</span> ·{" "}
                          {lang === "ar" ? SECTOR_AR[p.sectorKey] : sectorLabel(p.sectorKey)}
                        </p>
                        <div className="mt-2 flex items-center justify-between gap-2">
                          <p className="flex items-baseline gap-2">
                            <span className="text-base font-bold text-brand">{fmtEGP(p.sale ?? p.price)}</span>
                            {p.sale && <span className="text-[11px] text-fg3 line-through">{fmtEGP(p.price)}</span>}
                          </p>
                          {p.provenance?.sourceLabel ? (
                            <span
                              className="inline-flex shrink-0 items-center gap-1 rounded-full border border-brand/30 bg-brand/10 px-2 py-0.5 text-[9px] font-bold text-brand"
                              title={`${p.provenance.sourceLabel}${p.provenance.checkedAt ? ` · ${p.provenance.checkedAt}` : ""}`}
                            >
                              {t("v.audited.price")}
                            </span>
                          ) : (
                            <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-dashed border-line px-2 py-0.5 text-[9px] font-bold text-fg3" title={t("v.price.unverified")}>
                              {t("v.contact.na")}
                            </span>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => addToCart(p.id)}
                          className="mt-3 inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-brand to-brand-deep px-3 py-2 text-xs font-bold text-onbrand transition-all hover:brightness-110 active:scale-[0.97]"
                        >
                          <ShoppingCart className="h-3.5 w-3.5" aria-hidden /> {t("shop.addcart")}
                        </button>
                      </div>
                    </article>
                  </Reveal>
                );
              })}
            </div>
            {shown < products.length && (
              <div className="mt-10 text-center">
                <button
                  type="button"
                  onClick={() => setShown((s) => s + 12)}
                  className="rounded-full border border-line bg-elev/70 px-8 py-3 text-sm font-bold text-fg transition-colors hover:border-brand/50"
                >
                  {t("shop.showmore")} ({products.length - shown})
                </button>
              </div>
            )}
          </>
        )}
      </div>

      <ProductDialog open={dialogOpen} onClose={() => setDialogOpen(false)} product={editing} />
      <CartModal open={cartOpen} onClose={() => setCartOpen(false)} />
    </section>
  );
}
