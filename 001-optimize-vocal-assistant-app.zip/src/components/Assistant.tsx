import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  CalendarClock,
  Calculator,
  FlaskConical,
  Infinity as InfinityIcon,
  Keyboard,
  Mic,
  Radio,
  Scale,
  Send,
  Settings2,
  Square,
} from "lucide-react";
import { useLang, type DictKey } from "../lib/i18n";
import { useSpeechEngine, type AsstState } from "../lib/speech";
import { useStore, type Vendor } from "../lib/store";
import { useConcierge } from "../lib/concierge";
import { resolveVoice, type VoiceDeps } from "../lib/voice-actions";
import { askWorldKnowledge, looksLikeKnowledgeQuestion } from "../lib/knowledge";
import { highlightTarget } from "./Spotlighter";
import { VoiceOrb } from "./VoiceOrb";
import { RoopaFace } from "./RoopaFace";
import { cn } from "../utils/cn";

const STATUS_KEY: Record<AsstState, DictKey> = {
  idle: "asst.idle",
  listening: "asst.listening",
  processing: "asst.processing",
  speaking: "asst.speaking",
};

const CHIPS: DictKey[] = ["asst.chip.0", "asst.chip.1", "asst.chip.2", "asst.chip.3"];

function Monogram() {
  return (
    <span className="relative grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand to-accent shadow-[0_8px_24px_-6px_color-mix(in_oklab,var(--c-brand)_60%,transparent)]">
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" aria-hidden>
        <g fill="var(--c-onbrand)">
          <rect x="3.5" y="9" width="3" height="6" rx="1.5" />
          <rect x="8.5" y="5.5" width="3" height="13" rx="1.5" />
          <rect x="13.5" y="8" width="3" height="8" rx="1.5" />
          <rect x="18" y="4" width="3" height="16" rx="1.5" transform="translate(-0.5)" />
        </g>
      </svg>
      <span className="absolute -bottom-0.5 -end-0.5 h-3 w-3 rounded-full border-2 border-panel bg-brand" />
    </span>
  );
}

export function Assistant() {
  const { t, lang } = useLang();
  const { db, addToCart, cart, cartTotal, toast } = useStore();
  const {
    profile,
    updateProfile,
    addSchedule,
    showResult,
    openSettings,
    openPlanner,
    openWriter,
  } = useConcierge();
  const [textOpen, setTextOpen] = useState(false);
  const [typed, setTyped] = useState("");

  /* live catalogue brain — knows every vendor, category and product */
  const resolve = useCallback(
    async (text: string, l: typeof lang) => {
      const deps: VoiceDeps = {
        db,
        cart,
        cartTotal,
        profile,
        addToCart,
        openVendor: (v: Vendor) =>
          window.dispatchEvent(new CustomEvent("iroopa:open-vendor", { detail: v.id })),
        filterShop: (catId: string, subId?: string) => {
          window.dispatchEvent(new CustomEvent("iroopa:shop-filter", { detail: { catId, subId } }));
          document.getElementById("shop")?.scrollIntoView({ behavior: "smooth", block: "start" });
        },
        highlight: (sel, label, kind) => highlightTarget(sel, label, kind),
        goto: (hash: string) => {
          window.location.hash = hash;
        },
        showResult,
        addSchedule,
        updateProfile,
        openPlanner,
        openWriter,
      };
      const local = resolveVoice(text, l, deps);
      if (local) return local;

      if (looksLikeKnowledgeQuestion(text)) {
        const controller = new AbortController();
        const timeout = window.setTimeout(() => controller.abort(), 8500);
        const knowledge = await askWorldKnowledge(text, l, controller.signal);
        window.clearTimeout(timeout);
        if (knowledge) {
          return {
            reply: knowledge.answer,
            action: () => showResult({
              kind: "answer",
              title: knowledge.title,
              subtitle: knowledge.answer,
              items: knowledge.image
                ? [{ id: "source", label: knowledge.sourceLabel, image: knowledge.image }]
                : [],
              note:
                l === "ar"
                  ? "إجابة معلوماتية بمصدر خارجي. في القرارات الطبية أو القانونية أو المالية، راجع مختصًا."
                  : "Sourced informational answer. For medical, legal or financial decisions, consult a qualified professional.",
              sourceUrl: knowledge.sourceUrl,
              sourceLabel: knowledge.sourceLabel,
            }),
          };
        }
      }
      return null;
    },
    [
      db,
      cart,
      cartTotal,
      profile,
      addToCart,
      showResult,
      addSchedule,
      updateProfile,
      openPlanner,
      openWriter,
    ]
  );

  const {
    state,
    transcript,
    reply,
    typing,
    simulation,
    levelRef,
    toggleMic,
    runCommand,
  } = useSpeechEngine({
    lang,
    resolve,
    silenceMs: profile.silenceMs,
    sensitivity: profile.sensitivity,
    speakingRate: profile.speakingRate,
    pitch: profile.pitch,
    voiceNameEn: profile.voiceNameEn,
    voiceNameAr: profile.voiceNameAr,
  });

  /* external "talk" requests (mobile dock, hero CTA) */
  useEffect(() => {
    const onTalk = () => {
      if (state === "idle") toggleMic();
    };
    const onText = () => setTextOpen(true);
    window.addEventListener("iroopa:talk", onTalk);
    window.addEventListener("iroopa:text-mode", onText);
    return () => {
      window.removeEventListener("iroopa:talk", onTalk);
      window.removeEventListener("iroopa:text-mode", onText);
    };
  }, [state, toggleMic]);

  /* surface mic / network problems as highlighted notifications */
  useEffect(() => {
    const onErr = (e: Event) => {
      toast(String((e as CustomEvent).detail), "err");
      highlightTarget("#demo", lang === "ar" ? "تحقق من الميكروفون" : "Check your microphone", "warn");
    };
    window.addEventListener("iroopa:voice-error", onErr);
    return () => window.removeEventListener("iroopa:voice-error", onErr);
  }, [toast, lang]);

  const active = state !== "idle";

  return (
    <div
      id="demo"
      className="card-surface noise relative w-full overflow-hidden rounded-[26px] p-5 shadow-[0_40px_80px_-40px_rgba(0,0,0,0.7)] sm:p-6"
    >
      {/* ambient inner glow */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-32 start-1/2 h-64 w-[130%] -translate-x-1/2 rounded-full opacity-25 blur-3xl"
        style={{ background: "radial-gradient(closest-side, var(--c-brand), transparent)" }}
      />

      {/* header */}
      <div className="relative flex items-center gap-3">
        <Monogram />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold tracking-wide text-fg">{profile.assistantName || t("asst.name")}</p>
          <p className="truncate text-xs text-fg2">
            {state === "idle" ? t("asst.status.online") : t(STATUS_KEY[state])}
          </p>
        </div>
        <button
          type="button"
          onClick={openPlanner}
          aria-label={lang === "ar" ? "جدول الاحتياجات" : "Needs planner"}
          className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-line bg-elev/70 text-fg3 transition-all hover:border-brand/50 hover:text-brand"
        >
          <CalendarClock className="h-3.5 w-3.5" aria-hidden />
        </button>
        <button
          type="button"
          onClick={openSettings}
          aria-label={lang === "ar" ? "إعدادات المساعدة" : "Assistant settings"}
          className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-line bg-elev/70 text-fg3 transition-all hover:border-brand/50 hover:text-brand"
        >
          <Settings2 className="h-3.5 w-3.5" aria-hidden />
        </button>
        <span
          className={cn(
            "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider",
            simulation
              ? "border-gold/40 bg-gold/10 text-gold"
              : "border-brand/40 bg-brand/10 text-brand"
          )}
        >
          {simulation ? (
            <FlaskConical className="h-3 w-3" aria-hidden />
          ) : (
            <Radio className="h-3 w-3" aria-hidden />
          )}
          {simulation ? t("asst.sim") : t("asst.live")}
        </span>
      </div>

      {/* orb + Roopa character */}
      <div className="relative mx-auto mt-2 grid h-[218px] place-items-center">
        <VoiceOrb levelRef={levelRef} state={state} size={210} />
        {state === "processing" && (
          <div className="pointer-events-none absolute inset-0 grid place-items-center">
            <div className="h-24 w-24 animate-spin rounded-full border border-dashed border-gold/50 [animation-duration:5s]" />
          </div>
        )}
        {/* animated female character, orbiting the circle */}
        <motion.div
          initial={{ opacity: 0, scale: 0.7, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: [0, -7, 0] }}
          transition={{
            opacity: { duration: 0.6 },
            scale: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
            y: { duration: 4.2, repeat: Infinity, ease: "easeInOut" },
          }}
          className="pointer-events-none absolute -bottom-1 end-0 sm:end-2"
        >
          <RoopaFace levelRef={levelRef} state={state} size={80} />
        </motion.div>
      </div>

      {/* conversation */}
      <div className="relative min-h-[104px] space-y-2.5">
        {transcript && (
          <motion.div
            layout
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl rounded-ee-md border border-line bg-elev/80 p-3"
          >
            <p className="text-[10px] font-bold uppercase tracking-widest text-fg3">
              {profile.userName && profile.userName.toLowerCase() !== "friend"
                ? profile.userName
                : t("asst.you")}
            </p>
            <p dir="auto" className="mt-0.5 text-sm font-medium leading-relaxed text-fg">
              {transcript}
            </p>
          </motion.div>
        )}
        {reply && (
          <motion.div
            layout
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl rounded-es-md border border-brand/25 bg-gradient-to-b from-brand/[0.09] to-transparent p-3"
          >
            <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-brand">
              {profile.assistantName || t("asst.name")}
              {(state === "speaking" || typing) && (
                <span className="voice-wave" aria-hidden>
                  <span /><span /><span /><span /><span />
                </span>
              )}
            </p>
            <p dir="auto" className="mt-0.5 text-sm font-medium leading-relaxed text-fg">
              {reply}
              {typing && (
                <span className="ms-0.5 inline-block h-3.5 w-[2px] animate-blink bg-brand align-[-2px]" />
              )}
            </p>
          </motion.div>
        )}
        {!transcript && !reply && (
          <p className="absolute inset-x-0 top-0 text-center text-xs leading-relaxed text-fg3">
            {t("asst.idle")}
          </p>
        )}
      </div>

      {/* chips */}
      <div className="mt-3 flex flex-wrap justify-center gap-2">
        {CHIPS.map((chip) => (
          <button
            key={chip}
            type="button"
            onClick={() => runCommand(t(chip))}
            disabled={active}
            className="rounded-full border border-line bg-elev/70 px-3 py-1.5 text-[11px] font-medium text-fg2 transition-all duration-300 hover:border-brand/50 hover:text-fg disabled:cursor-not-allowed disabled:opacity-40"
          >
            {t(chip)}
          </button>
        ))}
      </div>

      {/* smart shortcuts */}
      <div className="mt-2 flex flex-wrap justify-center gap-2">
        <button
          type="button"
          onClick={() => runCommand(lang === "ar" ? "قارن أفضل العروض" : "Compare the best offers")}
          disabled={active}
          className="inline-flex items-center gap-1.5 rounded-full border border-brand/25 bg-brand/[0.06] px-3 py-1.5 text-[10px] font-bold text-brand transition-all hover:border-brand/50 disabled:opacity-40"
        >
          <Scale className="h-3 w-3" aria-hidden /> {lang === "ar" ? "قارن" : "Compare"}
        </button>
        <button
          type="button"
          onClick={() => runCommand(lang === "ar" ? "احسب إجمالي السلة ولخص الطلب" : "Calculate my cart total and summarize the order")}
          disabled={active}
          className="inline-flex items-center gap-1.5 rounded-full border border-brand/25 bg-brand/[0.06] px-3 py-1.5 text-[10px] font-bold text-brand transition-all hover:border-brand/50 disabled:opacity-40"
        >
          <Calculator className="h-3 w-3" aria-hidden /> {lang === "ar" ? "احسب" : "Calculate"}
        </button>
        <button
          type="button"
          onClick={openPlanner}
          className="inline-flex items-center gap-1.5 rounded-full border border-brand/25 bg-brand/[0.06] px-3 py-1.5 text-[10px] font-bold text-brand transition-all hover:border-brand/50"
        >
          <CalendarClock className="h-3 w-3" aria-hidden /> {lang === "ar" ? "جدولة" : "Schedule"}
        </button>
      </div>

      {/* unlimited text fallback — useful in noisy environments */}
      <div className="mt-3">
        <button
          type="button"
          onClick={() => setTextOpen((v) => !v)}
          className="mx-auto flex items-center gap-1.5 text-[10px] font-semibold text-fg3 transition-colors hover:text-fg"
        >
          <Keyboard className="h-3.5 w-3.5" aria-hidden />
          {lang === "ar" ? "اكتب طلبك بدلًا من الكلام" : "Type instead of speaking"}
        </button>
        {textOpen && (
          <motion.form
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            onSubmit={(e) => {
              e.preventDefault();
              const value = typed.trim();
              if (!value || active) return;
              setTyped("");
              runCommand(value);
            }}
            className="mt-2 flex items-center gap-2 rounded-2xl border border-line bg-ink/55 p-1.5"
          >
            <input
              value={typed}
              onChange={(e) => setTyped(e.target.value)}
              placeholder={lang === "ar" ? "مثال: اكتب رسالة، اسأل سؤالًا، أو افتح قسمًا…" : "e.g. Write a message, ask a question, or open a category…"}
              className="min-w-0 flex-1 bg-transparent px-2 text-base text-fg outline-none placeholder:text-fg3 sm:text-xs"
              dir="auto"
            />
            <button
              type="submit"
              disabled={!typed.trim() || active}
              className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-brand text-onbrand transition-all disabled:opacity-35"
              aria-label="Send"
            >
              <Send className="h-3.5 w-3.5 rtl:rotate-180" aria-hidden />
            </button>
          </motion.form>
        )}
      </div>

      {/* mic */}
      <div className="mt-5 flex flex-col items-center gap-2.5">
        <button
          type="button"
          onClick={toggleMic}
          aria-live="polite"
          className={cn(
            "group relative grid h-16 w-16 place-items-center rounded-full transition-all duration-500",
            state === "listening"
              ? "bg-gradient-to-br from-rose-500 to-rose-600 shadow-[0_0_0_8px_rgba(244,63,94,0.12),0_20px_40px_-12px_rgba(244,63,94,0.55)]"
              : "bg-gradient-to-br from-brand to-brand-deep shadow-[0_0_0_8px_color-mix(in_oklab,var(--c-brand)_12%,transparent),0_20px_40px_-12px_color-mix(in_oklab,var(--c-brand)_55%,transparent)] hover:scale-105 active:scale-95"
          )}
          aria-label={t(state === "listening" ? "asst.listening" : "hero.cta.talk")}
        >
          {state === "listening" && (
            <>
              <span className="absolute inset-0 animate-pulse-ring rounded-full bg-rose-500/40" aria-hidden />
              <span className="absolute inset-0 animate-pulse-ring rounded-full bg-rose-500/25 [animation-delay:0.7s]" aria-hidden />
            </>
          )}
          {state === "listening" ? (
            <Square className="h-5 w-5 fill-white text-white" aria-hidden />
          ) : (
            <Mic className="h-6 w-6 text-onbrand transition-transform duration-300 group-hover:scale-110" aria-hidden />
          )}
        </button>
        <p className="flex h-4 items-center gap-2 text-[11px] text-fg3">
          {state === "listening" && (
            <span className="voice-wave [transform:scale(0.8)]" aria-hidden>
              <span /><span /><span /><span /><span />
            </span>
          )}
          {t(STATUS_KEY[state])}
          {state === "listening" && (
            <span className="inline-flex items-center gap-1 rounded-full border border-brand/30 bg-brand/10 px-2 py-0.5 text-[9px] font-bold text-brand">
              <InfinityIcon className="h-2.5 w-2.5" aria-hidden />
              {lang === "ar"
                ? `ينتظر ${(profile.silenceMs / 1000).toFixed(1)} ث بعد كلامك`
                : `Finalizes ${(profile.silenceMs / 1000).toFixed(1)}s after you pause`}
            </span>
          )}
        </p>
        <p className="text-center text-[10px] text-fg3/80">{t("asst.hint")}</p>
      </div>
    </div>
  );
}
