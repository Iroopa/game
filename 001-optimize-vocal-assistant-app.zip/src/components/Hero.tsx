import { motion, useReducedMotion } from "framer-motion";
import { Mic, Play, ShieldCheck, Star, Volume2, Zap } from "lucide-react";
import { useLang } from "../lib/i18n";
import { useStore } from "../lib/store";
import { Assistant } from "./Assistant";
import { Eyebrow } from "./Reveal";

const MARQUEE: Record<"en" | "ar", string[]> = {
  en: [
    "Compare the best-value products",
    "Open Egyptian fashion brands",
    "Write a polite follow-up email",
    "Calculate and summarize my cart",
    "Schedule my daily needs for 9 AM",
    "Where is the nearest verified vendor?",
    "Explain artificial intelligence simply",
    "Show products under 2,000 EGP",
  ],
  ar: [
    "قارن أفضل المنتجات قيمة",
    "افتح ماركات الأزياء المصرية",
    "اكتب بريد متابعة مهذب",
    "احسب السلة ولخص الطلب",
    "جدول احتياجاتي اليومية الساعة ٩",
    "أين أقرب شريك موثّق؟",
    "اشرح الذكاء الاصطناعي ببساطة",
    "اعرض منتجات بأقل من ٢٠٠٠ جنيه",
  ],
};

const ease = [0.22, 1, 0.36, 1] as const;

function scrollAndTalk() {
  document.getElementById("demo")?.scrollIntoView({ behavior: "smooth", block: "center" });
  window.setTimeout(() => window.dispatchEvent(new CustomEvent("iroopa:talk")), 700);
}

export function Hero() {
  const { t, lang } = useLang();
  const { db, activeThemeDef } = useStore();
  const ocopy = db.overrides[activeThemeDef.id]?.copy;
  const useDict = !ocopy && activeThemeDef.id === "royal";
  const ha = useDict ? t("hero.title.a") : ocopy?.a ?? activeThemeDef.copy.a;
  const hb = useDict ? t("hero.title.b") : ocopy?.b ?? activeThemeDef.copy.b;
  const sub = useDict ? t("hero.sub") : ocopy?.sub || activeThemeDef.copy.sub || t("hero.sub");
  const reduced = useReducedMotion();
  const marquee = MARQUEE[lang];

  return (
    <section id="top" className="noise relative overflow-hidden pb-10 pt-32 sm:pt-36">
      {/* ------------------------------ backdrop ------------------------------ */}
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="grid-bg absolute inset-0" />
        <div
          className="aurora-blob start-[-8%] top-[-12%] h-[460px] w-[460px] opacity-35"
          style={{ background: "var(--c-brand)", animation: reduced ? undefined : "floaty 11s ease-in-out infinite" }}
        />
        <div
          className="aurora-blob end-[-10%] top-[6%] h-[420px] w-[420px] opacity-25"
          style={{ background: "var(--c-violet)", animation: reduced ? undefined : "floaty 14s ease-in-out 1.2s infinite" }}
        />
        <div
          className="aurora-blob start-[30%] top-[38%] h-[380px] w-[380px] opacity-20"
          style={{ background: "var(--c-accent)", animation: reduced ? undefined : "floaty 16s ease-in-out 0.6s infinite" }}
        />
        <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-ink to-transparent" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-14 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10">
          {/* ------------------------------- copy ------------------------------- */}
          <div className="text-center lg:text-start">
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease }}
            >
              <Eyebrow>{t("hero.eyebrow")}</Eyebrow>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 26 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.85, delay: 0.08, ease }}
              className="mt-6 font-display text-[44px] font-bold leading-[1.04] tracking-[-0.03em] sm:text-6xl lg:text-[68px]"
            >
              {ha}{" "}
              <span className="text-gradient">{hb}</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.85, delay: 0.16, ease }}
              className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-fg2 sm:text-lg lg:mx-0"
            >
              {sub}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.85, delay: 0.24, ease }}
              className="mt-9 flex flex-wrap items-center justify-center gap-3.5 lg:justify-start"
            >
              <button
                type="button"
                onClick={scrollAndTalk}
                className="group inline-flex items-center gap-2.5 rounded-full bg-gradient-to-r from-brand to-brand-deep px-7 py-3.5 text-sm font-bold text-onbrand shadow-[0_18px_40px_-12px_color-mix(in_oklab,var(--c-brand)_65%,transparent)] transition-all duration-300 hover:scale-[1.03] hover:brightness-110 active:scale-95"
              >
                <Mic className="h-4 w-4 transition-transform duration-300 group-hover:-rotate-12" aria-hidden />
                {t("hero.cta.talk")}
              </button>
              <a
                href="#dashboard"
                className="inline-flex items-center gap-2.5 rounded-full border border-line bg-elev/70 px-7 py-3.5 text-sm font-semibold text-fg transition-all duration-300 hover:border-brand/50 hover:bg-elev"
              >
                <Play className="h-4 w-4 text-brand" aria-hidden />
                {t("hero.cta.watch")}
              </a>
            </motion.div>

            {/* trust row */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.45 }}
              className="mt-11 flex flex-wrap items-center justify-center gap-x-7 gap-y-4 lg:justify-start"
            >
              <div className="flex items-center gap-3">
                <div className="flex -space-x-2.5 rtl:space-x-reverse">
                  {["from-brand to-accent", "from-violet to-brand", "from-gold to-brand", "from-accent to-violet"].map(
                    (g, i) => (
                      <span
                        key={i}
                        className={`grid h-8 w-8 place-items-center rounded-full border-2 border-ink bg-gradient-to-br ${g} text-[10px] font-bold text-onbrand`}
                      >
                        {["SM", "AK", "LN", "RH"][i]}
                      </span>
                    )
                  )}
                </div>
                <div className="text-start">
                  <span className="flex items-center gap-1 text-xs font-bold text-gold">
                    {[0, 1, 2, 3, 4].map((i) => (
                      <Star key={i} className="h-3 w-3 fill-current" aria-hidden />
                    ))}
                  </span>
                  <p className="mt-0.5 text-[11px] text-fg3">
                    {t("hero.trust")} · {t("hero.rating")}
                  </p>
                </div>
              </div>
              <span className="hidden h-8 w-px bg-line sm:block" aria-hidden />
              <div className="flex items-center gap-5 text-fg3">
                <span className="flex items-center gap-1.5 text-[11px] font-medium">
                  <Zap className="h-3.5 w-3.5 text-brand" aria-hidden /> 0.8s
                  <span className="hidden sm:inline">{t("hero.stat.response")}</span>
                </span>
                <span className="flex items-center gap-1.5 text-[11px] font-medium">
                  <ShieldCheck className="h-3.5 w-3.5 text-brand" aria-hidden />
                  {t("footer.ondevice")}
                </span>
                <span className="flex items-center gap-1.5 text-[11px] font-medium">
                  <Volume2 className="h-3.5 w-3.5 text-brand" aria-hidden /> 40+
                  <span className="hidden sm:inline">{t("hero.stat.langs")}</span>
                </span>
              </div>
            </motion.div>
          </div>

          {/* --------------------------- assistant card --------------------------- */}
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 1, delay: 0.3, ease }}
            className="relative"
          >
            <div
              aria-hidden
              className="absolute -inset-3 rounded-[34px] bg-gradient-to-br from-brand/25 via-transparent to-violet/20 blur-xl"
            />
            <Assistant />
          </motion.div>
        </div>

        {/* ------------------------------ marquee ------------------------------ */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.7 }}
          className="marquee-mask marquee-paused relative mt-20 overflow-hidden border-y border-line py-5"
          style={{ direction: "ltr" }}
        >
          <div className="marquee-track">
            {[0, 1].map((dup) => (
              <div key={dup} className="flex shrink-0 items-center" aria-hidden={dup === 1}>
                {marquee.map((cmd, i) => (
                  <span key={`${dup}-${i}`} className="flex items-center gap-3 pe-10 text-sm text-fg2">
                    <Mic className="h-3.5 w-3.5 shrink-0 text-brand/70" aria-hidden />
                    <span className="whitespace-nowrap">“{cmd}”</span>
                  </span>
                ))}
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
