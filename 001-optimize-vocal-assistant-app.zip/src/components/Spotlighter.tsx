import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowDown, Sparkles, TriangleAlert } from "lucide-react";

interface Spot {
  id: number;
  top: number;
  left: number;
  width: number;
  height: number;
  label: string;
  kind: "ok" | "warn";
}

let seq = 1;

/**
 * Global navigation highlighter — scrolls to a target, rings it, and drops a
 * bouncing arrow with a label. Fired via:
 *   window.dispatchEvent(new CustomEvent("iroopa:highlight",
 *     { detail: { selector, label, kind } }))
 */
export function Spotlighter() {
  const [spot, setSpot] = useState<Spot | null>(null);

  useEffect(() => {
    let hideTimer = 0;
    let rafId = 0;

    const place = (el: Element, label: string, kind: "ok" | "warn") => {
      const r = el.getBoundingClientRect();
      setSpot({
        id: seq++,
        top: r.top + window.scrollY,
        left: r.left + window.scrollX,
        width: r.width,
        height: Math.min(r.height, window.innerHeight * 0.8),
        label,
        kind,
      });
    };

    const onHighlight = (e: Event) => {
      const { selector, label = "", kind = "ok" } =
        (e as CustomEvent).detail as { selector: string; label?: string; kind?: "ok" | "warn" };
      const el = document.querySelector(selector);
      if (!el) return;

      el.scrollIntoView({ behavior: "smooth", block: "start" });
      window.clearTimeout(hideTimer);
      cancelAnimationFrame(rafId);

      /* re-measure after the smooth scroll settles */
      let ticks = 0;
      const follow = () => {
        place(el, label, kind);
        ticks += 1;
        if (ticks < 46) rafId = requestAnimationFrame(follow);
      };
      rafId = requestAnimationFrame(follow);
      hideTimer = window.setTimeout(() => setSpot(null), 5200);
    };

    window.addEventListener("iroopa:highlight", onHighlight);
    return () => {
      window.removeEventListener("iroopa:highlight", onHighlight);
      window.clearTimeout(hideTimer);
      cancelAnimationFrame(rafId);
    };
  }, []);

  return (
    <AnimatePresence>
      {spot && (
        <motion.div
          key={spot.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.35 }}
          className="pointer-events-none absolute z-[65]"
          style={{ top: spot.top, left: spot.left, width: spot.width, height: spot.height }}
        >
          {/* ring */}
          <motion.div
            initial={{ scale: 0.97 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="absolute inset-0 rounded-[28px] border-2"
            style={{
              borderColor: spot.kind === "warn" ? "var(--c-gold)" : "var(--c-brand)",
              boxShadow:
                spot.kind === "warn"
                  ? "0 0 0 6px color-mix(in oklab, var(--c-gold) 14%, transparent), 0 0 60px color-mix(in oklab, var(--c-gold) 30%, transparent)"
                  : "0 0 0 6px color-mix(in oklab, var(--c-brand) 14%, transparent), 0 0 60px color-mix(in oklab, var(--c-brand) 32%, transparent)",
            }}
          />
          {/* sweeping shine */}
          <motion.div
            className="absolute inset-0 overflow-hidden rounded-[28px]"
            initial={{ opacity: 0.5 }}
            animate={{ opacity: 0 }}
            transition={{ duration: 1.6, repeat: 2 }}
          >
            <motion.div
              className="absolute inset-y-0 w-1/3"
              initial={{ x: "-120%" }}
              animate={{ x: "320%" }}
              transition={{ duration: 1.6, repeat: 2, ease: "easeInOut" }}
              style={{
                background:
                  "linear-gradient(90deg, transparent, color-mix(in oklab, var(--c-brand) 22%, transparent), transparent)",
              }}
            />
          </motion.div>

          {/* arrow + label */}
          <motion.div
            initial={{ y: -14, opacity: 0 }}
            animate={{ y: [0, 9, 0], opacity: 1 }}
            transition={{
              y: { duration: 1.1, repeat: Infinity, ease: "easeInOut" },
              opacity: { duration: 0.3 },
            }}
            className="absolute -top-12 start-1/2 -translate-x-1/2 rtl:translate-x-1/2"
          >
            <div
              className="flex items-center gap-2 rounded-full border px-4 py-2 shadow-2xl backdrop-blur-md"
              style={{
                borderColor: spot.kind === "warn" ? "var(--c-gold)" : "var(--c-brand)",
                background: "color-mix(in oklab, var(--c-panel) 88%, transparent)",
              }}
            >
              {spot.kind === "warn" ? (
                <TriangleAlert className="h-3.5 w-3.5 text-gold" aria-hidden />
              ) : (
                <Sparkles className="h-3.5 w-3.5 text-brand" aria-hidden />
              )}
              <span className="whitespace-nowrap text-xs font-bold text-fg">{spot.label}</span>
            </div>
            <ArrowDown
              className="mx-auto mt-0.5 h-5 w-5 drop-shadow"
              style={{ color: spot.kind === "warn" ? "var(--c-gold)" : "var(--c-brand)" }}
              aria-hidden
            />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/** Helper used across the app. */
export function highlightTarget(selector: string, label: string, kind: "ok" | "warn" = "ok") {
  window.dispatchEvent(new CustomEvent("iroopa:highlight", { detail: { selector, label, kind } }));
}
