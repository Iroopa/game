import { motion, useReducedMotion } from "framer-motion";
import { AudioLines, BadgeCheck, BrainCircuit, type LucideIcon } from "lucide-react";
import { useLang, type DictKey } from "../lib/i18n";
import { Eyebrow, Reveal } from "./Reveal";

const STEPS: { icon: LucideIcon; t: DictKey; d: DictKey }[] = [
  { icon: AudioLines, t: "how.s1.t", d: "how.s1.d" },
  { icon: BrainCircuit, t: "how.s2.t", d: "how.s2.d" },
  { icon: BadgeCheck, t: "how.s3.t", d: "how.s3.d" },
];

export function HowItWorks() {
  const { t } = useLang();
  const reduced = useReducedMotion();

  return (
    <section id="how" className="relative overflow-hidden py-24 sm:py-32">
      <div
        aria-hidden
        className="aurora-blob end-[-12%] top-[20%] h-[380px] w-[380px] opacity-15"
        style={{ background: "var(--c-brand)" }}
      />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <Eyebrow>{t("how.eyebrow")}</Eyebrow>
          </Reveal>
          <Reveal delay={0.08}>
            <h2 className="mt-5 font-display text-4xl font-bold tracking-[-0.02em] sm:text-5xl">
              {t("how.title")}
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mt-4 text-base leading-relaxed text-fg2 sm:text-lg">{t("how.sub")}</p>
          </Reveal>
        </div>

        <div className="relative mt-16 grid gap-10 md:grid-cols-3 md:gap-6">
          {/* animated connector */}
          <svg
            aria-hidden
            className="absolute start-[16%] end-[16%] top-9 hidden h-1 w-[68%] md:block"
            preserveAspectRatio="none"
            viewBox="0 0 100 2"
          >
            <line x1="0" y1="1" x2="100" y2="1" stroke="var(--c-line2)" strokeWidth="1.5" />
            <line
              x1="0"
              y1="1"
              x2="100"
              y2="1"
              stroke="var(--c-brand)"
              strokeWidth="1.5"
              className={reduced ? undefined : "dash-anim"}
              opacity="0.55"
            />
          </svg>

          {STEPS.map((s, i) => {
            const Icon = s.icon;
            return (
              <Reveal key={s.t} delay={0.12 * i}>
                <div className="group relative flex flex-col items-center text-center">
                  <div className="relative">
                    <motion.div
                      whileHover={{ scale: 1.06 }}
                      transition={{ type: "spring", stiffness: 300, damping: 18 }}
                      className="relative z-10 grid h-[74px] w-[74px] place-items-center rounded-3xl border border-line bg-panel shadow-[0_20px_50px_-20px_rgba(0,0,0,0.6)]"
                    >
                      <Icon className="h-7 w-7 text-brand" aria-hidden />
                      <span className="absolute -end-2 -top-2 grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-brand to-brand-deep font-display text-xs font-bold text-onbrand">
                        {i + 1}
                      </span>
                    </motion.div>
                  </div>
                  <h3 className="mt-6 text-lg font-bold tracking-tight">{t(s.t)}</h3>
                  <p className="mt-2.5 max-w-xs text-sm leading-relaxed text-fg2">{t(s.d)}</p>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
