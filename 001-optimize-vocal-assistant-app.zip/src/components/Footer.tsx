import { AtSign, Building2, Cpu, MessageCircle, Mic, Music2, Play, ShieldCheck } from "lucide-react";
import { useLang, type DictKey } from "../lib/i18n";
import { Logo } from "./Navbar";
import { Reveal } from "./Reveal";
import { LiquidMetalButton } from "./ui/liquid-metal-button";

const COLS: { title: DictKey; links: DictKey[] }[] = [
  {
    title: "footer.product",
    links: ["footer.links.features", "footer.links.demo", "footer.links.dashboard", "footer.links.languages"],
  },
  {
    title: "footer.company",
    links: ["footer.links.about", "footer.links.careers", "footer.links.press", "footer.links.contact"],
  },
  {
    title: "footer.legal",
    links: ["footer.links.terms", "footer.links.privacyp", "footer.links.security"],
  },
];

export function Footer() {
  const { t } = useLang();

  return (
    <>
      {/* ------------------------------- CTA ------------------------------- */}
      <section id="cta" className="relative overflow-hidden py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <div className="noise relative overflow-hidden rounded-[32px] border border-line px-6 py-16 text-center sm:px-12 sm:py-20">
              <div aria-hidden className="pointer-events-none absolute inset-0">
                <div className="grid-bg absolute inset-0 opacity-70" />
                <div
                  className="aurora-blob start-[10%] top-[-40%] h-[380px] w-[380px] opacity-30"
                  style={{ background: "var(--c-brand)" }}
                />
                <div
                  className="aurora-blob end-[5%] bottom-[-50%] h-[380px] w-[380px] opacity-25"
                  style={{ background: "var(--c-violet)" }}
                />
                <div className="absolute inset-0 bg-gradient-to-b from-panel/40 via-transparent to-panel/70" />
              </div>
              <div className="relative">
                <h2 className="mx-auto max-w-2xl font-display text-4xl font-bold leading-[1.05] tracking-[-0.03em] sm:text-6xl">
                  {t("cta.title.a")}{" "}
                  <span className="text-gradient">{t("cta.title.b")}</span>
                </h2>
                <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-fg2 sm:text-lg">
                  {t("cta.sub")}
                </p>
                <div className="mt-9 flex flex-wrap items-center justify-center gap-6">
                  <div className="scale-125 transform transition-transform hover:scale-[1.3]">
                    <LiquidMetalButton
                      label={t("cta.secondary")}
                      onClick={() => {
                        document.getElementById("demo")?.scrollIntoView({ behavior: "smooth", block: "center" });
                        window.setTimeout(() => window.dispatchEvent(new CustomEvent("iroopa:talk")), 700);
                      }}
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      document.getElementById("demo")?.scrollIntoView({ behavior: "smooth", block: "center" });
                      window.setTimeout(() => window.dispatchEvent(new CustomEvent("iroopa:talk")), 700);
                    }}
                    className="group inline-flex items-center gap-3 rounded-full bg-gradient-to-r from-brand to-brand-deep px-12 py-6 text-lg font-bold text-onbrand shadow-[0_20px_50px_-14px_color-mix(in_oklab,var(--c-brand)_70%,transparent)] transition-all duration-300 hover:brightness-110 active:scale-95"
                  >
                    <Mic className="h-6 w-6 transition-transform group-hover:scale-110" aria-hidden />
                    {t("cta.button")}
                  </button>
                </div>
                <div className="mt-8 flex items-center justify-center gap-6 text-[11px] text-fg3">
                  <span className="flex items-center gap-1.5">
                    <ShieldCheck className="h-3.5 w-3.5 text-brand" aria-hidden />
                    {t("footer.privacy")}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Cpu className="h-3.5 w-3.5 text-brand" aria-hidden />
                    {t("footer.ondevice")}
                  </span>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ------------------------------ footer ------------------------------ */}
      <footer className="border-t border-line pb-28 pt-14 sm:pb-14">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-10 md:grid-cols-[1.2fr_repeat(3,0.6fr)]">
            <div>
              <Logo />
              <p className="mt-4 max-w-xs text-sm leading-relaxed text-fg2">{t("footer.tag")}</p>
              <p className="mt-2 inline-flex items-center gap-2 rounded-full border border-brand/25 bg-brand/[0.06] px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-brand">
                {t("brand.tagline")}
              </p>
              <a
                href="#/submit"
                className="mt-3 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-brand to-brand-deep px-4 py-2 text-[11px] font-bold text-onbrand transition-all hover:brightness-110"
              >
                <Building2 className="h-3.5 w-3.5" aria-hidden />
                {t("cta.addcompany")}
              </a>
              <p className="mt-5 inline-flex items-center gap-2 rounded-full border border-brand/25 bg-brand/[0.06] px-3 py-1.5 text-[10px] font-bold text-brand">
                <ShieldCheck className="h-3.5 w-3.5" aria-hidden /> {t("footer.verifiedlinks")}
              </p>
              <div className="mt-5 flex gap-2">
                {[
                  { icon: AtSign, href: "#top" },
                  { icon: MessageCircle, href: "#top" },
                  { icon: Music2, href: "#top" },
                  { icon: Play, href: "https://www.youtube.com" }, // YouTube added
                ].map((item, i) => (
                  <a
                    key={i}
                    href={item.href}
                    target="_blank"
                    rel="noreferrer"
                    aria-label="Social link"
                    className="grid h-9 w-9 place-items-center rounded-full border border-line bg-elev/60 text-fg2 transition-all duration-300 hover:border-brand/50 hover:text-brand"
                  >
                    <item.icon className="h-4 w-4" aria-hidden />
                  </a>
                ))}
              </div>
            </div>
            {COLS.map((col) => (
              <div key={col.title}>
                <p className="text-xs font-bold uppercase tracking-widest text-fg3">{t(col.title)}</p>
                <ul className="mt-4 space-y-2.5">
                  {col.links.map((l) => (
                    <li key={l}>
                      <a
                        href={l === "footer.links.demo" ? "#demo" : l === "footer.links.dashboard" ? "#dashboard" : l === "footer.links.languages" ? "#languages" : l === "footer.links.features" ? "#services" : "#top"}
                        className="text-sm text-fg2 transition-colors duration-300 hover:text-fg"
                      >
                        {t(l)}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-line pt-6 sm:flex-row">
            <p className="text-xs text-fg3">{t("footer.rights")}</p>
            <p className="text-xs text-fg3" dir="ltr">
              English <span className="text-brand">·</span> العربية
            </p>
          </div>
        </div>
      </footer>
    </>
  );
}
