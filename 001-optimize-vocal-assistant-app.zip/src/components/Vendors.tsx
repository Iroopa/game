import { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  BadgePercent,
  BadgeCheck,
  Building2,
  Car,
  ChartLine,
  Clock3,
  ExternalLink,
  Landmark,
  Loader2,
  MapPin,
  Paintbrush,
  Phone,
  Plane,
  Play,
  Rocket,
  Scissors,
  Search,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  Globe2,
  Users,
  UtensilsCrossed,
  ChevronLeft,
  ChevronRight,
  Clapperboard,
  Shirt,
  Footprints,
  AtSign,
  Music2,
  MessageCircle,
  Briefcase,
  Factory,
  CircleAlert,
  type LucideIcon,
} from "lucide-react";
import {
  SECTORS,
  fmtEGP,
  sectorLabel,
  useStore,
  vendorHost,
  type Category,
  type SectorKey,
  type Vendor,
} from "../lib/store";
import { SECTOR_AR, SUB_AR, TIER_AR, useLang } from "../lib/i18n";
import { probeVendorLinks } from "../lib/link-check";
import { ImgWithFallback, Modal } from "./ui";
import { Eyebrow, Reveal } from "./Reveal";
import { cn } from "../utils/cn";

const SECTOR_ICON: Record<SectorKey, LucideIcon> = {
  insurance: ShieldCheck,
  realestate: Building2,
  startup: Rocket,
  ecommerce: ShoppingBag,
  antiques: Landmark,
  tourism: Plane,
  homes: Paintbrush,
  automotive: Car,
  salon: Scissors,
  stocks: ChartLine,
  restaurants: UtensilsCrossed,
  recruitment: Users,
  offers: BadgePercent,
  fashion: Shirt,
  footwear: Footprints,
};

const TIER_STYLE: Record<Vendor["tier"], string> = {
  Platinum: "border-violet/50 bg-violet/15 text-violet",
  Gold: "border-gold/50 bg-gold/15 text-gold",
  Silver: "border-line2 bg-fg3/15 text-fg2",
  Verified: "border-brand/50 bg-brand/15 text-brand",
};

/** Real brand logo (Clearbit → Google favicon → monogram), never a broken image. */
export function VendorLogo({ vendor, size = 44 }: { vendor: Vendor; size?: number }) {
  const host = vendorHost(vendor.website);
  const [stage, setStage] = useState(0);
  useEffect(() => setStage(0), [vendor.id]);

  const initials = vendor.name
    .split(" ")
    .slice(0, 2)
    .map((w) => w[0])
    .join("");

  const src =
    host && stage === 0
      ? `https://logo.clearbit.com/${host}`
      : host && stage === 1
        ? `https://www.google.com/s2/favicons?domain=${host}&sz=128`
        : null;

  if (src) {
    return (
      <span
        className="grid shrink-0 place-items-center overflow-hidden rounded-2xl border border-white/15 bg-white shadow-lg"
        style={{ width: size, height: size }}
      >
        <img
          src={src}
          alt={`${vendor.name} logo`}
          width={size}
          height={size}
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          onError={() => setStage((s) => s + 1)}
          className="h-full w-full object-contain p-1.5"
        />
      </span>
    );
  }

  return (
    <span
      className="grid shrink-0 place-items-center rounded-2xl border border-white/20 font-display font-bold text-white shadow-lg"
      style={{
        width: size,
        height: size,
        fontSize: size * 0.34,
        background: `linear-gradient(135deg, hsl(${vendor.logoHue} 70% 48%), hsl(${(vendor.logoHue + 62) % 360} 75% 30%))`,
      }}
      aria-hidden
    >
      {initials}
    </span>
  );
}

/* ------------------------------- reel tab -------------------------------- */

function ReelBox({ vendor }: { vendor: Vendor }) {
  const { lang, t } = useLang();
  const [broken, setBroken] = useState(false);
  const yt = vendor.socials?.youtube
    ?.replace(/\/shorts\/?$/, "")
    .replace(/\/$/, "");
  const videoLinks = [
    {
      label: "Instagram Reels",
      icon: AtSign,
      url: vendor.socials?.instagram || `https://www.google.com/search?q=${encodeURIComponent(`${vendor.name} official Instagram Reels Egypt`)}`,
      verified: Boolean(vendor.socials?.instagram),
    },
    {
      label: "TikTok",
      icon: Music2,
      url: vendor.socials?.tiktok || `https://www.tiktok.com/search?q=${encodeURIComponent(`${vendor.name} official Egypt`)}`,
      verified: Boolean(vendor.socials?.tiktok),
    },
    {
      label: "YouTube",
      icon: Play,
      url: yt || `https://www.youtube.com/results?search_query=${encodeURIComponent(`${vendor.name} official channel Egypt`)}`,
      verified: Boolean(yt),
    },
    {
      label: t("v.youtube.shorts"),
      icon: Clapperboard,
      url: yt ? `${yt}/shorts` : `https://www.youtube.com/results?search_query=${encodeURIComponent(`${vendor.name} official YouTube Shorts Egypt`)}`,
      verified: Boolean(yt),
    },
    {
      label: "Facebook Videos",
      icon: MessageCircle,
      url: vendor.socials?.facebook || `https://www.facebook.com/search/videos/?q=${encodeURIComponent(`${vendor.name} official Egypt`)}`,
      verified: Boolean(vendor.socials?.facebook),
    },
  ];
  const canPlay = !!vendor.videoUrl && !broken;

  return (
    <div className="mx-auto w-full max-w-[260px]">
      <div className="relative aspect-[9/16] overflow-hidden rounded-2xl border border-line bg-black shadow-2xl">
        {canPlay ? (
          <video
            src={vendor.videoUrl}
            className="absolute inset-0 h-full w-full object-cover"
            autoPlay
            muted
            loop
            playsInline
            preload="metadata"
            onError={() => setBroken(true)}
          />
        ) : (
          <>
            <ImgWithFallback
              src={vendor.showImg}
              alt={vendor.name}
              letter={vendor.name[0]}
              hue={vendor.logoHue}
              className="absolute inset-0 h-full w-full object-cover opacity-65"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/55 to-black/20" />
            <div className="absolute inset-0 flex flex-col items-center justify-center p-5 text-center">
              <VendorLogo vendor={vendor} size={62} />
              <p className="mt-4 text-sm font-bold text-white" dir="ltr">{vendor.name}</p>
              <p className="mt-1 text-[10px] leading-relaxed text-white/60">
                {lang === "ar"
                  ? "نعرض الروابط الرسمية المؤكدة فقط — لا نستخدم فيديوهات أو حسابات تخمينية."
                  : "Only audited official channels appear here — no stock reels or guessed handles."}
              </p>
              <div className="mt-5 flex w-full flex-col gap-2">
                {videoLinks.map((channel) => {
                  const Icon = channel.icon;
                  return (
                    <a
                      key={channel.label}
                      href={channel.url}
                      target="_blank"
                      rel="noreferrer"
                      className={cn(
                        "flex w-full items-center justify-center gap-2 rounded-full border px-3 py-2 text-[11px] font-bold text-white backdrop-blur-sm transition-colors hover:bg-white/20",
                        channel.verified
                          ? "border-brand/45 bg-brand/15"
                          : "border-dashed border-white/20 bg-white/10"
                      )}
                    >
                      <Icon className="h-3.5 w-3.5" aria-hidden /> {channel.label}
                      {channel.verified ? (
                        <BadgeCheck className="h-3 w-3 text-brand" aria-hidden />
                      ) : (
                        <Search className="h-3 w-3 text-gold" aria-hidden />
                      )}
                    </a>
                  );
                })}
                {videoLinks.some((link) => !link.verified) && (
                  <span className="rounded-xl border border-gold/30 bg-gold/10 p-2 text-[9px] leading-relaxed text-gold">
                    {t("v.discovery.notvideos")}
                  </span>
                )}
              </div>
            </div>
          </>
        )}
        {canPlay && (
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent p-3 pt-8">
            <p className="flex items-center gap-1.5 text-xs font-bold text-white" dir="ltr">
              <Clapperboard className="h-3.5 w-3.5" aria-hidden /> {vendor.name}
            </p>
            <p className="mt-0.5 text-[10px] text-white/70">{lang === "ar" ? "فيديو رسمي موثّق" : "Audited official video"}</p>
          </div>
        )}
      </div>
    </div>
  );
}

/* --------------------------- social embed panel --------------------------- */

const CHANNEL_ACCENT: Record<string, string> = {
  instagram: "from-[#833ab4] via-[#fd1d1d] to-[#fcb045]",
  facebook: "from-[#1877f2] to-[#0b5fce]",
  tiktok: "from-[#25f4ee] via-[#111] to-[#fe2c55]",
  youtube: "from-[#ff0000] to-[#b30000]",
};

function SocialEmbed({
  vendor,
  channel,
  url,
  embeddable,
  note,
  verified,
  t,
}: {
  vendor: Vendor;
  channel: string;
  url: string;
  embeddable: boolean;
  note: string;
  verified: boolean;
  t: (k: Parameters<ReturnType<typeof useLang>["t"]>[0]) => string;
}) {
  const gradient = CHANNEL_ACCENT[channel] ?? "from-brand to-accent";
  const result = verified && embeddable ? platformEmbedUrl(channel, url) : { src: null };
  const embedUrl = result.src;
  const blockedReason = result.blocked;

  /* Legal platform-provided embeds. A fallback action is always visible. */
  if (embedUrl) {
    return (
      <div>
        <div className="mb-3 flex flex-wrap items-center gap-1.5">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-brand/35 bg-brand/10 px-3 py-1.5 text-[10px] font-bold text-brand">
            <BadgeCheck className="h-3 w-3" /> Embedded official {channel}
          </span>
          <a
            href={url}
            target="_blank"
            rel="noreferrer"
            className="ms-auto inline-flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 text-[11px] font-bold text-fg2 hover:text-brand"
          >
            <ExternalLink className="h-3 w-3" aria-hidden /> {t("v.opensite")}
          </a>
        </div>
        <div className="overflow-hidden rounded-2xl border border-line bg-black">
          <iframe
            title={`${vendor.name} — ${channel}`}
            src={embedUrl}
            className="h-[58dvh] min-h-[380px] w-full"
            loading="lazy"
            referrerPolicy="strict-origin-when-cross-origin"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
        <div className="mt-2 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-center">
          <p className="text-[10px] text-fg3">{note}</p>
          <a
            href={url}
            target="_blank"
            rel="noreferrer"
            className="text-[10px] font-bold text-brand underline decoration-dotted underline-offset-2 hover:text-fg"
          >
            {t("v.embed.notloading")} · {t("v.embed.open")}
          </a>
        </div>
      </div>
    );
  }

  /* Cannot embed this link — explain exactly why and offer the real action. */
  const blockedKey =
    blockedReason === "needsid"
      ? ("v.embed.needsid" as const)
      : blockedReason === "noplugin"
        ? ("v.embed.noplugin" as const)
        : ("v.embed.notloading" as const);

  /* Non-embeddable platform: branded preview + honest notice + escape hatch. */
  const Icon =
    channel === "instagram" ? AtSign
    : channel === "facebook" ? MessageCircle
    : channel === "tiktok" ? Music2
    : channel === "linkedin" ? Briefcase
    : Play;

  return (
    <div>
      <div className="overflow-hidden rounded-2xl border border-line">
        <div className={cn("flex items-center gap-3 bg-gradient-to-r p-4", gradient)}>
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white/20 text-white backdrop-blur-sm">
            <Icon className="h-5 w-5" aria-hidden />
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold text-white" dir="ltr">{vendor.name}</p>
            <p className="truncate text-[11px] text-white/80" dir="ltr">{url}</p>
          </div>
          {verified ? (
            <BadgeCheck className="h-5 w-5 shrink-0 text-white" aria-hidden />
          ) : (
            <Search className="h-5 w-5 shrink-0 text-white" aria-hidden />
          )}
        </div>
        <div className="flex flex-col items-center gap-4 bg-elev/40 px-6 py-10 text-center">
          <span className={cn("grid h-16 w-16 place-items-center rounded-3xl bg-gradient-to-br text-white", gradient)}>
            <Icon className="h-7 w-7" aria-hidden />
          </span>
          <p className="max-w-md text-xs leading-relaxed text-fg2">
            {!verified
              ? `No audited ${channel} account is saved for this vendor yet. Use the discovery search, verify the result, then save the exact URL in Dashboard → Link Health.`
              : blockedReason
                ? t(blockedKey)
                : note}
          </p>
          <a
            href={url}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full border border-line bg-panel px-6 py-2.5 text-xs font-bold text-fg transition-colors hover:border-brand/50 hover:text-brand"
          >
            {verified ? <ExternalLink className="h-4 w-4" aria-hidden /> : <Search className="h-4 w-4 text-gold" aria-hidden />}
            {verified ? "Open official account" : `Find official ${channel} account`}
          </a>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ vendor modal ----------------------------- */

type Tab =
  | "products"
  | "visit"
  | "map"
  | "reel"
  | "instagram"
  | "facebook"
  | "tiktok"
  | "youtube"
  | "linkedin";

/**
 * Platforms either allow official embedding or they do not. Instagram, Facebook
 * and TikTok send X-Frame-Options on profile pages, so those render an honest
 * in-frame notice plus a new-tab escape hatch instead of a blank or blocked frame.
 */
const EMBED_POLICY: Record<string, { embeddable: boolean; note: string }> = {
  instagram: {
    embeddable: true,
    note: "Instagram public profile embed. If the account disables embedding, use Open official account.",
  },
  facebook: {
    embeddable: true,
    note: "Official Facebook Page Plugin. Some regional/privacy settings can limit the feed.",
  },
  tiktok: {
    embeddable: false,
    note: "TikTok blocks profile embedding. Open the official account to watch its short videos.",
  },
  youtube: {
    embeddable: true,
    note: "Official uploads player is available when YouTube exposes a channel ID. Otherwise open the audited channel.",
  },
};

/**
 * Builds a platform-sanctioned embed URL, or null when the saved link cannot be
 * embedded (in which case the UI shows a clearly-labelled fallback panel).
 *
 * YouTube only permits iframing of /embed/ paths. A channel can be embedded as
 * its uploads playlist — the official, still-supported pattern — but ONLY when
 * the channel ID (UC…) is known. @handle, /user/ and /c/ links cannot be
 * resolved client-side, so those fall back with an actionable message.
 */
function platformEmbedUrl(
  channel: string,
  url: string,
): { src: string | null; blocked?: "needsid" | "noplugin" } {
  try {
    const clean = url.split("?")[0].replace(/\/$/, "");

    if (channel === "instagram") {
      return { src: `${clean}/embed` };
    }

    if (channel === "linkedin") {
      /* LinkedIn profiles can't be easily embedded anonymously via iframe */
      return { src: null, blocked: "noplugin" };
    }

    if (channel === "facebook") {
      /* The Page Plugin only accepts real page URLs, not /p/ or /people/ links. */
      if (/\/(p|people)\//.test(clean)) return { src: null, blocked: "noplugin" };
      return {
        src: `https://www.facebook.com/plugins/page.php?href=${encodeURIComponent(
          `${clean}/`
        )}&tabs=timeline&width=640&height=720&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=false`,
      };
    }

    if (channel === "youtube") {
      const uc = clean.match(/\/channel\/(UC[\w-]{20,})/)?.[1];
      if (!uc) return { src: null, blocked: "needsid" };
      /* UC… → UU… is the channel's uploads playlist; videoseries embeds it. */
      const uploads = `UU${uc.slice(2)}`;
      return {
        src: `https://www.youtube-nocookie.com/embed/videoseries?list=${uploads}&rel=0&modestbranding=1`,
      };
    }
  } catch {
    return { src: null };
  }
  return { src: null };
}

export function VendorModal({ vendor, onClose }: { vendor: Vendor | null; onClose: () => void }) {
  const { vendorsOf, addToCart, bulkUpsertVendors } = useStore();
  const { t, lang } = useLang();
  const [tab, setTab] = useState<Tab>("products");
  const [linkTesting, setLinkTesting] = useState(false);
  useEffect(() => setTab("products"), [vendor?.id]);

  /* Public smoke test: refresh stale/missing link health at most once per week. */
  useEffect(() => {
    if (!vendor) return;
    const checked = vendor.linkCheck?.checkedAt
      ? new Date(vendor.linkCheck.checkedAt).getTime()
      : 0;
    if (checked && Date.now() - checked < 7 * 24 * 60 * 60 * 1000) return;
    let active = true;
    setLinkTesting(true);
    void probeVendorLinks({
      website: vendor.website || undefined,
      instagram: vendor.socials?.instagram,
      facebook: vendor.socials?.facebook,
      tiktok: vendor.socials?.tiktok,
      youtube: vendor.socials?.youtube,
    }).then((report) => {
      if (!active) return;
      bulkUpsertVendors([
        {
          ...vendor,
          linkCheck: { ...report, checkedAt: new Date().toISOString() },
          linkStatus:
            report.website.state === "ok"
              ? "fresh"
              : report.website.state === "missing"
                ? "unverified"
                : "stale",
        },
      ]);
      setLinkTesting(false);
    });
    return () => {
      active = false;
    };
  }, [vendor?.id, bulkUpsertVendors]);

  /* voice can jump straight to a tab (e.g. the map after an order) */
  useEffect(() => {
    const onTab = (e: Event) => setTab((e as CustomEvent).detail as Tab);
    window.addEventListener("iroopa:vendor-tab", onTab);
    return () => window.removeEventListener("iroopa:vendor-tab", onTab);
  }, []);

  const products = useMemo(
    () => (vendor ? vendorsOf(vendor.id).filter((p) => !p.hidden) : []),
    [vendor, vendorsOf]
  );

  if (!vendor) return <Modal open={false} onClose={onClose}>{null}</Modal>;

  const socialTabs = [
    { key: "instagram", label: "Instagram", icon: AtSign },
    { key: "facebook", label: "Facebook", icon: MessageCircle },
    { key: "tiktok", label: "TikTok", icon: Music2 },
    { key: "youtube", label: "YouTube", icon: Play },
    { key: "linkedin", label: "LinkedIn", icon: Briefcase },
  ] as { key: Tab; label: string; icon: LucideIcon }[];

  const tabs: { key: Tab; label: string; icon: LucideIcon }[] = [
    { key: "products", label: t("v.tab.products"), icon: ShoppingBag },
    { key: "visit", label: t("v.tab.visit"), icon: Globe2 },
    { key: "map", label: t("v.tab.map"), icon: MapPin },
    ...socialTabs,
    { key: "reel", label: t("v.tab.reel"), icon: Clapperboard },
  ];
  const host = vendorHost(vendor.website);
  const entityKind = vendor.entityKind ?? (host ? "official" : "marketplace");
  const linkStatus = vendor.linkStatus ?? (host ? "fresh" : "unverified");
  const isManufacturer = entityKind === "manufacturer" || vendor.about.includes("MOQ");
  const contactVerified = Boolean(vendor.hotline && linkStatus === "fresh");
  const mapVerified = Boolean(vendor.mapUrl || vendor.mapQuery);
  const mapSearchQuery = vendor.mapQuery || `${vendor.name}, Egypt`;
  const websiteDiscovery = `https://www.google.com/search?q=${encodeURIComponent(`${vendor.name} official website Egypt`)}`;
  const whatsappNumber = vendor.whatsapp || "";
  const whatsappDiscovery = `https://www.google.com/search?q=${encodeURIComponent(`${vendor.name} official WhatsApp Egypt`)}`;
  const socialDiscovery = (platform: string) =>
    `https://www.google.com/search?q=${encodeURIComponent(`${vendor.name} official ${platform} Egypt`)}`;
  const socials = [
    { key: "instagram", label: "Instagram", icon: AtSign, url: vendor.socials?.instagram, discovery: socialDiscovery("Instagram") },
    { key: "facebook", label: "Facebook", icon: MessageCircle, url: vendor.socials?.facebook, discovery: socialDiscovery("Facebook") },
    { key: "tiktok", label: "TikTok", icon: Music2, url: vendor.socials?.tiktok, discovery: socialDiscovery("TikTok") },
    { key: "youtube", label: "YouTube", icon: Play, url: vendor.socials?.youtube, discovery: `https://www.youtube.com/results?search_query=${encodeURIComponent(`${vendor.name} official channel Egypt`)}` },
    { key: "linkedin", label: "LinkedIn", icon: Briefcase, url: vendor.socials?.linkedin, discovery: socialDiscovery("LinkedIn") },
  ];

  return (
    <Modal open={!!vendor} onClose={onClose} wide labelledBy="vendor-modal-title">
      <div>
        {/* hero */}
        <div className="relative h-36 overflow-hidden rounded-t-3xl sm:h-44">
          <ImgWithFallback
            src={vendor.showImg}
            alt={`${vendor.name} showroom`}
            letter={vendor.name[0]}
            hue={vendor.logoHue}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-panel via-panel/40 to-transparent" />
          <div className="absolute bottom-3 start-4 flex items-end gap-3">
            <VendorLogo vendor={vendor} size={52} />
            <div className="pb-0.5">
              <p id="vendor-modal-title" className="font-display text-lg font-bold leading-tight text-fg" dir="ltr">
                {vendor.name}
              </p>
              <p className="text-[11px] text-fg2">
                {lang === "ar" ? SECTOR_AR[vendor.sector] : sectorLabel(vendor.sector)} ·{" "}
                {mapVerified
                  ? vendor.mapQuery
                  : lang === "ar"
                    ? "بحث في مصر"
                    : "Egypt-wide discovery"}
              </p>
            </div>
          </div>
          <div className="absolute top-3 flex flex-col items-end gap-1.5" style={{ right: "3.25rem", left: "auto" }}>
            <span className={cn("rounded-full border px-2.5 py-1 text-[10px] font-bold backdrop-blur-md", TIER_STYLE[vendor.tier])}>
              {lang === "ar" ? TIER_AR[vendor.tier] : vendor.tier}
            </span>
            <span
              className={cn(
                "rounded-full border px-2 py-0.5 text-[8.5px] font-bold backdrop-blur-md",
                entityKind === "official"
                  ? "border-brand/45 bg-brand/15 text-brand"
                  : entityKind === "manufacturer"
                    ? "border-gold/45 bg-gold/15 text-gold"
                    : "border-accent/40 bg-accent/15 text-accent"
              )}
            >
              {entityKind === "official"
                ? t("v.entity.brand")
                : entityKind === "manufacturer"
                  ? t("v.entity.manufacturer")
                  : entityKind === "store"
                    ? t("v.entity.store")
                    : t("v.entity.marketplace")}
            </span>
          </div>
        </div>

        {/* quick actions */}
        <div className="flex flex-wrap items-center gap-2 border-b border-line px-4 py-3">
          {host ? (
            <button
              type="button"
              onClick={() => setTab("visit")}
              className="inline-flex items-center gap-1.5 rounded-full border border-line bg-elev/70 px-3 py-1.5 text-[11px] font-semibold text-fg2 transition-colors hover:border-brand/50 hover:text-fg"
            >
              <ExternalLink className="h-3 w-3" aria-hidden /> {t("v.website")}
            </button>
          ) : (
            <a
              href={websiteDiscovery}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-full border border-dashed border-line px-3 py-1.5 text-[11px] font-semibold text-fg3 transition-colors hover:border-brand/50 hover:text-fg"
            >
              <Search className="h-3 w-3 text-gold" aria-hidden /> {t("v.site.find")}
            </a>
          )}
          {contactVerified ? (
            <a
              href={`tel:${vendor.hotline}`}
              className="inline-flex items-center gap-1.5 rounded-full border border-line bg-elev/70 px-3 py-1.5 text-[11px] font-semibold text-fg2 transition-colors hover:border-brand/50 hover:text-fg"
            >
              <Phone className="h-3 w-3" aria-hidden /> {vendor.hotline}
            </a>
          ) : (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-dashed border-line px-3 py-1.5 text-[10px] font-semibold text-fg3" title={t("v.contact.na")}>
              <CircleAlert className="h-3 w-3 text-gold" aria-hidden /> {t("v.contact.na")}
            </span>
          )}
          <button
            type="button"
            onClick={() => setTab("map")}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-semibold transition-colors",
              mapVerified
                ? "border-line bg-elev/70 text-fg2 hover:border-brand/50 hover:text-fg"
                : "border-dashed border-line text-fg3 hover:border-brand/40 hover:text-fg"
            )}
          >
            {mapVerified ? <MapPin className="h-3 w-3 text-brand" aria-hidden /> : <Search className="h-3 w-3 text-gold" aria-hidden />}
            {mapVerified ? t("v.directions") : t("v.map.search")}
          </button>
          <a
            href={whatsappNumber ? `https://wa.me/${whatsappNumber.startsWith("20") ? whatsappNumber : `2${whatsappNumber}`}` : whatsappDiscovery}
            target="_blank"
            rel="noreferrer"
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-semibold transition-colors",
              whatsappNumber
                ? "border-brand/35 bg-brand/[0.06] text-fg2 hover:border-brand/60 hover:text-brand"
                : "border-dashed border-line text-fg3 hover:border-brand/40 hover:text-fg"
            )}
            title={whatsappNumber ? t("v.contact.verified") : t("v.whatsapp.find")}
          >
            {whatsappNumber ? <MessageCircle className="h-3 w-3 text-brand" aria-hidden /> : <Search className="h-3 w-3 text-gold" aria-hidden />}
            {whatsappNumber ? "WhatsApp" : t("v.whatsapp.find")}
            {whatsappNumber && <BadgeCheck className="h-2.5 w-2.5 text-brand" aria-hidden />}
          </a>
          {socials.map((social) => {
            const Icon = social.icon;
            const verified = Boolean(social.url);
            return (
              <button
                type="button"
                key={social.key}
                onClick={() => setTab(social.key as Tab)}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-semibold transition-colors",
                  verified
                    ? "border-brand/30 bg-brand/[0.06] text-fg2 hover:border-brand/60 hover:text-brand"
                    : "border-dashed border-line text-fg3 hover:border-brand/40 hover:text-fg"
                )}
                title={verified ? `${social.label} — ${t("v.audited")}` : `${social.label} — ${t("v.social.find")}`}
              >
                <Icon className={cn("h-3 w-3", verified ? "text-brand" : "text-fg3")} aria-hidden /> {social.label}
                {verified ? (
                  <BadgeCheck className="h-2.5 w-2.5 text-brand" aria-hidden />
                ) : (
                  <Search className="h-2.5 w-2.5 text-gold" aria-hidden />
                )}
              </button>
            );
          })}
          {isManufacturer ? (
            <span className="ms-auto inline-flex items-center gap-1.5 text-[10px] font-semibold text-gold">
              <Factory className="h-3.5 w-3.5" aria-hidden /> {t("v.b2b")}
            </span>
          ) : (
            <span
              className="ms-auto inline-flex items-center gap-1.5 text-[10px] font-semibold"
              style={{
                color:
                  linkStatus === "fresh"
                    ? "var(--c-brand)"
                    : linkStatus === "stale"
                      ? "var(--c-gold)"
                      : "var(--c-fg3)",
              }}
              title={
                linkStatus === "fresh"
                  ? t("v.links.fresh")
                  : linkStatus === "stale"
                    ? t("v.links.stale")
                    : t("v.links.unverified")
              }
            >
              {linkTesting ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
              ) : linkStatus === "fresh" ? (
                <BadgeCheck className="h-3.5 w-3.5" aria-hidden />
              ) : (
                <CircleAlert className="h-3.5 w-3.5" aria-hidden />
              )}
              {linkTesting
                ? lang === "ar"
                  ? "جاري فحص الروابط"
                  : "Checking links"
                : linkStatus === "fresh"
                  ? t("v.links.fresh")
                  : linkStatus === "stale"
                    ? t("v.links.stale")
                    : t("v.links.unverified")}
            </span>
          )}
        </div>

        {/* tabs */}
        <div className="no-scrollbar sticky top-0 z-20 flex gap-1 overflow-x-auto border-b border-line bg-panel/95 px-4 pt-3 backdrop-blur-xl" role="tablist">
          {tabs.map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.key}
                role="tab"
                aria-selected={tab === t.key}
                onClick={() => setTab(t.key)}
                className={cn(
                  "relative flex shrink-0 items-center gap-1.5 rounded-t-xl px-3.5 py-2 text-xs font-bold transition-colors",
                  tab === t.key ? "text-brand" : "text-fg3 hover:text-fg"
                )}
              >
                <Icon className="h-3.5 w-3.5" aria-hidden />
                {t.label}
                {tab === t.key && (
                  <motion.span layoutId="vendor-tab" className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-brand" />
                )}
              </button>
            );
          })}
        </div>

        <div className="p-4">
          {tab === "products" && (
            <div>
              {vendor.catalogUrl ? (
                <div className="overflow-hidden rounded-2xl border border-brand/35 bg-white">
                  <div className="flex items-center gap-3 border-b border-line bg-elev/70 p-3">
                    <VendorLogo vendor={vendor} size={34} />
                    <span className="min-w-0 flex-1">
                      <span className="block text-xs font-bold text-fg">{t("v.officialcatalog")}</span>
                      <span className="block truncate text-[10px] text-fg3" dir="ltr">{vendorHost(vendor.catalogUrl)}</span>
                    </span>
                    <BadgeCheck className="h-4 w-4 shrink-0 text-brand" aria-hidden />
                  </div>
                  <iframe
                    title={`${vendor.name} official catalogue`}
                    src={vendor.catalogUrl}
                    className="h-[460px] w-full bg-white"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
                  />
                  <p className="border-t border-line bg-elev/60 px-3 py-2 text-center text-[10px] text-fg3">
                    {t("v.catalognote")}
                  </p>
                </div>
              ) : (
                <>
                  <p className="mb-3 text-[10px] leading-relaxed text-fg3">{t("v.previewnote")}</p>
                  <div className="grid gap-3 sm:grid-cols-3">
                    {products.map((p) => (
                      <div key={p.id} className="group overflow-hidden rounded-2xl border border-line bg-elev/50">
                        <div className="aspect-[4/3] overflow-hidden">
                          <ImgWithFallback src={p.img} alt={p.name} letter={p.name[0]} hue={vendor.logoHue} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        </div>
                        <div className="p-3">
                          <p className="line-clamp-1 text-xs font-bold text-fg">{p.name}</p>
                          <p className="mt-1 flex items-baseline gap-1.5">
                            <span className="text-sm font-bold text-brand">{fmtEGP(p.sale ?? p.price)}</span>
                            {p.sale && <span className="text-[10px] text-fg3 line-through">{fmtEGP(p.price)}</span>}
                          </p>
                          <button
                            type="button"
                            onClick={() => addToCart(p.id)}
                            className="mt-2 inline-flex w-full items-center justify-center gap-1.5 rounded-lg bg-gradient-to-r from-brand to-brand-deep px-2 py-1.5 text-[11px] font-bold text-onbrand transition-all hover:brightness-110 active:scale-95"
                          >
                            <ShoppingCart className="h-3 w-3" aria-hidden /> {t("v.add")}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          {tab === "visit" && (
            <div>
              {/* in-popup website frame — same pattern as the map popup */}
              <div className="overflow-hidden rounded-2xl border border-line bg-white">
                <div className="flex items-center gap-2 border-b border-line bg-elev/70 px-3 py-2">
                  <span className="flex gap-1" aria-hidden>
                    <span className="h-2 w-2 rounded-full bg-rose-400/70" />
                    <span className="h-2 w-2 rounded-full bg-gold/70" />
                    <span className="h-2 w-2 rounded-full bg-brand/70" />
                  </span>
                  <span className="truncate text-[10px] text-fg3" dir="ltr">{host ?? vendor.website}</span>
                </div>
                {host ? (
                  <iframe
                    title={`${vendor.name} website`}
                    src={vendor.website}
                    className="h-72 w-full bg-white sm:h-96"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
                  />
                ) : (
                  <ImgWithFallback src={vendor.showImg} alt={vendor.name} letter={vendor.name[0]} hue={vendor.logoHue} className="h-72 w-full object-cover sm:h-96" />
                )}
                <div className="grid grid-cols-2">
                  <a
                    href={host ? vendor.website : websiteDiscovery}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-center gap-2 border-t border-line bg-elev/60 py-2.5 text-xs font-bold text-brand transition-colors hover:text-fg"
                  >
                    <ExternalLink className="h-3.5 w-3.5" aria-hidden /> {host ? t("v.opensite") : t("v.site.find")}
                  </a>
                  <a
                    href={websiteDiscovery}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-center gap-2 border-t border-l border-line bg-elev/40 py-2.5 text-xs font-bold text-fg2 transition-colors hover:text-brand"
                  >
                    <Search className="h-3.5 w-3.5 text-gold" aria-hidden /> {t("v.site.verify")}
                  </a>
                </div>
              </div>
              <p className="mt-2 text-center text-[10px] text-fg3">{t("v.sitenote")}</p>
              <p className="mt-4 text-sm leading-relaxed text-fg2" dir="auto">{vendor.about}</p>
              <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
                <div className="flex items-center gap-2.5 rounded-xl border border-line bg-elev/50 p-3 text-xs text-fg2">
                  <Clock3 className="h-4 w-4 shrink-0 text-brand" aria-hidden /> {t("v.hours")}
                </div>
                <div className="flex items-center gap-2.5 rounded-xl border border-line bg-elev/50 p-3 text-xs text-fg2">
                  <MapPin className="h-4 w-4 shrink-0 text-brand" aria-hidden />{" "}
                  {vendor.mapQuery || t("v.map.na")}
                </div>
              </div>
              <div className="mt-4 flex gap-2">
                {products.slice(0, 3).map((p) => (
                  <div key={p.id} className="h-16 flex-1 overflow-hidden rounded-xl border border-line">
                    <ImgWithFallback src={p.img} alt={p.name} letter={p.name[0]} hue={vendor.logoHue} className="h-full w-full object-cover" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "map" && (
            <div className="overflow-hidden rounded-2xl border border-line">
              <div
                className={cn(
                  "flex items-center gap-2 border-b px-3 py-2 text-[10px] font-semibold",
                  mapVerified
                    ? "border-brand/25 bg-brand/[0.07] text-brand"
                    : "border-gold/25 bg-gold/[0.07] text-gold"
                )}
              >
                {mapVerified ? <BadgeCheck className="h-3.5 w-3.5" /> : <Search className="h-3.5 w-3.5" />}
                {mapVerified ? t("v.links.fresh") : t("v.map.discovery")}
              </div>
              <iframe
                title={`Map — ${vendor.name}`}
                src={`https://www.google.com/maps?q=${encodeURIComponent(mapSearchQuery)}&output=embed`}
                className="h-72 w-full grayscale-[35%] invert-[88%] hue-rotate-180 sm:h-80"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen
              />
              <a
                href={vendor.mapUrl || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapSearchQuery)}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 border-t border-line bg-elev/60 py-2.5 text-xs font-bold text-brand transition-colors hover:text-fg"
              >
                <MapPin className="h-3.5 w-3.5" aria-hidden /> {mapVerified ? t("v.openmaps") : t("v.map.search")}
              </a>
            </div>
          )}

          {(["instagram", "facebook", "tiktok", "youtube"] as Tab[]).map((channel) => {
            if (tab !== channel) return null;
            const social = socials.find((s) => s.key === channel);
            const verified = Boolean(social?.url);
            const url = social?.url || social?.discovery;
            if (!url) return null;
            const policy = EMBED_POLICY[channel];
            return (
              <SocialEmbed
                key={channel}
                vendor={vendor}
                channel={channel}
                url={url}
                embeddable={policy.embeddable}
                note={policy.note}
                verified={verified}
                t={t}
              />
            );
          })}

          {tab === "reel" && <ReelBox vendor={vendor} />}
        </div>
      </div>
    </Modal>
  );
}

/* ------------------------------- the section ----------------------------- */

export function BrandsSection() {
  const { db } = useStore();
  const { t, lang } = useLang();
  const [sector, setSector] = useState<SectorKey | "all">("all");
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [active, setActive] = useState<Vendor | null>(null);
  const [limit, setLimit] = useState(12);

  /* voice: "open Zooba" / "where is Sodic" */
  useEffect(() => {
    const onOpen = (e: Event) => {
      const id = String((e as CustomEvent).detail);
      const v = db.vendors.find((x) => x.id === id);
      if (v) setActive(v);
    };
    window.addEventListener("iroopa:open-vendor", onOpen);
    return () => window.removeEventListener("iroopa:open-vendor", onOpen);
  }, [db.vendors]);

  const visibleSectors = SECTORS.filter((s) => !db.sectorsHidden[s.key]);
  const vendors = useMemo(() => {
    let list = db.vendors
      .filter((v) => !v.hidden && !db.sectorsHidden[v.sector])
      .sort((a, b) => a.order - b.order);
    if (sector !== "all") list = list.filter((v) => v.sector === sector);
    if (activeTag) list = list.filter((v) => v.tags?.includes(activeTag));
    return list;
  }, [db.vendors, db.sectorsHidden, sector, activeTag]);
  const coverage = useMemo(() => {
    const visible = db.vendors.filter((v) => !v.hidden);
    return {
      sites: visible.filter((v) => Boolean(vendorHost(v.website))).length,
      socials: visible.filter((v) => Object.values(v.socials ?? {}).some(Boolean)).length,
      whatsapp: visible.filter((v) => Boolean(v.whatsapp)).length,
      maps: visible.length,
      logos: visible.length,
    };
  }, [db.vendors]);

  return (
    <section id="vendors" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <Reveal>
            <Eyebrow>{t("v.eyebrow")}</Eyebrow>
          </Reveal>
          <Reveal delay={0.08}>
            <h2 className="mt-5 font-display text-4xl font-bold tracking-[-0.02em] sm:text-5xl">
              {db.vendors.filter((v) => !v.hidden).length} {t("v.title.a")}{" "}
              <span className="text-gradient">
                {SECTORS.filter((s) => !db.sectorsHidden[s.key]).length}{" "}
                {lang === "ar" ? "قطاعًا" : "sectors"}
              </span>
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-fg2 sm:text-lg">
              {t("v.sub")}
            </p>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mx-auto mt-4 flex max-w-3xl flex-wrap items-center justify-center gap-x-3 gap-y-1.5 text-[10px] font-semibold text-fg3">
              <span>{coverage.maps} {t("v.coverage.maps")}</span>
              <span className="text-line2" aria-hidden>•</span>
              <span>{coverage.sites} {t("v.coverage.sites")}</span>
              <span className="text-line2" aria-hidden>•</span>
              <span>{coverage.socials} {t("v.coverage.socials")}</span>
              <span className="text-line2" aria-hidden>•</span>
              <span>{coverage.whatsapp} {t("v.coverage.whatsapp")}</span>
              <span className="text-line2" aria-hidden>•</span>
              <span>{coverage.logos} {t("v.coverage.logos")}</span>
            </p>
          </Reveal>
        </div>

        {/* sector chips */}
        <Reveal delay={0.24}>
          <div className="no-scrollbar -mx-4 mt-10 flex flex-col gap-3 overflow-x-auto px-4 pb-1">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => { setSector("all"); setLimit(12); }}
                className={cn(
                  "shrink-0 rounded-full border px-4 py-2 text-xs font-bold transition-all",
                  sector === "all"
                    ? "border-transparent bg-gradient-to-r from-brand to-brand-deep text-onbrand"
                    : "border-line bg-elev/60 text-fg2 hover:border-brand/40 hover:text-fg"
                )}
              >
                {t("v.all")}
              </button>
              {visibleSectors.map((s) => {
                const Icon = SECTOR_ICON[s.key];
                return (
                  <button
                    key={s.key}
                    type="button"
                    onClick={() => { setSector(s.key); setLimit(12); }}
                    className={cn(
                      "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-4 py-2 text-xs font-bold transition-all",
                      sector === s.key
                        ? "border-transparent bg-gradient-to-r from-brand to-brand-deep text-onbrand"
                        : "border-line bg-elev/60 text-fg2 hover:border-brand/40 hover:text-fg"
                    )}
                  >
                    <Icon className="h-3.5 w-3.5" aria-hidden />
                    {lang === "ar" ? SECTOR_AR[s.key] : s.label}
                  </button>
                );
              })}
            </div>
            
            {/* Expansion Filters */}
            <div className="flex items-center gap-2 border-t border-line/40 pt-2">
              <span className="text-[10px] font-bold uppercase tracking-widest text-fg3 me-2">
                Filters
              </span>
              <button
                type="button"
                onClick={() => setActiveTag(activeTag === "Egyptian Owned" ? null : "Egyptian Owned")}
                className={cn(
                  "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-bold transition-all",
                  activeTag === "Egyptian Owned"
                    ? "border-brand bg-brand/10 text-brand"
                    : "border-line bg-elev/40 text-fg2 hover:border-brand/40 hover:text-fg"
                )}
              >
                Egyptian Owned / Local Brand
              </button>
              <button
                type="button"
                onClick={() => setActiveTag(activeTag === "Gen Z Trending" ? null : "Gen Z Trending")}
                className={cn(
                  "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-bold transition-all",
                  activeTag === "Gen Z Trending"
                    ? "border-violet bg-violet/10 text-violet"
                    : "border-line bg-elev/40 text-fg2 hover:border-violet/40 hover:text-fg"
                )}
              >
                Gen Z Trending / Streetwear
              </button>
            </div>
          </div>
        </Reveal>

        {/* grid */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {vendors.slice(0, limit).map((v, i) => (
            <Reveal key={v.id} delay={0.04 * (i % 4)} className="h-full">
              <button
                type="button"
                onClick={() => setActive(v)}
                className="card-surface card-spotlight group block h-full w-full overflow-hidden rounded-3xl text-start transition-transform duration-500 hover:-translate-y-1"
              >
                <div className="relative aspect-[16/10] overflow-hidden">
                  <ImgWithFallback
                    src={v.showImg}
                    alt={`${v.name} showroom`}
                    letter={v.name[0]}
                    hue={v.logoHue}
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent" />
                  <span className={cn("absolute end-3 top-3 rounded-full border px-2 py-0.5 text-[9px] font-bold backdrop-blur-md", TIER_STYLE[v.tier])}>
                    {lang === "ar" ? TIER_AR[v.tier] : v.tier}
                  </span>
                  <span className="absolute bottom-3 start-3">
                    <VendorLogo vendor={v} size={40} />
                  </span>
                </div>
                <div className="p-4">
                  <p className="truncate text-sm font-bold text-fg" dir="ltr">{v.name}</p>
                  <p className="mt-1 flex items-center gap-1.5 text-[11px] text-fg3">
                    {(() => {
                      const Icon = SECTOR_ICON[v.sector];
                      return <Icon className="h-3 w-3 shrink-0 text-brand/80" aria-hidden />;
                    })()}
                    <span className="truncate">
                      {lang === "ar" ? SECTOR_AR[v.sector] : sectorLabel(v.sector)}
                      {v.hotline ? ` · ${t("v.hotline")} ${v.hotline}` : ` · ${t("v.contact.na")}`}
                    </span>
                  </p>
                </div>
              </button>
            </Reveal>
          ))}
        </div>

          {limit < vendors.length && (
          <div className="mt-10 text-center">
            <button
              type="button"
              onClick={() => setLimit((l) => l + 12)}
              className="rounded-full border border-line bg-elev/70 px-8 py-3 text-sm font-bold text-fg transition-all hover:border-brand/50 active:scale-95"
            >
              {t("v.showmore")} ({vendors.length - limit})
            </button>
          </div>
        )}
      </div>

      <VendorModal vendor={active} onClose={() => setActive(null)} />
    </section>
  );
}

/* ----------------------- browse the catalogue (update: all vendors) ------- */

export function CategoriesSection() {
  const { db } = useStore();
  const { t, lang } = useLang();
  const [activeBrand, setActiveBrand] = useState<Vendor | null>(null);
  const [brandCategory, setBrandCategory] = useState<Category | null>(null);

  const go = (catId: string, subId?: string) => {
    window.dispatchEvent(new CustomEvent("iroopa:shop-filter", { detail: { catId, subId } }));
    document.getElementById("shop")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const cats = db.categories.filter((c) => !c.hidden);

  return (
    <section id="categories" className="relative pb-24 sm:pb-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-5">
          <div>
            <Reveal>
              <Eyebrow>{t("cat.eyebrow")}</Eyebrow>
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-5 font-display text-4xl font-bold tracking-[-0.02em] sm:text-5xl">
                {t("cat.title.a")} <span className="text-gradient">{t("cat.title.b")}</span>
              </h2>
            </Reveal>
          </div>
          <Reveal delay={0.14}>
            <p className="max-w-sm text-sm leading-relaxed text-fg2">{t("cat.sub")}</p>
          </Reveal>
        </div>

        <div className="mt-10 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3 xl:grid-cols-4">
          {cats.map((c, i) => {
            const subs = db.subcategories.filter((s) => s.catId === c.id && !s.hidden).slice(0, 3);
            const count = db.products.filter((p) => p.catId === c.id && !p.hidden).length;
            const Icon = SECTOR_ICON[c.slug as SectorKey] ?? ShoppingBag;
            return (
              <Reveal key={c.id} delay={0.04 * (i % 4)} className="h-full">
                <div className="card-surface card-spotlight group flex h-full flex-col overflow-hidden rounded-3xl transition-transform duration-500 hover:-translate-y-1">
                  <button type="button" onClick={() => go(c.id)} className="relative block aspect-[16/9] w-full overflow-hidden text-start">
                    <ImgWithFallback src={c.image} alt={c.name} letter={c.name[0]} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-transparent" />
                    <span className="absolute bottom-3 start-3 grid h-9 w-9 place-items-center rounded-xl border border-white/20 bg-black/40 text-white backdrop-blur-sm">
                      <Icon className="h-4 w-4" aria-hidden />
                    </span>
                    <span className="absolute bottom-3.5 end-3 rounded-full bg-black/45 px-2.5 py-1 text-[10px] font-bold text-white backdrop-blur-sm">
                      {count} {t("cat.items")}
                    </span>
                  </button>
                  <div className="flex flex-1 flex-col p-4">
                    <p className="text-sm font-bold text-fg">
                      {lang === "ar" ? SECTOR_AR[c.slug] ?? c.name : c.name}
                    </p>
                    <div className="mt-2.5 flex flex-wrap gap-1.5">
                      {subs.map((s) => (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => go(c.id, s.id)}
                          className="rounded-full border border-line bg-elev/60 px-2.5 py-1 text-[10px] font-semibold text-fg2 transition-all hover:border-brand/50 hover:text-brand"
                        >
                          {lang === "ar" ? SUB_AR[s.name] ?? s.name : s.name}
                        </button>
                      ))}
                      <button
                        type="button"
                        onClick={() => go(c.id)}
                        className="rounded-full px-2.5 py-1 text-[10px] font-bold text-brand transition-colors hover:text-fg"
                      >
                        {t("cat.viewall")} →
                      </button>
                    </div>

                    {/* Full brand list for this category — one shared popup profile. */}
                    <CategoryBrands
                      catSlug={c.slug}
                      onOpen={(vendor) => setActiveBrand(vendor)}
                      onBrowseAll={() => setBrandCategory(c)}
                    />
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
      <VendorModal vendor={activeBrand} onClose={() => setActiveBrand(null)} />
      <CategoryDirectoryModal
        category={brandCategory}
        onClose={() => setBrandCategory(null)}
        onOpen={(vendor) => {
          setBrandCategory(null);
          window.setTimeout(() => setActiveBrand(vendor), 180);
        }}
      />
    </section>
  );
}

function CategoryBrands({
  catSlug,
  onOpen,
  onBrowseAll,
}: {
  catSlug: string;
  onOpen: (vendor: Vendor) => void;
  onBrowseAll: () => void;
}) {
  const { db } = useStore();
  const { t } = useLang();
  const sector = catSlug as SectorKey;
  const brands = useMemo(
    () =>
      db.vendors
        .filter((v) => v.sector === sector && !v.hidden)
        .sort((a, b) => a.order - b.order),
    [db.vendors, sector]
  );

  if (!brands.length) {
    return (
      <p className="mt-4 rounded-xl border border-dashed border-line2 px-3 py-2 text-center text-[10px] font-semibold text-fg3">
        {t("v.contact.na")}
      </p>
    );
  }

  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const scrollBy = (dir: number) => {
    scrollContainerRef.current?.scrollBy({ left: dir * 240, behavior: "smooth" });
  };

  return (
    <div className="mt-4 border-t border-line pt-3.5">
      <div className="mb-2 flex items-center justify-between">
        <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-fg3">
          {t("cat.brands")}
        </p>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => scrollBy(-1)}
            className="grid h-6 w-6 place-items-center rounded-full border border-line bg-elev/60 text-fg3 transition-colors hover:border-brand/50 hover:text-fg"
            aria-label="Scroll brands left"
          >
            <ChevronLeft className="h-3.5 w-3.5" aria-hidden />
          </button>
          <button
            type="button"
            onClick={() => scrollBy(1)}
            className="grid h-6 w-6 place-items-center rounded-full border border-line bg-elev/60 text-fg3 transition-colors hover:border-brand/50 hover:text-fg"
            aria-label="Scroll brands right"
          >
            <ChevronRight className="h-3.5 w-3.5" aria-hidden />
          </button>
          <span className="rounded-full bg-brand/10 px-2 py-0.5 text-[9px] font-bold text-brand">
            {brands.length}
          </span>
        </div>
      </div>
      <div ref={scrollContainerRef} className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto scroll-smooth px-1 pb-1" role="list">
        {brands.map((brand) => {
          const status = brand.linkStatus ?? (vendorHost(brand.website) ? "fresh" : "unverified");
          return (
            <button
              key={brand.id}
              type="button"
              role="listitem"
              onClick={() => onOpen(brand)}
              title={`${brand.name} · ${
                status === "fresh"
                  ? t("v.links.fresh")
                  : status === "stale"
                    ? t("v.links.stale")
                    : t("v.links.unverified")
              }`}
              className="group/brand flex w-[104px] shrink-0 flex-col items-center gap-1.5 rounded-2xl border border-line bg-elev/50 px-2 py-2 text-center transition-all duration-300 hover:-translate-y-0.5 hover:border-brand/45"
            >
              <span className="relative">
                <VendorLogo vendor={brand} size={32} />
                <span
                  className={cn(
                    "absolute -bottom-0.5 -end-0.5 h-2.5 w-2.5 rounded-full border border-panel",
                    status === "fresh"
                      ? "bg-brand"
                      : status === "stale"
                        ? "bg-gold"
                        : "bg-line2"
                  )}
                  aria-hidden
                />
              </span>
              <span className="w-full truncate text-[9.5px] font-bold text-fg" dir="ltr">
                {brand.name}
              </span>
              <span className="w-full truncate text-[8px] text-fg3">
                {brand.entityKind === "manufacturer"
                  ? t("v.entity.manufacturer")
                  : status === "fresh"
                    ? t("v.links.fresh")
                    : t("v.links.unverified")}
              </span>
            </button>
          );
        })}
      </div>
      {brands.length > 8 && (
        <button
          type="button"
          onClick={onBrowseAll}
          className="mt-2.5 inline-flex w-full items-center justify-center gap-1.5 rounded-xl border border-brand/30 bg-brand/[0.06] px-3 py-2 text-[10px] font-bold text-brand transition-colors hover:border-brand/55"
        >
          <Search className="h-3 w-3" aria-hidden /> {t("v.allbrands")} ({brands.length})
        </button>
      )}
    </div>
  );
}

function CategoryDirectoryModal({
  category,
  onClose,
  onOpen,
}: {
  category: Category | null;
  onClose: () => void;
  onOpen: (vendor: Vendor) => void;
}) {
  const { db } = useStore();
  const { t, lang } = useLang();
  const [query, setQuery] = useState("");
  const [segment, setSegment] = useState<string>("all");

  useEffect(() => {
    setQuery("");
    setSegment("all");
  }, [category?.id]);

  const brands = useMemo(() => {
    if (!category) return [];
    const q = query.trim().toLowerCase();
    return db.vendors
      .filter((v) => v.sector === category.slug && !v.hidden)
      .filter((v) => segment === "all" || v.subId === segment)
      .filter((v) => !q || v.name.toLowerCase().includes(q))
      .sort((a, b) => {
        const aRank = a.linkStatus === "fresh" ? 0 : a.linkStatus === "stale" ? 1 : 2;
        const bRank = b.linkStatus === "fresh" ? 0 : b.linkStatus === "stale" ? 1 : 2;
        return aRank - bRank || a.name.localeCompare(b.name);
      });
  }, [category, db.vendors, query, segment]);

  const allCount = category
    ? db.vendors.filter((v) => v.sector === category.slug && !v.hidden).length
    : 0;
  const subcategories = category
    ? db.subcategories.filter((s) => s.catId === category.id && !s.hidden)
    : [];

  const openSubcategory = (subId: string) => {
    if (!category) return;
    onClose();
    window.setTimeout(() => {
      window.dispatchEvent(
        new CustomEvent("iroopa:shop-filter", {
          detail: { catId: category.id, subId },
        })
      );
      document.getElementById("shop")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 180);
  };

  return (
    <Modal open={!!category} onClose={onClose} size="lg" resizable chrome labelledBy="category-brand-directory">
      <div className="p-6 sm:p-7">
        <div className="pe-10">
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-brand">
            {t("cat.brands")} · {allCount} {t("v.brandcount")}
          </p>
          <h2 id="category-brand-directory" className="mt-1 font-display text-2xl font-bold">
            {category ? (lang === "ar" ? SECTOR_AR[category.slug] ?? category.name : category.name) : ""}
          </h2>
          <p className="mt-1 text-xs leading-relaxed text-fg3">
            {lang === "ar"
              ? "الحسابات والروابط الموثّقة تظهر أولًا. ملفات البحث تبقى واضحة كبيانات غير مكتملة."
              : "Verified profiles appear first. Research entries remain visible and clearly marked as incomplete."}
          </p>
        </div>

        <div className="relative mt-5">
          <Search className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg3" aria-hidden />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t("v.searchbrands")}
            className="w-full rounded-full border border-line bg-ink/60 py-2.5 pe-4 ps-10 text-sm text-fg outline-none transition-colors placeholder:text-fg3 focus:border-brand/60"
            autoFocus
          />
        </div>

        {subcategories.length > 0 && (
          <div className="no-scrollbar mt-3 flex gap-1.5 overflow-x-auto pb-1">
            <button
              type="button"
              onClick={() => setSegment("all")}
              className={cn(
                "shrink-0 rounded-full border px-3 py-1.5 text-[10px] font-bold transition-all",
                segment === "all"
                  ? "border-transparent bg-gradient-to-r from-brand to-brand-deep text-onbrand"
                  : "border-line bg-elev/50 text-fg2 hover:border-brand/45 hover:text-brand"
              )}
            >
              {t("v.all")}
            </button>
            {subcategories.map((sub) => {
              const brandCount = db.vendors.filter(
                (v) => v.subId === sub.id && !v.hidden
              ).length;
              return (
                <button
                  key={sub.id}
                  type="button"
                  onClick={() => setSegment((s) => (s === sub.id ? "all" : sub.id))}
                  onDoubleClick={() => openSubcategory(sub.id)}
                  title={t("cat.viewall")}
                  className={cn(
                    "shrink-0 rounded-full border px-3 py-1.5 text-[10px] font-semibold transition-all",
                    segment === sub.id
                      ? "border-transparent bg-gradient-to-r from-brand to-brand-deep text-onbrand"
                      : "border-line bg-elev/50 text-fg2 hover:border-brand/45 hover:text-brand"
                  )}
                >
                  {lang === "ar" ? SUB_AR[sub.name] ?? sub.name : sub.name} · {brandCount}
                </button>
              );
            })}
          </div>
        )}
        {segment !== "all" && (
          <button
            type="button"
            onClick={() => openSubcategory(segment)}
            className="mt-2 inline-flex items-center gap-1.5 text-[10px] font-bold text-brand hover:text-fg"
          >
            {t("cat.viewall")} →
          </button>
        )}

        <div className="mt-5 grid max-h-[58dvh] grid-cols-2 gap-3 overflow-y-auto pe-1 sm:grid-cols-3 lg:grid-cols-4">
          {brands.map((brand) => {
            const status = brand.linkStatus ?? (vendorHost(brand.website) ? "fresh" : "unverified");
            const kind = brand.entityKind ?? (vendorHost(brand.website) ? "official" : "marketplace");
            return (
              <button
                key={brand.id}
                type="button"
                onClick={() => onOpen(brand)}
                className="group flex min-w-0 flex-col items-start rounded-2xl border border-line bg-elev/45 p-3 text-start transition-all duration-300 hover:-translate-y-0.5 hover:border-brand/45"
              >
                <div className="flex w-full items-start gap-2.5">
                  <VendorLogo vendor={brand} size={42} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-bold text-fg" dir="ltr">{brand.name}</p>
                          <p className="mt-0.5 truncate text-[9px] text-fg3">
                      {kind === "manufacturer"
                        ? t("v.entity.manufacturer")
                        : kind === "store"
                          ? t("v.entity.store")
                          : kind === "marketplace"
                            ? t("v.entity.marketplace")
                            : t("v.entity.brand")}
                    </p>
                  </div>
                </div>
                <div className="mt-3 flex w-full items-center justify-between gap-1.5">
                  <span
                    className={cn(
                      "rounded-full border px-2 py-0.5 text-[8px] font-bold",
                      status === "fresh"
                        ? "border-brand/30 bg-brand/10 text-brand"
                        : status === "stale"
                          ? "border-gold/30 bg-gold/10 text-gold"
                          : "border-line text-fg3"
                    )}
                  >
                    {status === "fresh"
                      ? t("v.links.fresh")
                      : status === "stale"
                        ? t("v.links.stale")
                        : t("v.links.unverified")}
                  </span>
                  <span className="text-[9px] font-bold text-brand transition-transform group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5">
                    {t("cat.viewall")} →
                  </span>
                </div>
              </button>
            );
          })}
        </div>
        {!brands.length && (
          <p className="py-10 text-center text-sm text-fg3">{t("v.contact.na")}</p>
        )}
      </div>
    </Modal>
  );
}
