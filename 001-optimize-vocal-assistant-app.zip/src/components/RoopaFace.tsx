import { memo, useEffect, useRef } from "react";
import type { AsstState } from "../lib/speech";

interface Props {
  levelRef: React.MutableRefObject<number>;
  state: AsstState;
  size?: number;
}

/** Photorealistic presenter with amplitude-reactive frame and voice meter. */
export const RoopaFace = memo(function RoopaFace({ levelRef, state, size = 80 }: Props) {
  const shellRef = useRef<HTMLDivElement>(null);
  const meterRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    let raf = 0;
    const bars = meterRef.current
      ? (Array.from(meterRef.current.children) as HTMLElement[])
      : [];
    const tick = (time: number) => {
      raf = requestAnimationFrame(tick);
      const level = Math.min(1, levelRef.current);
      const active = stateRef.current === "speaking" || stateRef.current === "listening";
      const breath = 1 + Math.sin(time / 1150) * 0.012;
      if (shellRef.current) {
        shellRef.current.style.transform = `translateY(${Math.sin(time / 1450) * 1.8}px) scale(${breath + (active ? level * 0.045 : 0)})`;
      }
      bars.forEach((bar, i) => {
        const wave = 0.34 + Math.abs(Math.sin(time / (155 + i * 19) + i * 1.15)) * 0.66;
        bar.style.transform = `scaleY(${active ? Math.max(0.24, wave * (0.38 + level * 1.15)) : 0.24})`;
      });
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [levelRef]);

  const accent =
    state === "speaking"
      ? "var(--c-violet)"
      : state === "processing"
        ? "var(--c-gold)"
        : "var(--c-brand)";
  const active = state === "speaking" || state === "listening";

  return (
    <div
      className="relative"
      style={{ width: size, height: size }}
      role="img"
      aria-label="Roopa, your female AI voice assistant"
    >
      <span
        className="absolute -inset-2 rounded-full border opacity-60"
        style={{
          borderColor: accent,
          boxShadow: `0 0 24px color-mix(in oklab, ${accent} 42%, transparent)`,
          animation: active ? "pulse-ring 1.9s ease-out infinite" : "none",
        }}
        aria-hidden
      />

      <div
        ref={shellRef}
        className="absolute inset-0 overflow-hidden rounded-full border-2 bg-panel shadow-2xl will-change-transform"
        style={{
          borderColor: accent,
          boxShadow: `0 10px 30px -8px color-mix(in oklab, ${accent} 60%, transparent)`,
        }}
      >
        <img
          src="/images/roopa-realistic.png"
          alt="Photorealistic portrait of Roopa"
          width={size}
          height={size}
          decoding="async"
          className="h-full w-full object-cover object-center"
        />
        <span
          className="pointer-events-none absolute inset-0 opacity-20 mix-blend-color"
          style={{ background: accent }}
          aria-hidden
        />
        <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/35 via-transparent to-white/10" aria-hidden />
      </div>

      <div
        ref={meterRef}
        className="absolute -bottom-1 start-1/2 flex h-4 -translate-x-1/2 items-center gap-[2px] rounded-full border border-white/15 bg-black/65 px-2 py-1 shadow-lg backdrop-blur-md rtl:translate-x-1/2"
        aria-hidden
      >
        {[0, 1, 2, 3, 4].map((i) => (
          <span
            key={i}
            className="block h-2.5 w-[2px] origin-center rounded-full will-change-transform"
            style={{ background: accent }}
          />
        ))}
      </div>

      {state === "speaking" && (
        <svg className="absolute -end-5 top-1/2 h-8 w-7 -translate-y-1/2 overflow-visible" viewBox="0 0 28 32" fill="none" aria-hidden>
          <path d="M3 10c4 3.5 4 8.5 0 12" stroke={accent} strokeWidth="2" strokeLinecap="round" className="animate-pulse" />
          <path d="M9 5c7 6 7 16 0 22" stroke={accent} strokeWidth="1.5" strokeLinecap="round" opacity="0.55" className="animate-pulse [animation-delay:220ms]" />
        </svg>
      )}

      <span
        className="absolute end-0 top-0 h-3 w-3 rounded-full border-2 border-panel"
        style={{ background: active ? accent : "var(--c-brand)" }}
        aria-hidden
      />
    </div>
  );
});