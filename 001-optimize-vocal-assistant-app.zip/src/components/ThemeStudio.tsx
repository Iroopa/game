import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, BadgeCheck, Check, Download, Palette, RotateCcw, ShoppingCart, SlidersHorizontal } from "lucide-react";
import { POOLS, pick } from "../lib/media";
import { THEMES, themeById } from "../lib/themes";
import { fmtEGP, useStore } from "../lib/store";
import { useLang } from "../lib/i18n";
import { ImgWithFallback, Modal, downloadJSON } from "./ui";
import { Reveal } from "./Reveal";
import { cn } from "../utils/cn";

/* --------------------------- theme studio modal --------------------------- */

export function ThemeStudioModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { db, setActiveTheme, resetAll } = useStore();
  const { t } = useLang();

  return (
    <Modal open={open} onClose={onClose} wide labelledBy="studio-title">
      <div className="p-6 sm:p-8">
        <p className="inline-flex items-center gap-2 rounded-full border border-line bg-elev/70 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-brand">
          <Palette className="h-3 w-3" aria-hidden /> {t("st.studio")}
        </p>
        <p id="studio-title" className="mt-4 font-display text-2xl font-bold tracking-tight sm:text-3xl">
          {t("st.title")}
        </p>
        <p className="mt-1.5 text-sm text-fg2">{t("st.sub")}</p>

        <div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {THEMES.map((th) => {
            const active = db.activeTheme === th.id;
            return (
              <button
                key={th.id}
                type="button"
                onClick={() => setActiveTheme(th.id)}
                className={cn(
                  "group relative overflow-hidden rounded-2xl border p-4 text-start transition-all duration-300 hover:-translate-y-0.5",
                  active ? "border-brand shadow-[0_0_0_3px_color-mix(in_oklab,var(--c-brand)_25%,transparent)]" : "border-line bg-elev/40 hover:border-brand/40"
                )}
              >
                {/* mini preview */}
                <div className="relative overflow-hidden rounded-xl border border-line/60" style={{ background: th.swatches[0] }}>
                  <div className="h-1.5 w-full" style={{ background: `linear-gradient(90deg, ${th.swatches[1]}, ${th.swatches[2]})` }} />
                  <div className="space-y-1.5 p-3">
                    <div className="h-2 w-3/5 rounded-full" style={{ background: th.swatches[1] }} />
                    <div className="h-1.5 w-4/5 rounded-full opacity-50" style={{ background: th.swatches[3] }} />
                    <div className="flex gap-1.5 pt-1">
                      <span className="h-5 w-10 rounded-full" style={{ background: th.swatches[1] }} />
                      <span className="h-5 w-14 rounded-full border" style={{ borderColor: th.swatches[2] }} />
                    </div>
                  </div>
                  {active && (
                    <span className="absolute end-2 top-3 grid h-6 w-6 place-items-center rounded-full bg-brand text-onbrand">
                      <Check className="h-3.5 w-3.5" aria-hidden />
                    </span>
                  )}
                </div>
                <p className="mt-3 flex items-center justify-between text-sm font-bold text-fg">
                  {th.name}
                  {th.dark ? (
                    <span className="rounded-full border border-line px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-fg3">{t("st.dark")}</span>
                  ) : (
                    <span className="rounded-full border border-gold/40 bg-gold/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-gold">{t("st.light")}</span>
                  )}
                </p>
                <p className="mt-1 line-clamp-2 text-[11px] leading-relaxed text-fg3">{th.tagline}</p>
              </button>
            );
          })}

          {/* customize card */}
          <a
            href="#/dashboard/themes"
            onClick={onClose}
            className="group flex min-h-[168px] flex-col items-center justify-center gap-2.5 rounded-2xl border border-dashed border-line2 p-4 text-center transition-all hover:border-brand/50 hover:bg-elev/40"
          >
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-brand to-accent text-onbrand">
              <SlidersHorizontal className="h-5 w-5" aria-hidden />
            </span>
            <p className="text-sm font-bold text-fg">{t("st.editor")}</p>
            <p className="text-[11px] leading-relaxed text-fg3">{t("st.editor.sub")}</p>
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-brand">
              {t("st.godash")} <ArrowUpRight className="h-3 w-3 rtl:rotate-[-90deg]" aria-hidden />
            </span>
          </a>
        </div>

        <div className="mt-7 flex flex-wrap items-center gap-2.5 border-t border-line pt-5">
          <button
            type="button"
            onClick={() =>
              downloadJSON(`iroopa-theme-${db.activeTheme}.json`, db.overrides[db.activeTheme] ?? themeById(db.activeTheme))
            }
            className="inline-flex items-center gap-2 rounded-full border border-line bg-elev/70 px-4 py-2 text-xs font-bold text-fg transition-colors hover:border-brand/50"
          >
            <Download className="h-3.5 w-3.5 text-brand" aria-hidden /> {t("st.export")}
          </button>
          <button
            type="button"
            onClick={resetAll}
            className="inline-flex items-center gap-2 rounded-full border border-line bg-elev/70 px-4 py-2 text-xs font-bold text-fg2 transition-colors hover:border-rose-400/40 hover:text-rose-400"
          >
            <RotateCcw className="h-3.5 w-3.5" aria-hidden /> {t("st.resetall")}
          </button>
          <span className="ms-auto flex items-center gap-1.5 text-[10px] font-semibold text-fg3">
            <BadgeCheck className="h-3.5 w-3.5 text-brand" aria-hidden /> {t("st.applied")}
          </span>
        </div>
      </div>
    </Modal>
  );
}

/* ------------------------------ spotlight band ---------------------------- */

export function ThemeSpotlight() {
  const { db, activeThemeDef, featuredFor, addToCart } = useStore();
  const { t } = useLang();
  const [studioOpen, setStudioOpen] = useState(false);
  const override = db.overrides[activeThemeDef.id];
  const spot = {
    kicker: override?.spotlight?.kicker ?? activeThemeDef.spotlight.kicker,
    title: override?.spotlight?.title ?? activeThemeDef.spotlight.title,
    desc: override?.spotlight?.desc ?? activeThemeDef.spotlight.desc,
    img: override?.spotlight?.img || pick(POOLS[activeThemeDef.spotlight.pool], activeThemeDef.spotlight.imgIdx),
  };
  const featured = featuredFor(activeThemeDef.id);

  /* global "open studio" requests (navbar palette button) */
  useEffect(() => {
    const open = () => setStudioOpen(true);
    window.addEventListener("iroopa:studio", open);
    return () => window.removeEventListener("iroopa:studio", open);
  }, []);

  return (
    <section id="spotlight" className="relative py-14 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <div className="card-surface noise relative overflow-hidden rounded-[28px]">
            <div className="grid items-stretch lg:grid-cols-[1.15fr_0.85fr]">
              <div className="relative p-7 sm:p-10">
                <div
                  aria-hidden
                  className="pointer-events-none absolute -start-20 -top-24 h-72 w-72 rounded-full opacity-25 blur-3xl"
                  style={{ background: "var(--c-brand)" }}
                />
                <div className="relative">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="inline-flex items-center gap-2 rounded-full border border-brand/40 bg-brand/10 px-3.5 py-1.5 text-[10px] font-bold uppercase tracking-widest text-brand">
                      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-brand" aria-hidden />
                      {spot.kicker}
                    </span>
                    <button
                      type="button"
                      onClick={() => setStudioOpen(true)}
                      className="inline-flex items-center gap-1.5 rounded-full border border-line bg-elev/70 px-3.5 py-1.5 text-[10px] font-bold uppercase tracking-widest text-fg2 transition-all hover:border-brand/50 hover:text-fg"
                    >
                      <Palette className="h-3 w-3 text-brand" aria-hidden /> {t("st.customize")}
                    </button>
                  </div>
                  <h2 className="mt-5 max-w-lg font-display text-3xl font-bold leading-[1.08] tracking-[-0.02em] sm:text-4xl">
                    {spot.title}
                  </h2>
                  <p className="mt-3.5 max-w-md text-sm leading-relaxed text-fg2 sm:text-base">{spot.desc}</p>

                  {/* featured trio */}
                  <div className="mt-7 grid gap-3 sm:grid-cols-3">
                    {featured.map((p, i) => (
                      <motion.div
                        key={p.id}
                        initial={{ opacity: 0, y: 18 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.12 + i * 0.1, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                        className="group overflow-hidden rounded-2xl border border-line bg-elev/60"
                      >
                        <div className="h-20 overflow-hidden">
                          <ImgWithFallback src={p.img} alt={p.name} letter={p.name[0]} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        </div>
                        <div className="p-3">
                          <p className="line-clamp-1 text-[11px] font-bold text-fg">{p.name}</p>
                          <div className="mt-1.5 flex items-center justify-between gap-1">
                            <span className="text-xs font-bold text-brand">{fmtEGP(p.sale ?? p.price)}</span>
                            <button
                              type="button"
                              onClick={() => addToCart(p.id)}
                              aria-label={`Add ${p.name} to cart`}
                              className="grid h-7 w-7 place-items-center rounded-full bg-gradient-to-r from-brand to-brand-deep text-onbrand transition-all hover:scale-110 active:scale-90"
                            >
                              <ShoppingCart className="h-3 w-3" aria-hidden />
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="relative min-h-[220px] overflow-hidden lg:min-h-full">
                <ImgWithFallback
                  src={spot.img}
                  alt={spot.title}
                  letter="S"
                  className="absolute inset-0 h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-panel via-panel/25 to-transparent lg:bg-[linear-gradient(to_right,var(--c-panel)_0%,transparent_45%)]" />
                <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-panel/90 to-transparent lg:hidden" />
              </div>
            </div>
          </div>
        </Reveal>
      </div>
      <ThemeStudioModal open={studioOpen} onClose={() => setStudioOpen(false)} />
    </section>
  );
}
