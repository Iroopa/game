import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Languages, Menu, Moon, Palette, Sun, X } from "lucide-react";
import { useLang, type DictKey } from "../lib/i18n";
import type { RouteName } from "../lib/router-types";
import { DarkWoodButton } from "./ui/dark-wood-button";
import { cn } from "../utils/cn";

const LINKS: { key: DictKey; href: string }[] = [
  { key: "nav.services", href: "#services" },
  { key: "nav.languages", href: "#languages" },
];

const SECTION_LINKS: { key: DictKey; href: string }[] = [
  { key: "nav.vendors", href: "#vendors" },
  { key: "nav.catalogue", href: "#categories" },
  { key: "nav.shop", href: "#shop" },
  { key: "nav.demo", href: "#demo" },
];

interface Props {
  theme: "dark" | "light";
  onToggleTheme: () => void;
  route: RouteName;
}

export function Logo() {
  return (
    <span className="flex items-center gap-2.5">
      <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-brand to-accent shadow-[0_6px_18px_-4px_color-mix(in_oklab,var(--c-brand)_60%,transparent)]">
        <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" fill="none" aria-hidden>
          <g fill="var(--c-onbrand)">
            <rect x="3.5" y="9" width="3" height="6" rx="1.5" />
            <rect x="8.5" y="5.5" width="3" height="13" rx="1.5" />
            <rect x="13.5" y="8" width="3" height="8" rx="1.5" />
            <rect x="17.5" y="4" width="3" height="16" rx="1.5" />
          </g>
        </svg>
      </span>
      <span className="text-lg font-bold tracking-tight">
        i<span className="text-gradient">Roopa</span>
      </span>
    </span>
  );
}

export function Navbar({ theme, onToggleTheme, route }: Props) {
  const { t, toggleLang, lang } = useLang();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 14);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled
          ? "glass border-b border-line py-2.5 shadow-[0_10px_40px_-20px_rgba(0,0,0,0.5)]"
          : "border-b border-transparent py-5"
      )}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <a href="#top" aria-label="iRoopa home">
          <Logo />
        </a>

        {/* desktop nav */}
        <nav className="hidden items-center gap-6 lg:flex" aria-label="Primary">
          {SECTION_LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="group relative text-[13px] font-medium text-fg2 transition-colors duration-300 hover:text-fg"
            >
              {t(l.key)}
              <span className="absolute -bottom-1 start-0 h-px w-0 bg-brand transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
          {LINKS.map((l) => (
            <a
              key={l.key}
              href={l.href}
              className="group relative text-[13px] font-medium text-fg2 transition-colors duration-300 hover:text-fg"
            >
              {t(l.key)}
              <span className="absolute -bottom-1 start-0 h-px w-0 bg-brand transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
          <a
            href="#/showcase"
            className="group relative text-[13px] font-medium text-accent transition-colors duration-300 hover:text-fg"
          >
            {t("nav.showcase")}
            <span className="absolute -bottom-1 start-0 h-px w-0 bg-accent transition-all duration-300 group-hover:w-full" />
          </a>
          <a
            href="#/dashboard"
            className={cn(
              "group relative text-[13px] font-medium transition-colors duration-300",
              route === "dashboard" ? "text-brand" : "text-fg2 hover:text-fg"
            )}
          >
            {t("nav.dashboard")}
            <span className="absolute -bottom-1 start-0 h-px w-0 bg-brand transition-all duration-300 group-hover:w-full" />
          </a>
        </nav>

        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            type="button"
            onClick={() => window.dispatchEvent(new CustomEvent("iroopa:studio"))}
            className="grid h-8.5 w-8.5 place-items-center rounded-full border border-line bg-elev/70 text-fg2 transition-all duration-300 hover:border-brand/50 hover:text-brand"
            aria-label="Open theme studio"
            title="Theme Studio"
          >
            <Palette className="h-4 w-4" aria-hidden />
          </button>
          <button
            type="button"
            onClick={toggleLang}
            className="flex items-center gap-1.5 rounded-full border border-line bg-elev/70 px-3 py-1.5 text-xs font-semibold text-fg2 transition-all duration-300 hover:border-brand/50 hover:text-fg"
            aria-label="Switch language"
          >
            <Languages className="h-3.5 w-3.5" aria-hidden />
            {lang === "en" ? "العربية" : "English"}
          </button>
          <button
            type="button"
            onClick={onToggleTheme}
            className="grid h-8.5 w-8.5 place-items-center rounded-full border border-line bg-elev/70 text-fg2 transition-all duration-300 hover:border-brand/50 hover:text-fg"
            aria-label="Toggle theme"
          >
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={theme}
                initial={{ rotate: -60, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 60, opacity: 0 }}
                transition={{ duration: 0.25 }}
                className="grid place-items-center"
              >
                {theme === "dark" ? (
                  <Sun className="h-4 w-4" aria-hidden />
                ) : (
                  <Moon className="h-4 w-4" aria-hidden />
                )}
              </motion.span>
            </AnimatePresence>
          </button>
          <div className="hidden sm:block">
            <DarkWoodButton
              label={t("nav.cta")}
              onClick={() => {
                document.getElementById("cta")?.scrollIntoView({ behavior: "smooth", block: "start" });
              }}
            />
          </div>
          <button
            type="button"
            className="grid h-8.5 w-8.5 place-items-center rounded-full border border-line bg-elev/70 text-fg2 lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
            aria-expanded={open}
          >
            {open ? <X className="h-4.5 w-4.5" aria-hidden /> : <Menu className="h-4.5 w-4.5" aria-hidden />}
          </button>
        </div>
      </div>

      {/* mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.nav
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
            className="glass mx-4 mt-2 rounded-2xl border border-line p-2 lg:hidden"
            aria-label="Mobile"
          >
            {SECTION_LINKS.map((l) => (
              <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="block rounded-xl px-4 py-3 text-sm font-medium text-fg2 transition-colors hover:bg-elev hover:text-fg">
                {t(l.key)}
              </a>
            ))}
            {LINKS.map((l) => (
              <a key={l.key} href={l.href} onClick={() => setOpen(false)} className="block rounded-xl px-4 py-3 text-sm font-medium text-fg2 transition-colors hover:bg-elev hover:text-fg">
                {t(l.key)}
              </a>
            ))}
            <a href="#/showcase" onClick={() => setOpen(false)} className="block rounded-xl px-4 py-3 text-sm font-medium text-accent hover:bg-elev">
              {t("nav.showcase")}
            </a>
            <a href="#/dashboard" onClick={() => setOpen(false)} className="block rounded-xl px-4 py-3 text-sm font-medium text-fg2 hover:bg-elev hover:text-fg">
              {t("nav.dashboard")}
            </a>
            <a
              href="#cta"
              onClick={() => setOpen(false)}
              className="mt-1 block rounded-xl bg-gradient-to-r from-brand to-brand-deep px-4 py-3 text-center text-sm font-bold text-onbrand"
            >
              {t("nav.cta")}
            </a>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
