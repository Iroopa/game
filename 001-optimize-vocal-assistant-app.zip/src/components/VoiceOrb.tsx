import { memo, useEffect, useRef } from "react";
import type { AsstState } from "../lib/speech";

interface Props {
  levelRef: React.MutableRefObject<number>;
  state: AsstState;
  size?: number;
  className?: string;
}

/* palette per assistant state, as [r,g,b] */
const PALETTE: Record<AsstState, { core: number[]; mid: number[]; outer: number[] }> = {
  idle: { core: [52, 211, 153], mid: [45, 212, 191], outer: [16, 185, 129] },
  listening: { core: [110, 231, 183], mid: [52, 211, 153], outer: [13, 148, 116] },
  processing: { core: [242, 185, 104], mid: [245, 158, 11], outer: [217, 119, 6] },
  speaking: { core: [167, 139, 250], mid: [139, 92, 246], outer: [99, 102, 241] },
};

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const mix = (a: number[], b: number[], t: number) => [
  lerp(a[0], b[0], t),
  lerp(a[1], b[1], t),
  lerp(a[2], b[2], t),
];
const rgb = (c: number[], alpha = 1) =>
  `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${alpha})`;

const BARS = 44;

export const VoiceOrb = memo(function VoiceOrb({
  levelRef,
  state,
  size = 210,
  className,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef<AsstState>(state);
  const curRef = useRef(PALETTE.idle.core);

  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    let raf = 0;
    let inView = true;
    let visible = !document.hidden;
    let w = 0;
    let h = 0;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
      const rect = canvas.getBoundingClientRect();
      w = rect.width;
      h = rect.height;
      canvas.width = Math.max(1, Math.round(w * dpr));
      canvas.height = Math.max(1, Math.round(h * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();

    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    const io = new IntersectionObserver(([e]) => (inView = e.isIntersecting), {
      threshold: 0.01,
    });
    io.observe(canvas);
    const onVis = () => (visible = !document.hidden);
    document.addEventListener("visibilitychange", onVis);

    const draw = (t: number) => {
      raf = requestAnimationFrame(draw);
      if (!inView || !visible) return;
      const level = Math.min(1, levelRef.current);
      const pal = PALETTE[stateRef.current];
      const cur = curRef.current;
      /* ease the palette toward the active state's core color */
      for (let i = 0; i < 3; i++) cur[i] = lerp(cur[i], pal.core[i], 0.06);
      const mid = mix(cur, pal.mid, 0.45);
      const outer = mix(cur, pal.outer, 0.55);

      const cx = w / 2;
      const cy = h / 2;
      const base = Math.min(w, h) * 0.5;
      ctx.clearRect(0, 0, w, h);

      /* ---------- ambient halo ---------- */
      const haloR = base * (0.98 + level * 0.1);
      const halo = ctx.createRadialGradient(cx, cy, base * 0.2, cx, cy, haloR);
      halo.addColorStop(0, rgb(mid, 0.32 + level * 0.18));
      halo.addColorStop(0.62, rgb(outer, 0.1));
      halo.addColorStop(1, rgb(outer, 0));
      ctx.fillStyle = halo;
      ctx.beginPath();
      ctx.arc(cx, cy, haloR, 0, Math.PI * 2);
      ctx.fill();

      /* ---------- orbiting arcs ---------- */
      if (!reduced) {
        ctx.save();
        ctx.lineCap = "round";
        const rot = t / 2600;
        for (let k = 0; k < 2; k++) {
          ctx.beginPath();
          ctx.lineWidth = 1.4 - k * 0.5;
          ctx.strokeStyle = rgb(outer, 0.28 - k * 0.12);
          const r = base * (0.86 + k * 0.075);
          const dir = k === 0 ? 1 : -1;
          ctx.arc(cx, cy, r, rot * dir + k, rot * dir + k + Math.PI * (1.1 - k * 0.28));
          ctx.stroke();
        }
        ctx.restore();
      }

      /* ---------- reactive needle bars ---------- */
      const spokes = BARS;
      const innerR = base * (0.52 + level * 0.03);
      for (let i = 0; i < spokes; i++) {
        const a = (i / spokes) * Math.PI * 2 + (reduced ? 0 : t / 9000);
        const wob =
          Math.sin(t / 340 + i * 0.64) * 0.5 +
          Math.sin(t / 178 + i * 1.71) * 0.35 +
          0.6;
        const len = base * (0.05 + level * (0.16 + 0.3 * wob * wob * 0.55));
        const x1 = cx + Math.cos(a) * innerR;
        const y1 = cy + Math.sin(a) * innerR;
        const x2 = cx + Math.cos(a) * (innerR + len);
        const y2 = cy + Math.sin(a) * (innerR + len);
        ctx.beginPath();
        ctx.lineWidth = 1.6;
        ctx.strokeStyle = rgb(mix(cur, mid, i % 3 === 0 ? 0.85 : 0.35), 0.5 + level * 0.45);
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }

      /* ---------- core blob ---------- */
      const wobble =
        1 + level * 0.16 + (reduced ? 0 : Math.sin(t / 620) * 0.028);
      const coreR = base * 0.4 * wobble;
      const g = ctx.createRadialGradient(
        cx - coreR * 0.36,
        cy - coreR * 0.4,
        coreR * 0.12,
        cx,
        cy,
        coreR * 1.55
      );
      g.addColorStop(0, "rgba(255,255,255,0.92)");
      g.addColorStop(0.22, rgb(cur, 0.95));
      g.addColorStop(0.62, rgb(mid, 0.75));
      g.addColorStop(1, rgb(outer, 0));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(cx, cy, coreR * 1.5, 0, Math.PI * 2);
      ctx.fill();

      /* glass specular dot */
      ctx.beginPath();
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.arc(cx - coreR * 0.34, cy - coreR * 0.42, coreR * 0.13, 0, Math.PI * 2);
      ctx.fill();
    };

    raf = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [levelRef]);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      style={{ width: size, height: size }}
      aria-hidden="true"
    />
  );
});
