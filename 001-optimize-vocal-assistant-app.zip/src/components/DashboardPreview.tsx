import { useEffect, useRef, useState } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";
import {
  Activity,
  BadgeCheck,
  Bell,
  Clock3,
  HeartHandshake,
  HourglassIcon,
  Mic,
  Search,
  TrendingUp,
  type LucideIcon,
} from "lucide-react";
import { useLang } from "../lib/i18n";
import { Eyebrow, Reveal } from "./Reveal";

/* ------------------------------ count-up ------------------------------ */

function useCountUp(target: number, started: boolean, duration = 1600) {
  const [val, setVal] = useState(0);
  const reduced = useReducedMotion();
  useEffect(() => {
    if (!started) return;
    if (reduced) {
      setVal(target);
      return;
    }
    let raf = 0;
    const t0 = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - t0) / duration);
      const eased = 1 - Math.pow(1 - p, 4);
      setVal(target * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [started, target, duration, reduced]);
  return val;
}

/* --------------------------------- data --------------------------------- */

interface FeedItem {
  icon: LucideIcon;
  status: "done" | "scheduled" | "progress" | "confirm";
  en: { title: string; meta: string; status: string };
  ar: { title: string; meta: string; status: string };
}

const FEED: FeedItem[] = [
  {
    icon: BadgeCheck,
    status: "done",
    en: { title: "Car insurance renewed — $860/yr", meta: "Voice command · 42s ago", status: "Completed" },
    ar: { title: "تم تجديد تأمين السيارة — ٨٦٠$/سنة", meta: "أمر صوتي · قبل ٤٢ ثانية", status: "مكتمل" },
  },
  {
    icon: Clock3,
    status: "scheduled",
    en: { title: "Apartment viewings booked — Sat 10am", meta: "3 homes · Al Corniche", status: "Scheduled" },
    ar: { title: "حُجزت معاينات الشقق — السبت ١٠ص", meta: "٣ منازل · الكورنيش", status: "مجدول" },
  },
  {
    icon: Activity,
    status: "progress",
    en: { title: "Grocery order #4821 out for delivery", meta: "23 items · arriving 6–8pm", status: "In progress" },
    ar: { title: "طلب البقالة ٤٨٢١# في الطريق", meta: "٢٣ منتجًا · يصل ٦–٨م", status: "قيد التنفيذ" },
  },
  {
    icon: HeartHandshake,
    status: "confirm",
    en: { title: "Flight change to Friday — confirm?", meta: "No fee · seat 14A held", status: "Needs confirm" },
    ar: { title: "تغيير الرحلة إلى الجمعة — تأكيد؟", meta: "بدون رسوم · حُفظ مقعد 14A", status: "بانتظار التأكيد" },
  },
];

const STATUS_STYLE: Record<FeedItem["status"], string> = {
  done: "text-brand border-brand/30 bg-brand/10",
  scheduled: "text-gold border-gold/30 bg-gold/10",
  progress: "text-accent border-accent/30 bg-accent/10",
  confirm: "text-violet border-violet/30 bg-violet/10",
};

const BARS: Record<"en" | "ar", { day: string; v: number }[]> = {
  en: [
    { day: "Mon", v: 62 },
    { day: "Tue", v: 84 },
    { day: "Wed", v: 48 },
    { day: "Thu", v: 95 },
    { day: "Fri", v: 71 },
    { day: "Sat", v: 100 },
    { day: "Sun", v: 56 },
  ],
  ar: [
    { day: "سبت", v: 62 },
    { day: "أحد", v: 84 },
    { day: "اثنين", v: 48 },
    { day: "ثلاثاء", v: 95 },
    { day: "أربعاء", v: 71 },
    { day: "خميس", v: 100 },
    { day: "جمعة", v: 56 },
  ],
};

/* --------------------------------- view --------------------------------- */

export function DashboardPreview() {
  const { t, lang } = useLang();
  const chartRef = useRef<HTMLDivElement>(null);
  const kpiRef = useRef<HTMLDivElement>(null);
  const chartInView = useInView(chartRef, { once: true, margin: "-80px" });
  const kpiInView = useInView(kpiRef, { once: true, margin: "-80px" });

  const tasks = useCountUp(128_400, kpiInView);
  const response = useCountUp(0.8, kpiInView, 1200);
  const saved = useCountUp(6.2, kpiInView, 1400);
  const csat = useCountUp(98, kpiInView);

  const formatTasks = (v: number) =>
    lang === "ar"
      ? Math.round(v).toLocaleString("ar-EG")
      : Math.round(v) >= 1000
        ? `${(v / 1000).toFixed(1)}k`
        : `${Math.round(v)}`;
  const formatSecs = (v: number) =>
    lang === "ar" ? `${v.toLocaleString("ar-EG", { maximumFractionDigits: 1 })} ث` : `${v.toFixed(1)}s`;
  const formatHours = (v: number) =>
    lang === "ar" ? `${v.toLocaleString("ar-EG", { maximumFractionDigits: 1 })} س` : `${v.toFixed(1)}h`;
  const formatPct = (v: number) =>
    lang === "ar" ? `${Math.round(v).toLocaleString("ar-EG")}٪` : `${Math.round(v)}%`;

  const kpis = [
    { label: t("dash.kpi.tasks"), value: formatTasks(tasks), icon: TrendingUp, delta: "+18%" },
    { label: t("dash.kpi.response"), value: formatSecs(response), icon: Clock3, delta: "-120ms" },
    { label: t("dash.kpi.saved"), value: formatHours(saved), icon: HourglassIcon, delta: "+1.4" },
    { label: t("dash.kpi.csat"), value: formatPct(csat), icon: HeartHandshake, delta: "+2%" },
  ];

  const bars = BARS[lang];

  return (
    <section id="dashboard" className="relative overflow-hidden py-24 sm:py-32">
      <div
        aria-hidden
        className="aurora-blob start-[-10%] bottom-[0%] h-[420px] w-[420px] opacity-15"
        style={{ background: "var(--c-violet)" }}
      />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-14 lg:grid-cols-[0.9fr_1.1fr]">
          {/* copy + KPIs */}
          <div>
            <Reveal>
              <Eyebrow>{t("dash.eyebrow")}</Eyebrow>
            </Reveal>
            <Reveal delay={0.08}>
              <h2 className="mt-5 font-display text-4xl font-bold leading-[1.08] tracking-[-0.02em] sm:text-5xl">
                {t("dash.title")} <span className="text-gradient">{t("dash.title.b")}</span>
              </h2>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mt-4 text-base leading-relaxed text-fg2 sm:text-lg">{t("dash.sub")}</p>
            </Reveal>

            <div ref={kpiRef} className="mt-10 grid grid-cols-2 gap-3">
              {kpis.map((k, i) => {
                const Icon = k.icon;
                return (
                  <Reveal key={i} delay={0.08 * i}>
                    <div className="card-surface rounded-2xl p-4">
                      <div className="flex items-center justify-between">
                        <Icon className="h-4 w-4 text-brand" aria-hidden />
                        <span className="rounded-full border border-brand/30 bg-brand/10 px-1.5 py-0.5 text-[9px] font-bold text-brand">
                          {k.delta}
                        </span>
                      </div>
                      <p className="mt-3 font-display text-2xl font-bold tabular-nums tracking-tight">
                        {k.value}
                      </p>
                      <p className="mt-0.5 text-[11px] text-fg3">{k.label}</p>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </div>

          {/* dashboard mock */}
          <Reveal delay={0.15}>
            <div className="card-surface noise relative overflow-hidden rounded-[26px] shadow-[0_50px_100px_-50px_rgba(0,0,0,0.75)]">
              {/* window bar */}
              <div className="flex items-center gap-3 border-b border-line bg-elev/60 px-5 py-3.5">
                <div className="flex gap-1.5" aria-hidden>
                  <span className="h-2.5 w-2.5 rounded-full bg-rose-500/70" />
                  <span className="h-2.5 w-2.5 rounded-full bg-gold/70" />
                  <span className="h-2.5 w-2.5 rounded-full bg-brand/70" />
                </div>
                <div className="mx-auto flex h-7 w-48 items-center gap-2 rounded-lg border border-line bg-ink/60 px-3 text-[11px] text-fg3">
                  <Search className="h-3 w-3" aria-hidden />
                  iroopa.app/home
                </div>
                <Bell className="h-3.5 w-3.5 text-fg3" aria-hidden />
              </div>

              <div className="p-5 sm:p-6">
                {/* chart */}
                <div className="rounded-2xl border border-line bg-ink/50 p-4">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-bold text-fg">{t("dash.chart")}</p>
                    <span className="rounded-full border border-line bg-elev px-2 py-0.5 text-[10px] font-medium text-fg3">
                      {t("dash.week")}
                    </span>
                  </div>
                  <div ref={chartRef} className="mt-4 flex h-32 items-end justify-between gap-2 sm:gap-3">
                    {bars.map((b, i) => (
                      <div key={i} className="flex h-full flex-1 flex-col items-center justify-end gap-2">
                        <motion.div
                          initial={{ scaleY: 0 }}
                          animate={chartInView ? { scaleY: 1 } : {}}
                          transition={{ duration: 0.9, delay: 0.08 * i, ease: [0.22, 1, 0.36, 1] }}
                          style={{ height: `${b.v}%` }}
                          className={`w-full origin-bottom rounded-t-lg ${
                            b.v === 100
                              ? "bg-gradient-to-t from-brand-deep to-brand shadow-[0_0_20px_color-mix(in_oklab,var(--c-brand)_45%,transparent)]"
                              : "bg-gradient-to-t from-line2 to-brand/40"
                          }`}
                        />
                        <span className="text-[9px] font-medium text-fg3">{b.day}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* feed */}
                <div className="mt-4">
                  <p className="mb-2.5 flex items-center gap-2 text-xs font-bold text-fg">
                    <span className="relative flex h-2 w-2" aria-hidden>
                      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand opacity-60" />
                      <span className="relative inline-flex h-2 w-2 rounded-full bg-brand" />
                    </span>
                    {t("dash.feed")}
                  </p>
                  <ul className="space-y-2">
                    {FEED.map((f, i) => {
                      const Icon = f.icon;
                      const copy = lang === "ar" ? f.ar : f.en;
                      return (
                        <Reveal key={i} delay={0.1 * i} y={16}>
                          <li className="flex items-center gap-3 rounded-xl border border-line bg-elev/50 p-3 transition-colors duration-300 hover:border-brand/30">
                            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-line bg-ink/60 text-brand">
                              <Icon className="h-4 w-4" aria-hidden />
                            </span>
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-xs font-semibold text-fg">{copy.title}</p>
                              <p className="truncate text-[10px] text-fg3">{copy.meta}</p>
                            </div>
                            <span
                              className={`shrink-0 rounded-full border px-2 py-0.5 text-[9px] font-bold ${STATUS_STYLE[f.status]}`}
                            >
                              {copy.status}
                            </span>
                          </li>
                        </Reveal>
                      );
                    })}
                  </ul>
                </div>
              </div>

              {/* floating voice pill */}
              <div className="pointer-events-none absolute bottom-5 end-5 hidden items-center gap-2 rounded-full border border-brand/40 bg-panel/90 px-3.5 py-2 shadow-xl backdrop-blur-md sm:flex">
                <Mic className="h-3.5 w-3.5 text-brand" aria-hidden />
                <span className="voice-wave [transform:scale(0.7)]" aria-hidden>
                  <span /><span /><span /><span /><span />
                </span>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
