import { useCallback } from "react";
import {
  Building2,
  CalendarClock,
  Mic,
  Phone,
  Plane,
  ShieldCheck,
  ShoppingBag,
  type LucideIcon,
} from "lucide-react";
import { useLang } from "../lib/i18n";
import { Eyebrow, Reveal } from "./Reveal";

interface Service {
  icon: LucideIcon;
  en: { title: string; desc: string; cmd: string };
  ar: { title: string; desc: string; cmd: string };
  accent: string;
}

const SERVICES: Service[] = [
  {
    icon: ShieldCheck,
    en: {
      title: "Insurance, simplified",
      desc: "Compare quotes, renew policies, file and track claims — by voice.",
      cmd: "Compare health plans and pick the best value",
    },
    ar: {
      title: "التأمين، ببساطة",
      desc: "قارن العروض، جدّد الوثائق، وقدّم المطالبات وتتبعها — بالصوت.",
      cmd: "قارن الخطط الصحية واختر الأفضل قيمة",
    },
    accent: "var(--c-brand)",
  },
  {
    icon: Building2,
    en: {
      title: "Real estate concierge",
      desc: "Search homes, book viewings and pre-check mortgages hands-free.",
      cmd: "Homes near the Corniche under 2M SAR",
    },
    ar: {
      title: "كونسيرج العقارات",
      desc: "ابحث عن المنازل، احجز المعاينات وتحقق من التمويل دون لمس.",
      cmd: "منازل قرب الكورنيش بأقل من مليوني ريال",
    },
    accent: "var(--c-accent)",
  },
  {
    icon: ShoppingBag,
    en: {
      title: "E-commerce autopilot",
      desc: "Reorder staples, watch prices, track deliveries and returns.",
      cmd: "Reorder last month's groceries",
    },
    ar: {
      title: "تسوّق آلي بالكامل",
      desc: "أعد طلب الأساسيات، راقب الأسعار، وتتبّع الشحنات والمرتجعات.",
      cmd: "أعد طلب مشتريات الشهر الماضي",
    },
    accent: "var(--c-violet)",
  },
  {
    icon: Plane,
    en: {
      title: "Travel & bookings",
      desc: "Flights, hotels and itinerary changes — confirmed in seconds.",
      cmd: "Move my Thursday flight to Friday",
    },
    ar: {
      title: "السفر والحجوزات",
      desc: "الرحلات والفنادق وتعديلات الجدول — تُؤكَّد خلال ثوانٍ.",
      cmd: "انقل رحلة الخميس إلى الجمعة",
    },
    accent: "var(--c-gold)",
  },
  {
    icon: Phone,
    en: {
      title: "Virtual phone line",
      desc: "Second numbers, smart call screening and voicemail-to-text.",
      cmd: "Screen unknown callers on line two",
    },
    ar: {
      title: "خط هاتف افتراضي",
      desc: "أرقام ثانية، فحص ذكي للمكالمات وتحويل البريد الصوتي لنص.",
      cmd: "افحص المكالمات المجهولة على الرقم الثاني",
    },
    accent: "var(--c-brand)",
  },
  {
    icon: CalendarClock,
    en: {
      title: "Life admin",
      desc: "Bills, renewals and appointments — remembered so you don't.",
      cmd: "Remind me to renew the car registration",
    },
    ar: {
      title: "إدارة شؤون الحياة",
      desc: "الفواتير والتجديدات والمواعيد — نتذكرها نيابةً عنك.",
      cmd: "ذكّرني بتجديد استمارة السيارة",
    },
    accent: "var(--c-accent)",
  },
];

export function Services() {
  const { t, lang } = useLang();

  const onMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    const r = el.getBoundingClientRect();
    el.style.setProperty("--mx", `${e.clientX - r.left}px`);
    el.style.setProperty("--my", `${e.clientY - r.top}px`);
  }, []);

  return (
    <section id="services" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <Reveal>
            <Eyebrow>{t("services.eyebrow")}</Eyebrow>
          </Reveal>
          <Reveal delay={0.08}>
            <h2 className="mt-5 font-display text-4xl font-bold leading-[1.08] tracking-[-0.02em] sm:text-5xl">
              {t("services.title")}{" "}
              <span className="text-gradient">{t("services.title.b")}</span>
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mt-4 text-base leading-relaxed text-fg2 sm:text-lg">{t("services.sub")}</p>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s, i) => {
            const Icon = s.icon;
            const copy = lang === "ar" ? s.ar : s.en;
            return (
              <Reveal key={i} delay={0.06 * (i % 3)} className="h-full">
                <div
                  onMouseMove={onMove}
                  className="card-surface card-spotlight group flex h-full flex-col rounded-3xl p-6 hover:-translate-y-1"
                >
                  <div className="flex items-start justify-between">
                    <span
                      className="grid h-12 w-12 place-items-center rounded-2xl border border-line bg-elev transition-transform duration-500 group-hover:scale-110 group-hover:rotate-[8deg]"
                      style={{ color: s.accent }}
                    >
                      <Icon className="h-5.5 w-5.5" aria-hidden />
                    </span>
                    <span className="font-display text-xs font-bold text-fg3/60">
                      0{i + 1}
                    </span>
                  </div>
                  <h3 className="mt-5 text-lg font-bold tracking-tight text-fg">{copy.title}</h3>
                  <p className="mt-2 flex-1 text-sm leading-relaxed text-fg2">{copy.desc}</p>
                  <div className="mt-5 flex items-start gap-2 rounded-xl border border-line bg-ink/60 p-3">
                    <Mic className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand" aria-hidden />
                    <p dir="auto" className="text-xs font-medium italic leading-relaxed text-fg2">
                      “{copy.cmd}”
                    </p>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
