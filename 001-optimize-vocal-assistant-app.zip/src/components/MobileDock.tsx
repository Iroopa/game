import { Home, LayoutGrid, LayoutDashboard, Mic } from "lucide-react";
import { motion } from "framer-motion";
import { useLang } from "../lib/i18n";

/** Floating mobile quick-nav — a nod to the original app's bottom bar. */
export function MobileDock() {
  const { t } = useLang();

  const items = [
    { icon: Home, label: "iRoopa", href: "#top" },
    { icon: LayoutGrid, label: t("nav.services"), href: "#services" },
    { icon: Mic, label: t("nav.demo"), href: "#demo", voice: true },
    { icon: LayoutDashboard, label: t("nav.dashboard"), href: "#dashboard" },
  ];

  return (
    <motion.nav
      initial={{ y: 80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 1.1, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="glass fixed inset-x-4 bottom-4 z-40 flex items-center justify-between rounded-2xl border border-line px-2 py-2 shadow-[0_16px_40px_-16px_rgba(0,0,0,0.6)] md:hidden"
      aria-label="Quick navigation"
    >
      {items.map((item) => {
        const Icon = item.icon;
        if (item.voice) {
          return (
            <button
              key={item.href}
              type="button"
              aria-label={item.label}
              onClick={() => {
                document.getElementById("demo")?.scrollIntoView({ behavior: "smooth", block: "center" });
                window.setTimeout(() => window.dispatchEvent(new CustomEvent("iroopa:talk")), 650);
              }}
              className="mx-1 -mt-6 grid h-13 w-13 shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand to-brand-deep text-onbrand shadow-[0_12px_30px_-8px_color-mix(in_oklab,var(--c-brand)_70%,transparent)]"
            >
              <Mic className="h-5 w-5" aria-hidden />
            </button>
          );
        }
        return (
          <a
            key={item.href}
            href={item.href}
            className="flex flex-1 flex-col items-center gap-1 rounded-xl py-1.5 text-fg2 transition-colors hover:text-fg"
          >
            <Icon className="h-5 w-5" aria-hidden />
            <span className="text-[9px] font-medium">{item.label}</span>
          </a>
        );
      })}
    </motion.nav>
  );
}
